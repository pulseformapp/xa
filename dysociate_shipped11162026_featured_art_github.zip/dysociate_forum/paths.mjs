/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later.
 */

export const publicForum = "/forum";
export const womenForum = "/forum/women";
export const womenStoreName = "voice-for-women";
export const womenForumTitle = "A Voice for Women";

export function moderationPath(env) {
    const path = env.FORUM_MOD_PATH;
    return /^\/forum\/mod[A-Za-z0-9_$-]{1,80}$/.test(path || "") ? path : null;
}
