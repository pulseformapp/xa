# dλsociate public forum

The forum runs on a Workers Free-compatible Worker and a SQLite-backed Durable Object. One SQLite database stores submissions, decisions, and open reports. The forum accepts anonymous text topics and replies. Every submission starts pending. Only a moderator can publish or remove it. The private status receipt shows the submission's state and never includes its text.

## Moderation

Open the deployed moderator address and enter the moderator key. Review **Pending submissions** to approve or decline a topic or reply. Use **Published** to remove a topic or reply directly from the forum. Open **Reports** to decide whether to keep or remove a reported item. Removing a topic hides its replies. Removing a reply leaves the topic and other replies available.

After drafting a topic or reply, visitors answer three required questions to submit it for review. **Submission answers** in the moderator dashboard shows those private answers. Public posts and email alerts carry the original post or a review link, respectively.

The optional `FORUM_WATCH_TERMS` binding accepts one term per line. Matching ignores case, common Unicode presentation variants, spaces, and punctuation. Matches and simple spam patterns put an item higher in the queue for human review. Each original post remains available to the moderator as submitted.

## A Voice for Women

From Moderation, open **A Voice for Women → Invitation keys**. Generate a unique key for each guest. Add an optional private label to identify the key on the dashboard and in the review queue. Copy the key when it appears and send it directly with the `/forum/women` address. A key grants access to anyone who holds it. Revoking it closes all sessions created with that key on their next request.

Guests only enter their invitation key. They can then submit text topics and replies for human review. Use **A Voice for Women → Pending submissions** to approve or decline. Published topics, replies and their report forms are available to invited guests. The existing Durable Object class uses a separate named instance for this forum so private posts do not enter public queries.

## Alerts

The Cloudflare Email Routing binding is restricted to the verified `luna@dysociate.org` destination. Use **Send test alert** in Moderation to check delivery through the existing inbox. The email contains a link to the review case. Duplicate reports on the same open case share an alert. Due alerts persist and retry after a send failure. A moderator can retry an alert whose automatic attempts are exhausted.

## Deployment and local tests

Use Wrangler with `wrangler.jsonc`. Set `FORUM_MODERATOR_KEY` as a Worker secret to a 32-byte cryptographically random value encoded as base64url without padding. Distribute the key privately to the moderator. Rotating the key invalidates existing moderator sessions. Stage a deployment with `FORUM_OPEN=false` to test mail and moderator access before opening submissions.

Set `FORUM_MOD_PATH` as a Worker secret to a path starting with `/forum/mod` followed by 1 to 80 letters, digits, hyphens, underscores, or dollar signs. Moderator forms and new report emails use that path. Share the address privately with moderators.

For local testing, supply a disposable 43-character base64url `FORUM_MODERATOR_KEY` and a test `FORUM_MOD_PATH` to `wrangler dev --local`. Set `PUBLIC_ORIGIN` to the exact loopback address used by the server and set `--infer-origin-from-routes=false`. Use a fresh `--persist-to` directory. Set `FORUM_TEST_KEY` and `FORUM_TEST_MOD_PATH` in the test process to the corresponding test values, then run `node tests/moderation.mjs http://127.0.0.1:8797`. Wrangler simulates the email binding locally.
Run `node tests/women.mjs http://127.0.0.1:8797` with the same disposable configuration to verify invitations, publication and revocation.
