/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later.
 */

import css from "./forum.css";
import {moderationPath, publicForum, womenForum, womenStoreName} from "./paths.mjs";
import {lunaBlogTopicId} from "./store.mjs";
import {answerLimit, forumIndex, html, inviteCreated, invitePage, moderatorLogin, problem, reasons, receiptPage, reviewPage, submissionQuestions, topicPage, womenGate} from "./views.mjs";
export {ForumStore} from "./store.mjs";

const encoder = new TextEncoder();
const sessionLifetime = 12 * 3600;
const memberLifetime = 30 * 24 * 3600;
const idPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const keyPattern = /^[a-zA-Z0-9_-]{43}$/;
const moderatorActions = new Set(["approve", "decline", "remove", "keep", "retry"]);

class ForumError extends Error {
    constructor(status, message) {
        super(message);
        this.status = status;
    }
}

const unavailable = () => problem("This page is unavailable.", 404);
const redirect = (location, headers = {}) => new Response(null, {status: 303, headers: {Location: location, ...headers}});

async function form(request, maxBytes = 56 * 1024) {
    if (request.headers.get("Content-Type")?.split(";")[0] !== "application/x-www-form-urlencoded" || !request.body) {
        throw new ForumError(400, "Submit this action using the forum form.");
    }
    const reader = request.body.getReader();
    const decoder = new TextDecoder();
    let text = "";
    let length = 0;
    try {
        for (;;) {
            const {value, done} = await reader.read();
            if (done) break;
            length += value.byteLength;
            if (length > maxBytes) {
                await reader.cancel();
                throw new ForumError(413, "This submission is too long.");
            }
            text += decoder.decode(value, {stream: true});
        }
    } finally {
        reader.releaseLock();
    }
    return new URLSearchParams(text + decoder.decode());
}

function field(fields, name, max, required = true) {
    const value = (fields.get(name) || "").trim().replaceAll("\r\n", "\n");
    if ((required && !value) || value.length > max) throw new ForumError(400, `Use ${required ? "1 to " : "up to "}${max} characters for ${name}.`);
    return value;
}

function normalize(value) {
    return value.normalize("NFKC").toLowerCase().replace(/[\p{Cf}\p{P}\p{Z}\s]/gu, "");
}

function reviewHint(env, copy) {
    // Hints only change queue order. Every submission takes the same path
    // through pending review, and the original text is always shown to staff.
    const normalized = normalize(copy.slice(0, 4200));
    const terms = (env.FORUM_WATCH_TERMS || "").split("\n").slice(0, 200).map(normalize);
    if (terms.some(term => term.length >= 3 && normalized.includes(term))) return "Matches a watch term";
    if (/(.)\1{23}/u.test(copy) || (copy.match(/https?:\/\//gi) || []).length >= 4) return "Repeated characters or several links";
    return "";
}

async function rateLimit(request, binding, scope = "") {
    // Cloudflare applies the rate limit at the edge. The forum database does
    // not need an IP address or a public account to record posts and reports.
    const address = request.headers.get("CF-Connecting-IP") || "loopback";
    const result = await binding.limit({key: scope + address});
    if (!result.success) throw new ForumError(429, "Too many requests. Wait a minute and try again.");
}

function pageNumber(url) {
    const value = url.searchParams.get("page") || "1";
    return /^[1-9][0-9]{0,5}$/.test(value) ? Number(value) - 1 : 0;
}

function moderationTarget(fields, modPath, women) {
    const reportId = fields.get("report");
    if (idPattern.test(reportId || "")) return {reportId, view:"reports", path:`${modPath}?report=${reportId}`};
    const requested = fields.get("view");
    const views = women ? ["reports", "published", "invites"] : ["reports", "published"];
    const view = views.includes(requested) ? requested : "pending";
    return {reportId:null, view, path:view === "pending" ? modPath : `${modPath}?view=${view}`};
}

function cookieName(url, member) {
    const name = member ? "dysociate-forum-women" : "dysociate-forum-mod";
    return url.protocol === "https:" ? `__Host-${name}` : `${name}-local`;
}

function sessionCookie(url, token, age, member = false) {
    return `${cookieName(url, member)}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${age}${url.protocol === "https:" ? "; Secure" : ""}`;
}

async function authKey(env) {
    return crypto.subtle.importKey("raw", encoder.encode(env.FORUM_MODERATOR_KEY), {name: "HMAC", hash: "SHA-256"}, false, ["sign", "verify"]);
}

function sessionPayload(expires, subject, member) {
    // Different signing contexts keep a member cookie from being reused as
    // a moderator cookie, even if someone copies it and renames it.
    const purpose = member ? "dysociate-women-session" : "dysociate-forum-session";
    return encoder.encode(`${purpose}/v1/${expires}/${subject}`);
}

async function newSession(key, inviteId = null) {
    const expiry = Math.floor(Date.now() / 1000) + (inviteId ? memberLifetime : sessionLifetime);
    const subject = inviteId || crypto.randomUUID();
    const tag = new Uint8Array(await crypto.subtle.sign("HMAC", key, sessionPayload(expiry, subject, Boolean(inviteId)))).toHex();
    return `${expiry}.${subject}.${tag}`;
}

async function sessionSubject(request, url, env, member = false) {
    const name = cookieName(url, member) + "=";
    const token = (request.headers.get("Cookie") || "").split(";").map(piece => piece.trim())
        .find(piece => piece.startsWith(name))?.slice(name.length);
    const [expiry, subject, tag, extra] = (token || "").split(".");
    const now = Math.floor(Date.now() / 1000);
    const lifetime = member ? memberLifetime : sessionLifetime;
    if (extra !== undefined || !/^\d{10,11}$/.test(expiry) || Number(expiry) <= now || Number(expiry) > now + lifetime ||
        !idPattern.test(subject || "") || !/^[a-f0-9]{64}$/.test(tag || "")) return null;
    const valid = await crypto.subtle.verify("HMAC", await authKey(env), Uint8Array.fromHex(tag), sessionPayload(expiry, subject, member));
    return valid ? subject : null;
}

async function keyDigest(key) {
    return new Uint8Array(await crypto.subtle.digest("SHA-256", encoder.encode(key))).toHex();
}

async function moderator(request, url, env, store, action, rootPath, women) {
    const modPath = women ? `${rootPath}/women` : rootPath;
    if (request.method === "GET" && !action) {
        const target = moderationTarget(url.searchParams, modPath, women);
        if (!await sessionSubject(request, url, env)) return moderatorLogin(modPath, target.view, target.reportId);
        const page = target.reportId ? 0 : pageNumber(url);
        if (target.view === "invites") return invitePage(rootPath, await store.invites(page), page);
        return reviewPage(rootPath, await store.reviewQueue(target.view, page, target.reportId), target.view, page, women);
    }
    if (request.method !== "POST") return unavailable();
    if (action === "sign-in") {
        await rateLimit(request, env.FORUM_LOGIN);
        const fields = await form(request, 4096);
        const target = moderationTarget(fields, modPath, women);
        const supplied = fields.get("key") || "";
        const key = await authKey(env);
        const expected = await crypto.subtle.sign("HMAC", key, encoder.encode(env.FORUM_MODERATOR_KEY));
        if (!keyPattern.test(supplied) || !await crypto.subtle.verify("HMAC", key, expected, encoder.encode(supplied))) {
            return moderatorLogin(modPath, target.view, target.reportId, true);
        }
        return redirect(target.path, {"Set-Cookie": sessionCookie(url, await newSession(key), sessionLifetime)});
    }
    if (!await sessionSubject(request, url, env)) return problem("Sign in as a moderator to review submissions.", 403);
    if (action === "sign-out") return redirect(modPath, {"Set-Cookie": sessionCookie(url, "", 0)});
    if (women && action === "create-invite") {
        const fields = await form(request, 4096);
        const label = field(fields, "label", 80, false);
        const key = crypto.getRandomValues(new Uint8Array(32)).toBase64({alphabet:"base64url", omitPadding:true});
        // Only the generated response contains the plaintext, which means
        // the dashboard can revoke a key but cannot retrieve it later.
        await store.createInvite(await keyDigest(key), label);
        return inviteCreated(modPath, key);
    }
    if (women && action === "revoke-invite") {
        const id = (await form(request, 4096)).get("id");
        if (!idPattern.test(id || "")) return unavailable();
        await store.revokeInvite(id);
        return redirect(`${modPath}?view=invites`);
    }
    if (action === "test-email") {
        try {
            await store.sendAlert("dysociate forum: test alert", `This is a test of forum report notifications.\n\n${env.PUBLIC_ORIGIN}${modPath}?view=reports\n`);
            return html("Test alert sent", `<h1>Test alert sent</h1><p>Check your inbox for the test message.</p><a href="${modPath}">Back to moderation</a>`);
        } catch (error) {
            // This diagnostic is available only to an authenticated moderator.
            const code = /^E_[A-Z_]+$/.test(error?.code || "") ? ` (${error.code})` : "";
            const detail = typeof error?.message === "string" ? error.message.slice(0, 300) : "";
            return problem(`The test alert failed${code}. ${detail}`, 503);
        }
    }
    if (action !== "decision") return unavailable();
    const fields = await form(request, 4096);
    const choice = fields.get("action");
    const id = fields.get("id");
    if (!moderatorActions.has(choice) || !idPattern.test(id || "")) return unavailable();
    const changed = choice === "retry" ? await store.retryAlert(id) : await store.decide(choice, id);
    if (!changed) return html("Already reviewed", `<h1>Review item unavailable</h1><p>Reload the queue for its latest status.</p><a href="${modPath}">Back to moderation</a>`, 409);
    if (choice === "approve" || choice === "decline") return redirect(modPath);
    if (choice === "remove" && url.searchParams.get("view") === "published") return redirect(`${modPath}?view=published`);
    return redirect(`${modPath}?view=reports`);
}

async function submit(request, env, store, topicId, forum, inviteId) {
    const fields = await form(request);
    const title = topicId ? null : field(fields, "title", 120);
    const body = field(fields, "body", 4000);
    const draft = {topicId, title, body};
    let answers;
    if (forum === publicForum) {
        if (fields.get("step") !== "questionnaire") {
            if (topicId && !await store.isPublishedTopic(topicId)) return unavailable();
            return submissionQuestions(draft);
        }
        answers = {
            gender: (fields.get("gender") || "").trim(),
            topic: (fields.get("topic") || "").trim(),
            discovery: (fields.get("discovery") || "").trim(),
        };
        if (Object.values(answers).some(answer => !answer || answer.length > answerLimit)) return submissionQuestions(draft, answers, true);
    }
    await rateLimit(request, env.FORUM_WRITE);
    const id = await store.submit({...draft, hint: reviewHint(env, `${title || ""}\n${body}`), answers, inviteId});
    return id ? redirect(`${forum}/receipt/${id}`) : unavailable();
}

async function browse(request, url, env, store, forum, inviteId = null) {
    const [view, id, action, extra] = url.pathname.slice(forum.length + 1).split("/");
    const method = request.method;
    if (extra !== undefined) return unavailable();
    if (!view && !id) {
        if (method === "POST") return submit(request, env, store, null, forum, inviteId);
        const page = pageNumber(url);
        return forumIndex(await store.topics(page), page, forum);
    }
    if (view === "reported" && !id && method === "GET") return html("Report received",
        `<h1>Report received</h1><p>Your report has been saved for a moderator to review.</p><a href="${forum}">Back to the forum</a>`);
    if (!idPattern.test(id || "")) return unavailable();
    if (view === "topic" && action === "reply" && method === "POST") {
        if (id === lunaBlogTopicId) return problem("Replies are closed for this topic.", 403);
        return submit(request, env, store, id, forum, inviteId);
    }
    if (view === "topic" && !action && method === "GET") {
        const page = pageNumber(url);
        const topic = await store.topic(id, page);
        return topic ? topicPage(topic, page, forum) : unavailable();
    }
    if (view === "receipt" && !action && method === "GET") {
        const receipt = await store.receipt(id);
        return receipt ? receiptPage(receipt, forum) : unavailable();
    }
    if (view === "report" && !action && method === "POST") {
        if (id === lunaBlogTopicId) return problem("Reporting is unavailable for this post.", 403);
        await rateLimit(request, env.FORUM_WRITE);
        const fields = await form(request, 8192);
        const reason = fields.get("reason");
        if (!Object.hasOwn(reasons, reason)) return problem("Choose a reason for your report.", 400);
        return await store.report(id, reason, field(fields, "details", 400, false), inviteId) ? redirect(`${forum}/reported`) : unavailable();
    }
    return unavailable();
}

function womenReturn(path) {
    const [view, id, extra] = (path || "").slice(womenForum.length + 1).split("/");
    if (path?.startsWith(`${womenForum}/`) && ["topic", "receipt"].includes(view) && idPattern.test(id || "") && extra === undefined) {
        return path;
    }
    return womenForum;
}

async function womenAccess(request, url, env, store) {
    if (request.method === "POST" && url.pathname === `${womenForum}/unlock`) {
        await rateLimit(request, env.FORUM_LOGIN, "invitation/");
        const fields = await form(request, 4096);
        const next = womenReturn(fields.get("next"));
        const supplied = (fields.get("key") || "").trim();
        const inviteId = keyPattern.test(supplied) ? await store.inviteForKey(await keyDigest(supplied)) : null;
        if (!inviteId) return womenGate(next, true);
        const token = await newSession(await authKey(env), inviteId);
        return redirect(next, {"Set-Cookie": sessionCookie(url, token, memberLifetime, true)});
    }
    if (request.method === "POST" && url.pathname === `${womenForum}/leave`) {
        return redirect(womenForum, {"Set-Cookie": sessionCookie(url, "", 0, true)});
    }
    const inviteId = await sessionSubject(request, url, env, true);
    if (!inviteId || !await store.activeInvite(inviteId)) {
        return womenGate(womenReturn(url.pathname), false, request.method === "GET" ? 200 : 403);
    }
    return browse(request, url, env, store, womenForum, inviteId);
}

function within(path, base) {
    return path === base || path.startsWith(`${base}/`);
}

async function route(request, url, env, modPath) {
    const path = url.pathname;
    const method = request.method;
    if (url.origin !== env.PUBLIC_ORIGIN || !within(path, publicForum)) return unavailable();
    if (!modPath || !keyPattern.test(env.FORUM_MODERATOR_KEY || "")) return problem("The forum is being set up. Please come back later.", 503);
    if (method === "POST" && request.headers.get("Origin") !== url.origin) return problem("Open the forum and submit the form again.", 403);
    if (method !== "GET" && method !== "POST") return problem("Use a forum page or form for this action.", 405);
    if (path === `${publicForum}/style.css` && method === "GET") return new Response(css, {headers: {"Content-Type": "text/css; charset=utf-8"}});

    const isModerator = within(path, modPath);
    if (!isModerator && env.FORUM_OPEN !== "true") return problem("The forum is being set up. Please come back later.", 503);
    const womenModeration = `${modPath}/women`;
    const women = within(path, womenForum) || within(path, womenModeration);
    const store = env.FORUM.getByName(women ? womenStoreName : "public-forum");
    if (isModerator) {
        const action = path.slice((women ? womenModeration : modPath).length + 1);
        return action.includes("/") ? unavailable() : moderator(request, url, env, store, action, modPath, women);
    }
    if (women) return womenAccess(request, url, env, store);
    return browse(request, url, env, store, publicForum);
}

export default {
    async fetch(request, env) {
        const url = new URL(request.url);
        url.pathname = url.pathname.replaceAll("%24", "$");
        const modPath = moderationPath(env);
        let response;
        try {
            response = await route(request, url, env, modPath);
        } catch (error) {
            response = error instanceof ForumError ? problem(error.message, error.status)
                : problem("The forum is temporarily unavailable. Please try again.", 503);
        }
        response.headers.set("Cache-Control", "no-store");
        response.headers.set("Referrer-Policy", "same-origin");
        response.headers.set("X-Content-Type-Options", "nosniff");
        response.headers.set("Content-Security-Policy", "default-src 'none'; style-src 'self'; img-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'");
        if ((modPath && within(url.pathname, modPath)) || within(url.pathname, womenForum) ||
            /^\/forum\/(receipt|reported)(\/|$)/.test(url.pathname)) response.headers.set("X-Robots-Tag", "noindex");
        return response;
    },
};
