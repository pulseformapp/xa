"""Create reproducible, source-inclusive iPhone web edition distributions.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""
import hashlib
from pathlib import Path
import zipfile

from build import VERSION

HERE = Path(__file__).resolve().parent


def archive(destination, files):
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for source, name in sorted(files, key=lambda item: item[1]):
            entry = zipfile.ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            output.writestr(entry, source.read_bytes())
    with zipfile.ZipFile(destination) as output:
        if output.testzip():
            raise ValueError("ZIP CRC verification failed")
    print(destination)


def main():
    releases = HERE / "releases"
    releases.mkdir(exist_ok=True)
    source = releases / f"dysociate-{VERSION}-source.zip"
    website = releases / f"dysociate-{VERSION}-website.zip"
    excluded = {".git", ".openai", ".venv", "__pycache__", "releases"}
    archive(source, [(p, "dysociate-iphone/" + p.relative_to(HERE).as_posix())
                     for p in HERE.rglob("*") if p.is_file() and not excluded.intersection(p.relative_to(HERE).parts)])
    archive(website, [(p, p.relative_to(HERE / "dist").as_posix())
                      for p in (HERE / "dist").rglob("*") if p.is_file()])
    checksums = "".join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n" for p in (source, website))
    (releases / "SHA256SUMS.txt").write_text(checksums, encoding="ascii")


if __name__ == "__main__":
    main()
