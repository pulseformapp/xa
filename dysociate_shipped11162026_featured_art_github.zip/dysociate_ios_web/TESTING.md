# Physical iPhone/iPad release acceptance

These are pending device checks, not claims of completed tests.

1. On a supported iPhone in Safari, install from an HTTPS host. Open the Home
   Screen icon. Check logo, notch safe areas, portrait and landscape layouts.
2. The license Agree button must remain hidden until the entire agreement is
   scrolled. Repeat for Karmic Law if it overflows. Disagree must lock the app.
   Close/reopen after agreeing; unchanged agreements should stay accepted.
3. Post text with a long unbroken word and a photo from Photos. Reply, reply
   again, edit and remove an image. Check keyboard, 16 px fields and tap targets.
4. Leave an unfinished reply and image. Switch apps, force-close, then reopen.
   The posted thread, reply target and unfinished draft must recover.
5. Wait for Ready offline. Enable airplane mode, close and reopen the app. Read,
   post and reply. Save to Files offline. Disable airplane mode afterward.
6. Export HTML via Save to Files. Open/import that file in the Windows app,
   Android app and the iPhone editor. Posts, images and reply links must match.
7. Receive an HTML attachment in Mail. Save to Files, then Open HTML in the app.
   Cancel the picker and try an invalid file; the current thread must survive.
8. Share HTML to Mail, AirDrop and a messenger that accepts HTML attachments.
   Confirm the actual attachment opens and includes the latest comment.
   Cancel each sheet; work must remain. Check unsupported-type download fallback.
9. Try Email with a large photo thread. Check the 8 MB budget and attachment.
   If the chosen mail app does not support .eml, use HTML-to-Mail instead.
10. Load a new hosted app version with a draft open. Update must wait for the
    button. Accept update; verify draft recovery. Simulate denied/full browser
    storage and verify a visible warning with export still available.
11. Test VoiceOver focus in agreements/help, large text settings, reduced motion,
    and an iPad split-screen window. Ensure Agree and Disagree stay reachable.

Copies do not sync. Check the newest saved file, not an older attachment.
