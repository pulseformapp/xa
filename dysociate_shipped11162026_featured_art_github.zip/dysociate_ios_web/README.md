# dλsociate for iPhone & iPad

created by luna love, lunasoft λ 2026

The installable web edition of dλsociate. The same portable HTML conversations
as the Windows and Android apps, with an iPhone Home Screen icon, offline
app shell, recovery drafts, Files/Photos pickers and file sharing.

This is a Progressive Web App (PWA), not an App Store app or signed IPA.
No Mac, Xcode or Apple Developer membership is needed to use this edition.
Serve `dist/` from an HTTPS static host before installing it on a phone.
Opening the files directly does not install an offline app.

## Install

1. Open the hosted HTTPS address in Safari on the iPhone or iPad.
2. Tap Share (or More → Share), then Add to Home Screen.
3. Enable Open as Web App if offered. Tap Add.
4. Open the new dλsociate icon, read and accept the license and Karmic Law.
5. Wait for **Ready offline** while online. Then the app can reopen offline.

Install before starting important work: Safari tabs and an installed web app
can have separate browser storage. A private preview host requires its owner's
sign-in on first use; it is not a public release address for recipients.

## Use

**Create live thread** opens the online composer in a separate browser tab.
Share the link it creates to let participants post and reply to the same live
thread. The offline editor keeps its own local draft. The build can point to
another HTTPS composer with `--live-editor https://example.org/t/new`.

- **New post:** write text, optionally choose a photo, then Post to thread.
- **Reply:** tap Reply under a post. Reply chains keep their parent links.
- **Edit:** changes the selected post in your current copy. Delete also removes
  its replies after confirmation.
- **Open HTML:** choose a received dλsociate `.html` file from Files. Only its
  editable data is imported. Imported scripts do not execute.
- **Thread details:** change the page title, banner and optional public HTTPS
  browser-editor link.
- **Save HTML:** prepares the newest complete HTML file. Tap Share prepared
  file → Save to Files, or Download file. Safari chooses the destination flow.
- **Share / Email → Share HTML file:** opens the system share sheet if the
  browser supports sharing HTML files. Choose Mail, AirDrop, Messages or another
  compatible app. Otherwise download the file and attach it yourself.
- **Email:** prepares an `.eml` draft with the HTML attached. Oversized email
  copies optimize images toward an 8 MB MIME budget. This does not change the
  original thread. Some iPhone mail apps cannot open `.eml` drafts: share HTML
  directly to Mail or attach the downloaded HTML instead. Provider limits vary.
- **Help / Install:** opens the built-in offline manual.

No message is sent automatically. A successful share-sheet handoff does not
prove delivery or a disk save. Canceling keeps your work. Safari does not
silently overwrite the original HTML attachment: keep and send the newest copy.

## What offline means

Your working thread, unfinished text, selected image and reply target are kept
in IndexedDB on this browser/device. This is recovery storage, not a substitute
for saving HTML to Files. iOS, browser settings or clearing site data can remove
it. Important threads need exported copies.

The service worker caches only the app shell. Opening or importing an HTML
thread keeps it in the offline editor. **Create live thread** opens a separate
online service with its own shared history. Your static hosting provider may
keep access logs.

People exchange HTML copies. Replies do not magically merge with other copies,
and a published page does not update when somebody edits it locally. Email/file
previews sometimes disable scripts: import the attachment into this app.

An update waits while the editor remains open. The Update ready button saves a
recovery checkpoint before applying it. If that checkpoint fails, the app does
not reload. Previously cached shell versions remain available to older tabs.

## Host

Upload **all contents of `dist/` together**, keeping file names and paths intact,
to GitHub Pages, Cloudflare Pages, Netlify or an ordinary HTTPS static host.
No build server, Python runtime, API keys or database are required for visitors.
The app works at a domain root or a subdirectory.

Serve `sw.js` as JavaScript and `manifest.webmanifest` as a web manifest or JSON.
Do not redirect asset requests to an HTML landing/login page. Allow service
worker installation. Revalidate `index.html`, `sw.js`, `iphone.js` and CSS rather
than applying a long immutable CDN lifetime to these unversioned file names.
Use a stable origin: changing the host/path creates a different app storage area.

The development checkout's `.openai/hosting.json` identity belongs to this
project's owner-private review Site. Its hosting workflow uploads the app source
and static files with the owner's authorization. Release ZIPs omit this identity;
it is not needed on your own static host. The preview is not a public release.

## Rebuild from complete source

Use Python 3.11+ with Tkinter (required by the existing renderer's import) and
Pillow. Neither Python nor Tkinter is needed on the phone.

```powershell
python -m venv .venv
& .\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
& .\.venv\Scripts\python.exe .\build.py
& .\.venv\Scripts\python.exe -m http.server 8766 --bind 127.0.0.1 --directory dist
```

Localhost allows desktop service-worker development. An iPhone cannot reach a
Windows computer through the phone's own `localhost`. Use HTTPS hosting to
install on the phone. A plain LAN HTTP address is insufficient for offline setup.

The `shared/` folder is the matching canonical renderer, portable editor,
license, resources and logo needed to reproduce `dist/` without the other apps.
`build.py` guards its markup anchors to fail visibly if that renderer changes.

## Checks and release status

The automated test uses an isolated installed Windows Edge executable and Node
24. It opens only a temporary test profile and a loopback HTTP preview:

```powershell
node .\test_browser.cjs http://127.0.0.1:8766/
```

It checks scroll-gated agreements, decline lock, IndexedDB reload recovery,
photo round trips, storage-write failures, portable exports, unsafe/malformed imports, share cancellation/fallback, email
attachment, offline navigation with networking disabled and 320/390/820/1280 px
layouts. The native share sheet is mocked; no email or message is sent.

**Actual iPhone/iPad Safari and real share destinations have not been tested.**
Before selling the iPhone edition, run the acceptance steps in TESTING.md on
physical devices. No signed native iOS binary has been produced.

## License

Copyright (c) 2026 Luna Love ~ LunaSoft. GPL-3.0-or-later; see LICENSE for the
complete terms and warranty/liability disclaimer. Distributed derivatives must
meet the GPL's corresponding-source obligations. Posts and pictures remain
their authors' content. Karmic Law text is included as requested.
