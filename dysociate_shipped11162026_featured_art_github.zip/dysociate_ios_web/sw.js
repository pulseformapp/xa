/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 * Cache only the published shell. Imported HTML/photos never use fetch().
 */
"use strict";
const CACHE = "dysociate-iphone-__SHELL_HASH__";
const ROOT = new URL("./", self.location.href);
const ASSETS = ["./", "index.html", "iphone.js", "iphone.css", "manifest.webmanifest",
    "LICENSE", "icon-180.png", "icon-192.png", "icon-512.png"].map(p => new URL(p, ROOT).href);
self.addEventListener("install", event => {
    // Installation is atomic: a failed request leaves the previous shell active.
    // Never cache a redirected login page as the offline app on a private host.
    event.waitUntil((async () => {
        const cache = await caches.open(CACHE);
        try {
            for (const url of ASSETS) {
                const response = await fetch(new Request(url, {cache:"reload", credentials:"same-origin"}));
                if (!response.ok || response.redirected) throw Error("Offline shell unavailable");
                await cache.put(url, response);
            }
        } catch (error) { await caches.delete(CACHE); throw error; }
    })());
});
self.addEventListener("activate", event => {
    event.waitUntil((async () => {
        // Keep previous version caches for still-open clients. An update never
        // deletes assets underneath another tab with an unsaved working draft.
        await self.clients.claim();
    })());
});
self.addEventListener("message", event => {
    if (event.data === "ACTIVATE_UPDATE") self.skipWaiting();
});
self.addEventListener("fetch", event => {
    const url = new URL(event.request.url);
    if (event.request.method !== "GET" || url.origin !== ROOT.origin) return;
    if (event.request.mode === "navigate" && url.pathname.startsWith(ROOT.pathname)) {
        event.respondWith(caches.open(CACHE).then(cache => cache.match(new URL("index.html", ROOT).href))
            .then(cached => cached || fetch(event.request)));
    } else if (ASSETS.includes(url.href)) {
        event.respondWith(caches.open(CACHE).then(cache => cache.match(event.request))
            .then(cached => cached || fetch(event.request)));
    }
});
