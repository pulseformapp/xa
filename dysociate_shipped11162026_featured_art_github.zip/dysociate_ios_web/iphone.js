/* dλsociate iPhone/iPad installation shell.
 * Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 *
 * DysociateAndroid is the shared editor's historical adapter interface, not an
 * Android dependency. This implementation uses only standard browser APIs.
 * Keeping the adapter outside the export prevents an HTML attachment from
 * depending on our host, service worker or local recovery database.
 */
(() => {
    "use strict";
    const el = id => document.getElementById(id);
    const config = JSON.parse(el("iphone-config").textContent);
    const main = document.querySelector("main");
    main.inert = true;
    let editor, restoring = true, timer, dbPromise, registration;
    let operationBusy = false, preparingImage = false, pendingFile = null, fileUrl = null;
    let writing = Promise.resolve(), recoveryFailed = false, reloadRequested = false;
    const agreement = el("iphone-agreement"), scrollbox = el("iphone-agreement-text");
    const agreementKey = "dysociate-iphone-agreements-" + config.termsVersion;
    let agreementStage = 0, viewingTerms = false;

    function feedback(value) {
        el("iphone-feedback").textContent = value;
        el("iphone-feedback").hidden = !value;
    }
    function database() {
        if (!dbPromise) dbPromise = new Promise((resolve, reject) => {
            const request = indexedDB.open("dysociate-iphone", 1);
            request.onupgradeneeded = () => request.result.createObjectStore("editor");
            request.onsuccess = () => {
                request.result.onversionchange = () => request.result.close();
                resolve(request.result);
            };
            request.onerror = () => reject(request.error || Error("Local storage unavailable"));
            request.onblocked = () => reject(Error("Close another dλsociate tab and try again."));
        });
        return dbPromise;
    }
    async function readRecovery() {
        const db = await database();
        return new Promise((resolve, reject) => {
            const request = db.transaction("editor").objectStore("editor").get("working");
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
    function checkpoint() {
        if (restoring || !editor) return Promise.resolve();
        clearTimeout(timer);
        // Capture NOW, before awaiting IndexedDB. Otherwise a pending save for
        // thread A can accidentally read thread B after Open HTML or New thread.
        // Serialize writes too: the last requested snapshot must commit last.
        const snapshot = JSON.parse(JSON.stringify(editor.checkpoint()));
        const write = async () => {
            const db = await database();
            await new Promise((resolve, reject) => {
                const transaction = db.transaction("editor", "readwrite");
                transaction.oncomplete = resolve;
                transaction.onabort = () => reject(transaction.error || Error("Storage write failed"));
                transaction.onerror = () => {}; // onabort owns the error path
                transaction.objectStore("editor").put(snapshot, "working");
            });
            recoveryFailed = false;
        };
        writing = writing.catch(() => {}).then(write);
        return writing;
    }
    function recoveryWarning() {
        recoveryFailed = true;
        feedback("Local recovery could not be saved. Export HTML to Files before leaving.");
        el("save-state").textContent = "Recovery unavailable · export HTML";
    }
    function preserveDraft() {
        if (restoring) return;
        clearTimeout(timer);
        timer = setTimeout(() => checkpoint().catch(recoveryWarning), 600);
    }
    function clearPrepared() {
        el("iphone-file-ready").hidden = true;
        pendingFile = null;
        if (fileUrl) URL.revokeObjectURL(fileUrl);
        fileUrl = null;
    }
    function prepareFile(payload, name, type) {
        clearPrepared();
        const file = new File([payload], name, {type});
        pendingFile = file;
        fileUrl = URL.createObjectURL(file);
        const link = el("iphone-download");
        link.href = fileUrl; link.download = name;
        el("iphone-file-name").textContent = name + " · " + (file.size / 1000000).toFixed(2) + " MB · prepared copy";
        el("iphone-file-ready").hidden = false;
        return file;
    }
    async function shareFile(file) {
        // Call share() BEFORE any await. Safari requires the tap's transient
        // activation; doing async image/email work first can consume it.
        try {
            if (!navigator.canShare || !navigator.canShare({files:[file]}) || !navigator.share) {
                feedback("This browser cannot share that file type. Tap Download file, then attach it from Files.");
                return false;
            }
            await navigator.share({files:[file], title:document.title});
            feedback("File handed to the share sheet. Check your chosen app to finish.");
            return true;
        } catch (error) {
            feedback(error.name === "AbortError" ? "Sharing canceled. Your thread is still here." :
                "Sharing was unavailable. Download the prepared file and attach it from Files.");
            return false;
        }
    }
    function showAgreement(stage = 0, review = false) {
        viewingTerms = review; agreementStage = stage;
        main.inert = true;
        agreement.toggleAttribute("data-karmic", stage === 1);
        el("iphone-agreement-title").textContent = stage === 0 ? "License agreement" : "Karmic Law";
        scrollbox.textContent = stage === 0 ? el("dysociate-runtime-license").textContent : config.karmic;
        el("iphone-agree").hidden = true;
        el("iphone-agree").textContent = review ? (stage === 0 ? "Next" : "Back to thread") : "Agree";
        el("iphone-disagree").textContent = review ? "Close" : "Disagree";
        el("iphone-agreement-hint").textContent = "Scroll to the end to reveal " + (review ? "Continue." : "Agree.");
        if (!agreement.open) agreement.showModal();
        scrollbox.scrollTop = 0;
        scrollbox.focus();
        requestAnimationFrame(checkScroll);
    }
    function checkScroll() {
        if (!agreement.open) return;
        const reached = scrollbox.scrollTop + scrollbox.clientHeight >= scrollbox.scrollHeight - 4;
        // Once reached, scrolling back to reread must not revoke the button.
        if (reached) {
            el("iphone-agree").hidden = false;
            el("iphone-agreement-hint").textContent = "You have reached the end.";
        }
    }
    function unlock() {
        if (agreement.open) agreement.close();
        main.hidden = false; main.inert = false;
        el("iphone-locked").hidden = true;
    }
    function accepted() {
        try { return localStorage.getItem(agreementKey) === "yes"; } catch (_) { return false; }
    }
    el("iphone-agree").onclick = () => {
        if (el("iphone-agree").hidden) return;
        if (agreementStage === 0) { showAgreement(1, viewingTerms); return; }
        if (!viewingTerms) {
            try { localStorage.setItem(agreementKey, "yes"); }
            catch (_) { feedback("Agreements accepted for this session; browser storage is unavailable."); }
            // A request for persistent storage is a best effort, not a promise
            // that iOS will retain user data forever. Export remains essential.
            navigator.storage?.persist?.().catch(() => {});
        }
        unlock();
    };
    el("iphone-disagree").onclick = () => {
        if (viewingTerms) { unlock(); return; }
        agreement.close(); main.hidden = true; main.inert = true;
        el("iphone-locked").hidden = false;
    };
    agreement.addEventListener("cancel", event => event.preventDefault());
    scrollbox.addEventListener("scroll", checkScroll);
    window.addEventListener("resize", checkScroll);
    el("iphone-review").onclick = () => showAgreement();

    async function installOffline() {
        const state = el("iphone-offline");
        if (!isSecureContext || !("serviceWorker" in navigator)) {
            state.textContent = "Offline installation needs an HTTPS host. HTML editing still works here.";
            return;
        }
        try {
            registration = await navigator.serviceWorker.register("./sw.js", {scope:"./", updateViaCache:"none"});
            const ready = () => { state.textContent = "Ready offline · drafts stay on this device"; };
            const inspect = () => {
                if (registration.active) ready();
                if (registration.waiting) el("iphone-update").hidden = false;
                if (registration.installing) registration.installing.addEventListener("statechange", () => {
                    inspect();
                    if (!registration.active && !registration.waiting && !registration.installing)
                        state.textContent = "Offline setup failed. Reopen online to retry.";
                }, {once:true});
            };
            registration.addEventListener("updatefound", inspect);
            navigator.serviceWorker.addEventListener("controllerchange", () => {
                if (reloadRequested) location.reload(); else inspect();
            });
            inspect();
        } catch (_) { state.textContent = "Offline setup unavailable. Reopen online to retry."; }
    }

    window.DysociateAndroid = {
        feedback,
        // This adapter prepares an RFC 822 draft. Android's app adapter
        // instead hands raw HTML and the message fields to a native mail app.
        emailAsFile: true,
        // Legacy files without editable JSON are deliberately rejected. Never
        // execute or copy arbitrary HTML into this installed app's trusted DOM.
        recoverLegacy() { throw Error("Choose a dλsociate HTML file with editable thread data."); },
        async start(api) {
            editor = api;
            el("iphone-help").onclick = () => el("iphone-help-dialog").showModal();
            el("iphone-help-close").onclick = () => el("iphone-help-dialog").close();
            el("iphone-terms").onclick = () => showAgreement(0, true);
            el("iphone-share-html").onclick = () => editor.saveOnAndroid("share");
            el("iphone-share-ready").onclick = () => {
                if (pendingFile) shareFile(pendingFile);
            };
            el("iphone-download").onclick = () => feedback("Download requested. Check Downloads or Save to Files for the prepared copy.");
            document.addEventListener("input", () => { clearPrepared(); preserveDraft(); });
            document.addEventListener("change", preserveDraft);
            document.addEventListener("visibilitychange", () => {
                if (document.hidden) checkpoint().catch(recoveryWarning);
            });
            window.addEventListener("pagehide", () => checkpoint().catch(recoveryWarning));
            el("iphone-update").onclick = async () => {
                if (operationBusy || preparingImage) return feedback("Wait for the current operation before updating.");
                if (!confirm("Update the app? Your working draft will be recovered after reload. Keep an HTML copy of important threads.")) return;
                try {
                    await checkpoint();
                    if (registration?.waiting) {
                        reloadRequested = true;
                        registration.waiting.postMessage("ACTIVATE_UPDATE");
                    }
                } catch (_) { recoveryWarning(); }
            };
            try {
                const snapshot = await readRecovery();
                if (snapshot) { editor.restore(snapshot); feedback("Recovered your working thread. Export HTML for a separate saved file."); }
            } catch (_) { recoveryWarning(); }
            finally {
                restoring = false;
                if (accepted()) unlock(); else showAgreement();
                installOffline();
            }
        },
        state(busy, imageBusy, draft, changed) {
            operationBusy = busy; preparingImage = imageBusy;
            el("save-state").textContent = busy ? "Working…" : imageBusy ? "Preparing image…" :
                recoveryFailed ? "Recovery unavailable · export HTML" : draft ? "Working draft · on this device" :
                changed ? "Changes on this device · export to keep a file" : "Thread on this device";
            el("iphone-share-html").disabled = busy || imageBusy;
            el("iphone-update").disabled = busy || imageBusy;
            if (!restoring) preserveDraft();
        },
        scheduleSave() { clearPrepared(); preserveDraft(); },
        resetDocument() { clearPrepared(); },
        cleanExport(root) {
            root.querySelectorAll("[data-ios-only]").forEach(node => node.remove());
            root.removeAttribute("data-ios");
            const content = root.querySelector("main");
            content.removeAttribute("inert"); content.removeAttribute("hidden");
        },
        async write(mode, payload, name, type) {
            const file = prepareFile(payload, name, type);
            if (mode === "share" && type === "text/html") {
                await shareFile(file);
                // A share-sheet result does not prove a file was saved or a
                // message delivered. Do not clear the editor's changed flag.
                return {saved:false};
            }
            el("iphone-file-ready").scrollIntoView({block:"nearest"});
            return {saved:false, message:type === "message/rfc822" ?
                "Email draft ready with HTML attached. Tap Share prepared file or Download file. Mail app support varies." :
                "HTML ready. Tap Share prepared file → Save to Files, or Download file."};
        }
    };
})();
