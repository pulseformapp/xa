# dλsociate Live Engineering Specification

**Design baseline · November 11, 2026**

Create a thread in the Windows or Android app and share one HTTPS link. A guest opens it on a phone or computer, reads the conversation, and posts or replies in the browser. The server saves each change and sends it to everyone viewing the thread. Opening the link requires no account, email, or passkey.

## Launch scope

| Surface | First release |
| --- | --- |
| Windows | Use the existing editor to create a live thread. Copy or open the resulting link. Manage the opening post from the app that created it. |
| Android | Use the existing editor to create a live thread. Open the link or send it through the Android share sheet. Manage the opening post from the app that created it. |
| Browser | Open a shared thread, read its history, post, reply, share the link, and delete your own posts. The phone layout is designed for touch. Safari on iPhone is a launch target. |
| Hosting | Serve live threads under `https://dysociate.org/t/<invite>` using Cloudflare Workers Free and SQLite-backed Durable Objects. The public homepage and live routes have separate handlers. |
| Offline | The existing native editors keep their HTML save and export workflows. An offline HTML file is an independent copy. A live thread has one server-side history. |

Launch with text and **Wild West** links. Anyone with the link can read, post, reply, or forward it. There is no public thread directory. The native editors own thread creation for this release. Browser participation includes a post and reply composer inside a thread.

Photo posts can ship with the first release if the text release gates and photo tests pass in time. Locked access, the 30-second recorder, browser thread creation, the homepage link to that editor, and the custom C++ renderer have later phases.

The schedule favors the smallest complete path from app creation to a live browser reply. A deployed service and a real iPhone test are necessary to call that path launch-ready.

## Architecture

```mermaid
flowchart LR
    W["Windows editor"] --> A["Versioned live API"]
    D["Android editor"] --> A
    B["Browser thread page"] <-->|"HTTPS actions and WebSocket updates"| A
    A --> R["SQLite Durable Object for the thread"]
    W --> E["Offline HTML export"]
    D --> E
```

The existing snapshot publisher uploads a whole HTML document. The live service accepts structured thread and post data. Its browser page renders that data using an application-owned template. Threads, replies, and deletion markers use the same records on every client. [Snapshot publisher](dysociate_publishing/README.md)

Use a dedicated live Worker with routes for `dysociate.org/t/*` and `dysociate.org/api/v1/*`. The Worker serves a generic browser shell at a thread URL and routes data requests to the thread's Durable Object. Keep the shell's script and stylesheet within the live route or bundle them with it. Serve invite pages and their API responses with private, no-store caching and a no-referrer policy. Use a generic link preview without post content. [Cloudflare route matching](https://developers.cloudflare.com/workers/configuration/routing/routes/#matching-behavior) · [Routes and custom domains](https://developers.cloudflare.com/workers/configuration/routing/custom-domains/#interaction-with-routes)

Use one SQLite-backed Durable Object per thread. Its database is the source of truth for post ownership, ordering, and deletion. The Worker checks invite format and authenticity before contacting an object. The object checks thread state and permissions for each operation. Future locked threads use the same access check for history, writes, attachments, and live connections. [SQLite storage API](https://developers.cloudflare.com/durable-objects/api/sqlite-storage-api/)

### UI and client boundaries

| Layer | Responsibility |
| --- | --- |
| Service | Validate commands, persist history, enforce access and ownership, assign sequence numbers, and emit committed changes. |
| Client state | Keep credentials, drafts, pending requests, and a local view of loaded posts. Merge changes and recover after a disconnect. Expose actions and state independently of the screen. |
| Presentation | Draw the timeline and composer, show connection and posting status, and call client actions. |

Build the browser thread as a live view using the existing dλsociate visual language. Keep network and merge logic in a module that can run without the DOM. Windows and Android need thin clients for native creation and ownership of the opening post. They open the shared thread in the system browser. The Android editor's existing JavaScript bridge stays scoped to the bundled editor. The future C++ clients implement the same versioned protocol and can run the same behavioral fixtures. [Windows editor](python_pagebuilder/dysociate_gui.py) · [Android editor](dysociate_android/app/src/com/lunasoft/dysociate/EditorActivity.java)

## Access and ownership

- **Invitation.** A live URL is a bearer capability. The invite contains a high-entropy opaque room identifier and a server authentication tag. Generate IDs on the server using a keyed derivation with at least 128 bits of identifier entropy. Validate the tag before routing and compare it in constant time. Include a key version so changing signing keys can preserve previously issued links. Anyone who receives a forwarded Wild West link can enter.
- **Anonymous ownership.** Issue a random 256-bit credential silently. Use an HTTPS-only, HttpOnly, host-only cookie for the browser and a bearer credential in native apps. Persist native credentials with platform-backed protected storage. Store only derived identifiers in the service. Keep the public author identifier scoped to the thread so it cannot correlate a participant across threads.
- **Browser request checks.** Validate same-origin requests for cookie-authenticated writes and WebSocket handshakes. Render user text as text and use a restrictive content security policy. Full invite URLs, credential values, and post text stay out of application logs and analytics.
- **Deletion.** The server verifies ownership from the request credential. A deleted post becomes a marker with an empty body. Keep its ID, original position, and reply links. The creator has the same deletion rights as everyone else. Earlier copies and screenshots may still contain the original text.
- **Ownership across clients.** The app installation that publishes the opening post can delete it through its live-thread action. The browser owns posts it sends and offers **Delete my post** on those posts. An app and a browser on the same device have separate credentials at launch. Clearing browser data or losing an installation credential can remove the ability to delete posts made with it.

### Thread and post data

| Record | Required data |
| --- | --- |
| Thread | Opaque ID, title, creator identifier, creation time, access mode, current sequence, schema version |
| Post | Stable ID, optional parent ID, thread-scoped author ID, display name, body, creation time, creation sequence, last change sequence, optional deletion time |
| Request receipt | Actor, operation ID, normalized request digest, result ID. Receipts contain identifiers and digests. |

Use server timestamps and monotonic integer sequences. Each committed mutation advances the thread sequence once. An opening post and its thread are created atomically. Replies must target a post in the same thread and may target a deletion marker. Order posts by creation sequence. A deletion changes the last change sequence and preserves the creation sequence. The stored post is the canonical record for history and catch-up.

Treat sent text as fixed for launch. Post edits and transfer of authorship across browsers or installs can be designed later if requested.

## Live protocol

Use JSON under `/api/v1`. In this table `{invite}` is the whole opaque invitation and `{id}` is a server-issued post ID.

| Operation | Contract |
| --- | --- |
| `POST /api/v1/session` | Silently get or reuse a browser cookie. A native session request receives a bearer credential over HTTPS. Rate-limit issuance. An existing browser cookie stays stable on refresh. |
| `POST /api/v1/threads` | Take `operationId`, `title`, and one opening post. Return the share URL, the opening post, and the initial sequence. Launch exposes this action in the native editors. |
| `GET /api/v1/threads/{invite}` | Return thread details, the viewer's thread-scoped author ID, the most recent posts, `headSeq`, and a cursor for older history. |
| `GET /api/v1/threads/{invite}/history?before=...` | Page older posts by creation sequence. Return current versions of those posts and the next cursor. |
| `POST /api/v1/threads/{invite}/posts` | Take `operationId`, `body`, optional `displayName`, and optional `parentId`. Return the committed post and its sequence. |
| `DELETE /api/v1/threads/{invite}/posts/{id}` | Return the canonical deletion marker if the caller owns that post. Repeating a successful deletion returns the same marker. |
| `GET /api/v1/threads/{invite}/changes?after=...` | Return canonical post versions with last change sequences above the cursor, sorted by last change sequence, with a continuation cursor. |
| `GET /api/v1/threads/{invite}/live` | Upgrade to a WebSocket. Send a `ready` message with the current sequence, followed by committed `post.changed` messages. HTTP handles writes. |

Use the same `post` object in history, write responses, and live updates. The example shows the WebSocket envelope for a deletion. A creation carries `deletedAt: null`. A deletion keeps the ID and parent and sets `body: null` and `deletedAt`.

```json
{
  "type": "post.changed",
  "seq": 12,
  "post": {
    "id": "p_q7nk",
    "parentId": "p_m1db",
    "authorId": "a_s3df",
    "displayName": "Guest",
    "body": null,
    "createdAt": "2026-11-11T20:00:00Z",
    "createdSeq": 8,
    "updatedSeq": 12,
    "deletedAt": "2026-11-11T20:03:00Z"
  }
}
```

Allocate stable operation IDs before sending creates or posts. Use a deterministic, keyed room ID from the creation actor and operation ID so a retry can find the same Durable Object. The service compares the digest on a repeated operation and returns the original result or a conflict if the payload changed. Commit the receipt and post together. Store the receipt for the life of the associated record. A retry after deletion returns the current marker rather than recreating the original content.

Initial history and its high-water sequence come from the same database read. Open the socket and buffer incoming changes while loading or catching up. Compare `ready.headSeq` with the last applied sequence and request missed changes as needed. A paged catch-up response returns the last covered sequence, with a server watermark when the page covers all remaining changes at that read. A later version of a post can supersede an earlier change during replay. Merge by post ID and last change sequence. After catch-up, apply buffered and future events in sequence. If a gap appears, request changes again. An HTTP post acknowledgment can update the sender's view immediately. It advances the shared replay cursor only after any earlier changes have been reconciled.

Persist each mutation and its sequence before sending a WebSocket event. The catch-up endpoint reads current post records, so it returns a deletion marker for a post deleted during a disconnect. Do not persist deleted body text in a replay log or receipt. Use the Durable Objects WebSocket hibernation API and keep socket attachment metadata small. After backgrounding or losing a connection, retry with backoff and jitter, and catch up when visible again. [Cloudflare WebSocket hibernation](https://developers.cloudflare.com/durable-objects/best-practices/websockets/)

Use a consistent JSON error with a stable code and safe message. Distinguish invalid input, unavailable invite, expired local session, forbidden deletion, operation conflict, and temporary quota or connection failure. The UI keeps a failed submission in the composer. A retry uses the same operation ID for the same content and a new one if the user changes it.

## Browser interaction

- Render the thread in a responsive single column on phones. Keep the composer reachable above the keyboard and safe-area inset. Support keyboard focus, screen readers, zoom, and touch targets.
- Provide a clear **Post**, a **Reply** action on each entry, a reply target indicator, and **Share link**. The delete action appears for the author and asks for confirmation before sending the deletion.
- Show **Connecting**, **Live**, or **Reconnecting** based on the actual connection state. Mark a pending post until the server confirms it. Keep typed text if a post fails or the page is backgrounded.
- Apply incoming updates in place. Keep the reader's scroll position when they are reading older posts and offer a way to jump to new activity. Load older pages without losing reply context.
- Use the system share action where supported and a copyable URL as a fallback. Opening a link from a message brings the reader straight to the thread. Show a useful unavailable state for invalid, unknown, or temporarily unreachable invites.

## Delivery phases

For a release in under a week, target a local text exchange first, then connect the two app editors and use the remaining time for the HTTPS pilot and physical device checks. Route access, availability of an iPhone for testing, and the launch checklist determine when the pilot is ready. Photos have their own acceptance checks and can land independently.

### Phase 0 · Set up the live service

1. Verify the Worker plan is **Free** and record the current production routes. Prepare an isolated test configuration and a production config for the new live routes.
2. Write the versioned API schema and shared fixtures for posts, deletion markers, errors, and socket messages. Create the initial SQLite schema with indexes on creation sequence and last change sequence.
3. Stand up the Worker locally. Keep the live service separate from the snapshot worker and existing HTML exporter.

**Exit:** A local request creates one thread, returns its invite, and reads its opening post. Restart the local runtime and verify the same link and content still work.

### Phase 1 · Prove the live browser thread

1. Implement silent browser ownership, history pagination, text posts, replies, author-only deletion, and WebSocket updates.
2. Build the responsive reader and in-thread composer. Wire connection status, draft preservation, and retries.
3. Exercise the service independently of the UI, then use two independent browser profiles. Verify new posts, replies, and deletion markers reach both screens without a refresh.

**Exit:** Two guests can exchange replies, resume after a forced disconnect, and see the same history. One guest's credential is rejected when used to delete the other guest's post.

### Phase 2 · Connect Windows and Android

1. Add **Create live thread** to the existing editors. Launch accepts a title and one opening text post. Make that input explicit and preserve the editor draft if the server rejects it or the draft contains additional material.
2. When creation is confirmed, show **Open link** and **Share link**. Open the live page in the device's browser. Keep the credential and thread reference for deleting the opening post from the originating app.
3. Build an updated Windows EXE and Android APK with matching source. Verify upgrades from the last builds and exercise the existing offline save and export paths.

**Exit:** A Windows-created link and an Android-created link both open in Safari on a real iPhone. Each app can manage its own opening post. An iPhone guest can reply, and a second connected viewer sees the reply live.

### Phase 3 · Pilot and first release

1. Deploy an isolated HTTPS test endpoint and exercise links from a real messaging app. Check the browser and Android flows with slow and interrupted connections.
2. Exercise quota, storage, rate limiting, and service-unavailable responses. Confirm the client keeps failed work as a draft. Confirm unauthenticated writes and cross-thread requests are rejected.
3. Deploy the live routes after staging passes. Smoke-test the public homepage and both live URL prefixes over HTTPS. Verify protected routes fail closed where that route setting applies. Rehearse reverting a Worker version against the stored schema without dropping thread data.

**Exit:** The launch checklist below passes on the final build and the live host. Prioritize this text release if the schedule compresses.

### Phase 4 · Photos and recorded reels

- **Photos.** Add a picker to the app and browser composer. Constrain image types and byte size, preview locally, and attach the upload to one committed post. Serve attachments through the same thread access check. Photos can move into the pilot if real-device upload, rendering, deletion, and quota tests pass.
- **Reels.** Replace the video picker with **Record reel → Preview → Use clip or Retake**. Capture in the app and stop at 30 seconds. Enforce byte and duration limits on the service and test playback across supported browsers. Validate Safari recording and playback on an iPhone before enabling browser recording. Existing offline files can still be opened and played.
- Keep media bytes out of WebSocket messages. Send the attachment reference when the post is committed. Evaluate Workers KV Free for bounded media storage and account for read-after-write delay before choosing it. The server authorizes media reads using the canonical thread and post state, including after deletion. [Workers KV pricing](https://developers.cloudflare.com/kv/platform/pricing/) · [KV visibility after writes](https://developers.cloudflare.com/kv/concepts/how-kv-works/#consistency)

### Phase 5 · Optional locked access

Keep Wild West as the default. A locked thread can support a creator-chosen thread code or **Request to join**. Approval is the preferred first option. The request appears on the creator's thread page and stays pending when they are away. A guest sees their approval on the page, then receives full read, post, and reply access. Use the creator's private app credential or a scoped browser handoff to approve requests. Keep access enforcement on every thread endpoint and live connection. Author-only deletion applies in both modes.

### Phase 6 · Browser creation and C++ clients

1. Connect the existing browser editor to the thread-creation API so iPhone users can start new live threads directly. Add the editor entry point to the public homepage when that flow is ready. [Existing iPhone web editor](dysociate_ios_web/README.md)
2. Build the native Windows and Android renderer in C++. The app draws its own interface on the CPU. Use native window APIs to present the pixel buffer and operating system services for input, accessibility, and capture. Measure scrolling and text entry on a real Android phone and Windows machine. Run the same protocol fixtures against the new clients before replacing the existing interfaces.

### Phase 7 · Direct creation in the native composer

Let **Create thread** submit from the C++ preview. Keep the form responsive
while the existing client creates the thread. Show failures in the composer
and keep its draft available to retry. On success, use the app's existing
link and owner actions. Carry in the access mode and attachment selected in
the live-thread editor. Verify retry after a lost response, duplicate-click
handling, and compatibility with the existing Windows and Android clients.

### Phase 8 · Open the native composer first

In the native preview builds, **Create live thread** opens the C++ composer.
The main action creates a text thread with Wild West access. **More options**
carries the draft into the full live-thread dialog, which includes history,
owner actions, and the access and attachment controls available on the selected
service. Keep retries for saved Android drafts with a lock or attachment in
that dialog so the original access and media can be restored before submission.

### Phase 9 · Open and share a newly created link

After the native composer creates a text thread, show the saved link on a
dedicated screen. Offer **Open link**, **Copy link**, and on Android **Share
link**. **Manage thread** opens the existing owner controls. The result screen
uses the URL already saved by the client, so these actions can be repeated
without creating another thread.

### Phase 10 · Chat in the Windows and Android apps

**Open live link** accepts public or pilot guest invites and opens the existing
live web client inside the app. **Open link** after creation also uses the
embedded viewer. People using the app and browser share the same thread,
including locked access, replies, ownership, and reconnect. **Open in browser**
hands off the guest link. The embedded session owns posts made there. The
creation credential remains with the native owner controls.

Use a separate WebView with no offline editor bridge. Keep navigation scoped
to the one invite and use the existing live service. Windows and Android can
create reels through the existing recorder. For recording a reel from a
received live thread, use the browser.

### Phase 11 · Save and share offline threads

Save a live thread's complete available history and attachments as portable
HTML. Open the saved copy from the app without a connection, add local replies,
and share the updated HTML file. Keep live and offline changes independent.
Each export creates a separate dated copy. Confirm the live sequence before
and after collecting history and attachments. Publish the file only after
the complete copy is ready. Require a warning before saving a locked thread
because a recipient of the HTML can read the copy.

### Phase 12 · Final UI approval

The [release engineering specification](dysociate-release-engineering-spec.md)
proposes the remaining feature phases and release gates. Test both paths first.
Begin final visual polish only after Luna explicitly approves it.

## Launch checklist

| Check | Pass condition |
| --- | --- |
| Tap the link | A real iPhone opens a shared link from messaging in Safari and immediately shows the Wild West thread. A guest can participate without installing the app. |
| Live update | A post from one viewer appears for another with the same link without reloading. Exercise both directions with two isolated clients. Aim for under one second from server confirmation to visible update on a healthy connection and record the observed times. |
| Reconnect | Disconnect or background one client, post from the other, then return. The first client shows all missed changes in order without duplicates. |
| Ownership | Guests can delete their own posts. Another guest and the thread creator are denied when attempting that deletion. Opening-post deletion works from the app installation that published it. |
| History | A new guest can page through the complete surviving history. A deleted parent appears as a marker and its replies remain visible and actionable. Deleted body text is absent from history and catch-up responses. |
| Retry | Repeat the same create or post request after a simulated lost response. Exactly one thread or post exists. An altered payload with the same operation ID receives a conflict. |
| Isolation | A separate thread receives zero events from this one. Invalid invite tags, forged authorship, and a parent ID from another thread are rejected. |
| Mobile layout | The composer, post action, and reply target stay usable with Safari's keyboard open. The page works in portrait and with larger text. |
| Cost and availability | Confirm Workers Free and SQLite-backed Durable Objects on the target account. Simulate blocked writes and limited reads. The client shows a recoverable error and preserves the draft. |
| Existing workflow | Open and save an existing offline HTML thread in each app. Check the public homepage and its existing asset links after adding live routes. |

## Free-plan operating limits

Keep the service on Workers Free and use the included SQLite-backed Durable Objects. Cloudflare caps Free Worker requests at 100,000 per day across the account and limits SQLite Durable Objects by requests, runtime, rows, and storage. Check account usage before the pilot. The published Free-plan storage limits are 1 GB per object and 5 GB across the account. Reaching a quota can interrupt the service. The design does not require an R2 subscription. [Workers limits](https://developers.cloudflare.com/workers/platform/limits/) · [Durable Objects pricing](https://developers.cloudflare.com/durable-objects/platform/pricing/) · [Durable Objects storage limits](https://developers.cloudflare.com/durable-objects/platform/limits/)

Proposed starting bounds are a 120-character title, a 48-character display name, a 4 KiB text body measured in UTF-8, 50 posts per history page, and 100 records per catch-up page. Validate payload size before buffering. Apply launch rate limits to session creation, new threads, and posting. Use per-thread checks for strict limits. Edge rate limits can reduce bursts, and Cloudflare documents them as approximate per location. Favor preserving existing history when capacity is reached and reject new writes with a clear retry or capacity message. [Cloudflare rate limiting](https://developers.cloudflare.com/workers/runtime-apis/bindings/rate-limit/)
