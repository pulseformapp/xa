// Copyright (c) 2026 Luna Love ~ LunaSoft
// SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
//
// Exercise the packaged WebView and native Android document provider together.
// Run against a dedicated emulator with a -DebugWebView build installed.
// The fixture directory must contain Dysociate-Android-QA.html and Photo-QA.png.
import assert from "node:assert/strict";
import {execFileSync} from "node:child_process";
import {createHash} from "node:crypto";
import fs from "node:fs";
import path from "node:path";

const [adb, device, fixtureDirectory, upgradeApk] = process.argv.slice(2);
assert.ok(adb && fixtureDirectory && device?.startsWith("emulator-"),
    "Usage: node test_android.mjs <adb.exe> <emulator-serial> <fixture-directory> [loopback-upgrade.apk|--live|--browser-routing|--pilot|--pilot-media|--pilot-locked]");
const app = "com.lunasoft.dysociate";
const liveMedia = upgradeApk === "--pilot-media";
const liveLocked = upgradeApk === "--pilot-locked";
const browserRouting = upgradeApk === "--browser-routing";
const pilot = liveLocked || liveMedia || upgradeApk === "--pilot";
const liveOrigin = pilot ? "https://dysociate-live-pilot.pulseform.workers.dev" : "http://127.0.0.1:8795";
const filename = "Dysociate-Android-QA.html";
const originalPath = "/sdcard/Download/" + filename;
const targetUrl = "https://appassets.androidplatform.net/index.html";
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
const command = (...args) => execFileSync(adb, ["-s", device, ...args], {encoding:"utf8"}).trim();
const shell = text => command("shell", "-T", text);
const quote = text => "'" + text.replaceAll("'", "'\\''") + "'";
// exec-out keeps stdout binary on Windows. Even shell -T can add CR bytes
// in the host adb process and make an unchanged file appear different.
const readFile = name => execFileSync(adb, ["-s", device, "exec-out", "cat " + quote(name)], {encoding:"utf8"});
function checkContents(name, expected) {
    const hash = value => createHash("sha256").update(value).digest("hex");
    assert.equal(hash(readFile(name)), hash(expected), "External file bytes are preserved");
}
let socket;
let debuggerPort;
let nextId = 0;
const pending = new Map();

async function until(predicate, label, attempts = 60) {
    for (let attempt = 0; attempt < attempts; attempt++) {
        if (await predicate()) return;
        await pause(200);
    }
    throw Error("Timed out waiting for " + label);
}

function ui() {
    let xml;
    try {
        // Never reuse a previous screen's XML if Android is still animating
        // the next window and its accessibility tree is not available yet.
        xml = shell("rm -f /sdcard/dysociate-ui.xml; uiautomator dump /sdcard/dysociate-ui.xml >/dev/null 2>&1; cat /sdcard/dysociate-ui.xml 2>/dev/null");
    } catch (_) { return []; }
    return Array.from(xml.matchAll(/<node ([^>]+)>/g), match =>
        Object.fromEntries(Array.from(match[1].matchAll(/([\w-]+)="([^"]*)"/g), item => [item[1], item[2]])));
}

function tap(nodes, predicate, description) {
    const node = nodes.find(predicate);
    assert.ok(node, description + " is visible");
    const [left, top, right, bottom] = node.bounds.match(/\d+/g).map(Number);
    shell("input tap " + ((left + right) >> 1) + " " + ((top + bottom) >> 1));
}

const agrees = node => node.text?.toLowerCase() === "i agree";
function scrollToAgreement(nodes) {
    for (let attempt = 0; !nodes.some(agrees) && attempt < 8; attempt++) {
        const scroll = nodes.find(node => node.class === "android.widget.ScrollView");
        assert.ok(scroll, "The agreement has a scroll area");
        const [left, top, right, bottom] = scroll.bounds.match(/\d+/g).map(Number);
        const x = Math.round((left + right) / 2);
        const start = Math.round(bottom - (bottom - top) * 0.12);
        const end = Math.round(top + (bottom - top) * 0.12);
        shell("for i in $(seq 1 10); do input swipe " + x + " " + start + " " + x + " " + end + " 110; done");
        nodes = ui();
    }
    return nodes;
}

async function launch() {
    command("shell", "am", "start", "-W", "-n", app + "/.EditorActivity");
    let nodes;
    await until(() => { nodes = ui(); return nodes.some(node => node.text === "01 / LICENSE AGREEMENT"); }, "license screen", 12);
    assert.ok(nodes.some(node => node.text === "01 / LICENSE AGREEMENT"));
    assert.ok(!nodes.some(agrees), "License acceptance starts hidden");
    // Alt+Down is the native ScrollView end shortcut. Fall back to touch
    // scrolling on emulator images whose shell does not expose key chords.
    shell("input keycombination 57 20");
    nodes = scrollToAgreement(ui());
    tap(nodes, agrees, "License acceptance at the end");
    await until(() => { nodes = ui(); return nodes.some(node => node.text?.includes("~ as above so below ~")); }, "Karmic Law", 12);
    assert.ok(nodes.some(node => node.text?.includes("~ as above so below ~")));
    tap(scrollToAgreement(nodes), agrees, "Karmic Law acceptance");

    const processId = shell("pidof " + app);
    if (debuggerPort) command("forward", "--remove", "tcp:" + debuggerPort);
    debuggerPort = command("forward", "tcp:0", "localabstract:webview_devtools_remote_" + processId);
    let target;
    await until(async () => {
        try {
            const pages = await (await fetch("http://127.0.0.1:" + debuggerPort + "/json")).json();
            target = pages.find(page => page.url === targetUrl);
            return !!target;
        } catch (_) { return false; }
    }, "QA WebView");
    socket = new WebSocket(target.webSocketDebuggerUrl);
    await new Promise((resolve, reject) => {
        socket.addEventListener("open", resolve, {once:true});
        socket.addEventListener("error", reject, {once:true});
    });
    socket.addEventListener("message", event => {
        const reply = JSON.parse(event.data);
        if (!pending.has(reply.id)) return;
        const request = pending.get(reply.id);
        pending.delete(reply.id);
        if (reply.error) request.reject(Error(reply.error.message));
        else request.resolve(reply.result);
    });
    await until(async () => await evaluate("typeof DysociateAndroid !== 'undefined' && document.querySelector('#mobile-open').onclick !== null"),
        "editor initialization");
    // IndexedDB restoration is asynchronous even after the buttons bind.
    await pause(1200);
}

async function evaluate(expression) {
    const id = ++nextId;
    const reply = await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
            pending.delete(id);
            reject(Error("WebView evaluation timed out."));
        }, 15_000);
        pending.set(id, {
            resolve(value) { clearTimeout(timeout); resolve(value); },
            reject(error) { clearTimeout(timeout); reject(error); },
        });
        socket.send(JSON.stringify({id, method:"Runtime.evaluate",
            params:{expression, awaitPromise:true, returnByValue:true}}));
    });
    if (reply.exceptionDetails) throw Error(reply.exceptionDetails.exception?.description || reply.exceptionDetails.text);
    return reply.result.value;
}

const click = selector => evaluate("document.querySelector(" + JSON.stringify(selector) + ").click()");
const status = () => evaluate("document.querySelector('#comment-status').textContent");
const token = () => evaluate("DysociateDevice.documentToken()");
const canSave = () => evaluate("DysociateDevice.canAutoSave()");
async function type(selector, text) {
    await evaluate("(() => { const input = document.querySelector(" + JSON.stringify(selector) +
        "); input.value = " + JSON.stringify(text) + "; input.dispatchEvent(new Event('input', {bubbles:true})); })()");
}

async function choose(name) {
    const matches = node => node.text === name || node["content-desc"]?.startsWith(name + ",");
    let nodes;
    await until(() => {
        nodes = ui();
        return nodes.some(matches) || nodes.some(node => node["content-desc"] === "Show roots");
    }, "file picker", 12);
    if (!nodes.some(matches)) {
        tap(nodes, node => node["content-desc"] === "Show roots", "Picker navigation");
        await until(() => { nodes = ui(); return nodes.some(node => node.text === "Downloads"); }, "storage locations", 12);
        tap(nodes, node => node.text === "Downloads", "Downloads");
    }
    await until(() => { nodes = ui(); return nodes.some(matches); }, "file " + name, 12);
    tap(nodes, matches, name);
}

async function savePicker() {
    let nodes;
    await until(() => { nodes = ui(); return nodes.some(node => node.text?.toLowerCase() === "save"); }, "save picker", 12);
    return nodes;
}

async function openThread() {
    await click("#mobile-open");
    let launchOptions;
    const edit = node => node.text === "Open HTML in dλsociate";
    await until(() => { launchOptions = ui(); return launchOptions.some(edit); }, "Launch menu", 12);
    tap(launchOptions, edit, "Open HTML in dλsociate");
    await choose(filename);
    await until(async () => (await status()).startsWith("Opened "), "HTML import");
    await until(canSave, "writable document binding");
}

async function checkpoint() {
    return evaluate("(async () => { const db = await new Promise((resolve,reject) => {" +
        "const request=indexedDB.open('dysociate',1);request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);" +
        "}); return await new Promise((resolve,reject) => {const r=db.transaction('editor').objectStore('editor').get('working');" +
        "r.onsuccess=()=>{db.close();resolve(r.result)};r.onerror=()=>reject(r.error)}); })()");
}

async function restart() {
    socket.close();
    shell("am force-stop " + app);
    await launch();
}

async function nativeScreen(predicate, label) {
    let nodes;
    await until(() => { nodes = ui(); return nodes.some(predicate); }, label, 12);
    return nodes;
}

const named = text => node => node.text?.toLowerCase() === text.toLowerCase();

function networkRestored() {
    const status = shell("dumpsys connectivity");
    const active = status.match(/Active default network: (\d+)/)?.[1];
    return active && status.split("\n").some(line => line.includes("NetworkAgentInfo{network{" + active + "}")
        && /\bVALIDATED\b/.test(line));
}

async function selectLiveThread(title) {
    await click("#mobile-live");
    tap(await nativeScreen(named("My threads"), "My threads action"), named("My threads"), "My threads");
    const savedTitle = node => node.text?.includes(". " + title);
    tap(await nativeScreen(savedTitle, "saved live thread"), savedTitle, title);
}

async function checkLiveUpgrade() {
    await type("#comment-body", "Offline draft across APK update");
    await until(async () => (await checkpoint())?.body === "Offline draft across APK update", "upgrade draft checkpoint");
    if (!pilot && !browserRouting && upgradeApk !== "--live") {
        socket.close();
        command("install", "-r", upgradeApk);
        await launch();
        assert.equal(await evaluate("document.querySelector('#comment-body').value"), "Offline draft across APK update");
        console.log("PASS APK upgrade keeps the prior version's draft");
    }

    const title = "AndroidLive" + Date.now();
    const opening = "PublicOpeningFromAndroid";
    await click("#mobile-live");
    const edit = node => node.class === "android.widget.EditText";
    const create = node => named("Create")(node) || named("Create thread")(node);
    let nodes = await nativeScreen(edit, "native live composer");
    let fields = nodes.filter(edit);
    tap(fields.slice(0, 1), edit, "live title");
    shell("input text " + title);
    shell("input keyevent 4");
    nodes = await nativeScreen(create, "live composer buttons");
    fields = nodes.filter(edit);
    tap(fields.slice(1, 2), edit, "live opening post");
    shell("input text " + opening);
    shell("input keyevent 4");
    if (pilot) {
        shell("cmd connectivity airplane-mode enable");
        shell("svc wifi disable");
        try {
            tap(await nativeScreen(create, "Create while offline"), create, "Create while offline");
            nodes = await nativeScreen(node => node.text?.includes("Could not reach the live service"), "network error");
            assert.ok(nodes.some(named(opening)), "The opening post stays in the form");
            console.log("PASS Android retains the live draft when connectivity is interrupted");
        } finally {
            shell("cmd connectivity airplane-mode disable");
            shell("svc wifi enable");
        }
        await until(networkRestored, "Android validated its network after reconnect", 120);
        // The test emulator applies these settings to the retry and HTTPS browser handoff.
        command("emu", "network", "delay", "200");
        command("emu", "network", "speed", "edge");
    }
    tap(await nativeScreen(create, "Create button"), create, "Create");
    await nativeScreen(named("Share link"), "live thread actions");

    const prefs = shell("run-as " + app + " cat shared_prefs/" + (pilot ? "live-pilot" : "live-local") + ".xml");
    const record = prefs.split("\n").find(line => line.includes(title));
    const link = record?.replaceAll("\\/", "/").match(/https?:\/\/[A-Za-z0-9.:-]+\/t\/[A-Za-z0-9_.-]+/)?.[0];
    assert.ok(link, "native client saved the validated link");
    assert.equal(new URL(link).origin, liveOrigin);
    assert.ok((await (await fetch(link)).text()).includes('id="composer"'));
    const api = link.replace("/t/", "/api/v1/threads/");
    const snapshot = await (await fetch(api)).json();
    assert.equal(snapshot.posts[0].body, opening);
    assert.equal(snapshot.posts.length, 1);
    if (browserRouting) {
        const done = named("Done");
        tap(await nativeScreen(done, "thread result"), done, "Done");
        return title;
    }
    tap(await nativeScreen(named("Share link"), "Share link action"), named("Share link"), "Share link");
    await until(() => shell("dumpsys activity activities").includes("ChooserActivity"), "live URL share sheet");
    shell("input keyevent 4");
    assert.equal(await evaluate("document.querySelector('#comment-body').value"), "Offline draft across APK update");
    console.log("PASS Android creates a live link and opens the share sheet without changing the offline draft");

    // Restart before using ownership to exercise persistent credentials and history.
    await restart();
    await selectLiveThread(title);
    tap(await nativeScreen(named("Delete opening post"), "opening post action"), named("Delete opening post"), "Delete opening post");
    tap(await nativeScreen(named("Delete"), "delete confirmation"), named("Delete"), "Delete");
    await until(async () => (await (await fetch(api)).json()).posts[0].deletedAt, "opening post deletion");
    tap(await nativeScreen(named("Close"), "live composer close"), named("Close"), "Close");
    await type("#comment-body", "");
    console.log("PASS Android can delete its opening post after a restart");
    return title;
}

async function checkLiveMedia() {
    async function recordClip(retakeOnce) {
        const start = named("Record");
        const stop = named("Stop");
        const use = named("Use clip");
        for (let attempt = 0; attempt < (retakeOnce ? 2 : 1); attempt++) {
            tap(await nativeScreen(start, "Android camera"), start, "Record");
            await pause(2300);
            tap(await nativeScreen(stop, "Android recording"), stop, "Stop");
            const preview = await nativeScreen(use, "Android reel preview");
            if (retakeOnce && attempt === 0) tap(preview, named("Retake"), "Retake");
            else tap(preview, use, "Use clip");
        }
    }
    for (const type of ["image/jpeg", "video/mp4"]) {
        await click("#mobile-live");
        const create = named("Create");
        const edit = node => node.class === "android.widget.EditText";
        const title = "AndroidMedia" + Date.now();
        const nodes = await nativeScreen(create, "native live composer");
        tap(nodes.filter(edit).slice(0, 1), edit, "live title");
        shell("input text " + title);
        shell("input keyevent 4");
        if (type === "image/jpeg") {
            const add = named("Add photo");
            tap(await nativeScreen(add, "Add photo"), add, "Add photo");
            await choose("Photo-QA.png");
            await nativeScreen(named("Photo ready to post."), "photo preview");
        } else {
            const record = named("Record reel");
            tap(await nativeScreen(record, "Record reel"), record, "Record reel");
            await recordClip(true);
            await nativeScreen(named("Reel ready to post."), "return to live composer");
        }
        tap(await nativeScreen(create, "Create with attachment"), create, "Create with attachment");
        await nativeScreen(named("Share link"), "live thread actions");
        const prefs = shell("run-as " + app + " cat shared_prefs/live-pilot.xml");
        const link = prefs.split("\n").find(line => line.includes(title))
            ?.replaceAll("\\/", "/").match(/https:\/\/[A-Za-z0-9.:-]+\/t\/[A-Za-z0-9_.-]+/)?.[0];
        assert.ok(link, "saved live link for the attachment");
        assert.equal(new URL(link).origin, liveOrigin);
        const api = link.replace("/t/", "/api/v1/threads/");
        const snapshot = await (await fetch(api)).json();
        assert.equal(snapshot.posts[0].media.type, type);
        const attachment = await fetch(api + "/media/" + snapshot.posts[0].id);
        assert.equal(attachment.status, 200);
        assert.equal(attachment.headers.get("content-type"), type);
        tap(await nativeScreen(named("Done"), "Done"), named("Done"), "Done");
        console.log("PASS Android captured or selected, previewed, and posted " + type);
    }
    await click("#mobile-record");
    await recordClip(false);
    await until(async () => (await status()).includes("Reel attached"), "reel delivered to offline composer");
    assert.equal(await evaluate("document.querySelector('#video-attachment').hidden"), false);
    await click("#remove-video");
    console.log("PASS Android recorder also attaches to the offline editor");
}

async function checkLockedCreation() {
    const title = "AndroidLocked" + Date.now();
    const edit = node => node.class === "android.widget.EditText";
    const lock = node => node.text?.startsWith("Locked");
    await click("#mobile-live");
    let nodes = await nativeScreen(lock, "locked choice");
    assert.equal(nodes.find(lock).checked, "false", "Wild West is the default");
    tap(nodes.filter(edit).slice(0, 1), edit, "title");
    shell("input text " + title);
    shell("input keyevent 4");
    nodes = await nativeScreen(lock, "locked composer");
    tap(nodes.filter(edit).slice(1, 2), edit, "opening");
    shell("input text PrivateAndroidOpening");
    shell("input keyevent 4");
    tap(await nativeScreen(lock, "locked choice"), lock, "enable locked mode");
    const passkey = node => node.text === "Passkey (optional)";
    tap(await nativeScreen(passkey, "optional passkey"), passkey, "optional passkey");
    shell("input text SyntheticAndroidPasskey");
    shell("input keyevent 4");
    tap(await nativeScreen(named("Create"), "Create locked thread"), named("Create"), "Create");
    const manage = named("Manage requests");
    nodes = await nativeScreen(manage, "creator action");
    const prefs = shell("run-as " + app + " cat shared_prefs/live-pilot.xml");
    const link = prefs.split("\n").find(line => line.includes(title))?.replaceAll("\\/", "/")
        .match(/https:\/\/[A-Za-z0-9.:-]+\/t\/l-[A-Za-z0-9_.-]+/)?.[0];
    assert.ok(link, "only the guest link is persisted");
    assert.equal(prefs.includes("SyntheticAndroidPasskey"), false);
    assert.equal(prefs.includes("#creator="), false);
    const api = link.replace("/t/", "/api/v1/threads/");
    assert.equal((await fetch(api)).status, 403);
    assert.deepEqual(await (await fetch(api + "/access")).json(), {state:"unrequested", role:"guest", passkey:true});
    const session = await fetch(liveOrigin + "/api/v1/session", {method:"POST",
        headers: {Origin:liveOrigin, "Content-Type":"application/json"}, body: JSON.stringify({client:"browser"})});
    assert.equal(session.status, 200);
    const guest = session.headers.get("Set-Cookie").split(";")[0];
    const guestName = "Android QA guest";
    const joining = await fetch(api + "/join", {method:"POST",
        headers:{Origin:liveOrigin, Cookie:guest, "Content-Type":"application/json"}, body:JSON.stringify({name:guestName})});
    assert.equal((await joining.json()).state, "pending");
    assert.equal((await fetch(api, {headers:{Cookie:guest}})).status, 403);
    tap(nodes, manage, "Manage requests");
    const guestRow = node => node.text?.startsWith(guestName);
    tap(await nativeScreen(guestRow, "pending guest"), guestRow, "pending guest");
    tap(await nativeScreen(named("Approve"), "Approve"), named("Approve"), "Approve");
    await nativeScreen(node => node.text?.startsWith("No pending requests."), "approval saved");
    const approved = await fetch(api, {headers:{Cookie:guest}});
    assert.equal(approved.status, 200);
    assert.equal((await approved.json()).posts[0].body, "PrivateAndroidOpening");
    assert.match(shell("dumpsys activity activities"), /topResumedActivity=.*com\.lunasoft\.dysociate/);
    console.log("PASS Android locked creation, protected snapshot, and in-app approval of a pending browser guest");
}

async function checkLiveBrowser(title) {
    await selectLiveThread(title);
    const inApp = named("Open in app");
    tap(await nativeScreen(inApp, "explicit in-app option"), inApp, "Open in app");
    const back = named("Back to editor");
    tap(await nativeScreen(back, "in-app live viewer"), back, "Back to editor");
    await selectLiveThread(title);
    const browser = named("Open in browser");
    tap(await nativeScreen(browser, "browser action"), browser, "Open in browser");
    await until(() => /topResumedActivity=.*com\.android\.chrome/.test(shell("dumpsys activity activities")),
        "system browser launch");
    // Chrome's first-run screen can consume the VIEW intent before dumpsys
    // reports it. ActivityTaskManager still records the dispatch to Chrome.
    const started = shell("logcat -d -t 2500 -s ActivityTaskManager").split("\n");
    assert.ok(started.some(line => line.includes("act=android.intent.action.VIEW") && line.includes("dat=" + liveOrigin + "/")
        && line.includes("cmp=com.android.chrome")), "Android logged the link dispatch");
    console.log("PASS Android opens live threads in Chrome by default and the embedded viewer on request");
}

function copyShared(pattern, destination) {
    const candidates = shell("run-as " + app + " find cache/shared -type f -name " + quote(pattern))
        .split("\n").map(value => value.trim()).filter(Boolean);
    assert.ok(candidates.length, "Shared attachment exists");
    const bytes = execFileSync(adb, ["-s", device, "exec-out", "run-as " + app + " cat " + quote(candidates.at(-1))]);
    fs.writeFileSync(path.join(fixtureDirectory, destination), bytes);
}

async function checkSharing() {
    await click("#share-page");
    await click("#mobile-share");
    await until(() => shell("dumpsys activity activities").includes("ChooserActivity"), "HTML share sheet");
    copyShared("*.html", "shared.html");
    shell("input keyevent 4");
    await until(async () => !(await evaluate("document.querySelector('#save-html').disabled")), "share completion");
    await click("#mobile-email-file");
    await until(() => shell("dumpsys activity activities").includes("ChooserActivity"), "email share sheet");
    copyShared("*.eml", "shared.eml");
    shell("input keyevent 4");
    await until(async () => !(await evaluate("document.querySelector('#save-html').disabled")), "email completion");
}

async function checkPreview() {
    const previousToken = await token();
    const original = readFile(originalPath);
    await type("#comment-body", "Unposted preview draft");
    await click("#mobile-preview");
    assert.equal(await evaluate("document.querySelector('#mobile-preview-dialog').open"), true);
    assert.ok((await evaluate("document.querySelector('#mobile-preview-content').textContent")).includes("Android photo reply"));
    assert.equal(await evaluate("!!document.querySelector('#mobile-preview-content img[src^=\"data:image/\"]')"), true);
    assert.equal(await evaluate("document.querySelector('#mobile-preview-draft').hidden"), false);
    shell("input keyevent 4");
    await until(async () => !(await evaluate("document.querySelector('#mobile-preview-dialog').open")), "Back closes preview");
    assert.equal(await evaluate("document.querySelector('#comment-body').value"), "Unposted preview draft");
    assert.equal(await token(), previousToken);
    checkContents(originalPath, original);
    await type("#comment-body", "");
}

async function run() {
    shell("am force-stop " + app);
    await launch();
    if (liveLocked) {
        await checkLockedCreation();
        return;
    }
    if (liveMedia) {
        await checkLiveMedia();
        return;
    }
    const liveTitle = upgradeApk ? await checkLiveUpgrade() : null;
    if (browserRouting) {
        await checkLiveBrowser(liveTitle);
        return;
    }
    if (pilot) {
        await checkLiveBrowser(liveTitle);
        console.log("PASS Android pilot HTTPS suite");
        return;
    }
    await openThread();
    assert.equal(await evaluate("typeof window.untrustedAttachment"), "undefined");
    await click('[data-reply-to="desktop-root"]');
    await type("#comment-body", "Android photo reply 🚀");
    await click("#mobile-photo");
    await choose("Photo-QA.png");
    await until(async () => (await status()).startsWith("Image ready"), "photo");
    await click("#post-submit");
    await until(async () => (await status()).startsWith("Saved "), "automatic save");
    assert.ok(readFile(originalPath).includes("Android photo reply 🚀"));
    console.log("PASS desktop HTML import, photo picker, reply, and automatic save");

    const savedToken = await token();
    await click("#mobile-copy");
    await savePicker();
    shell("input keyevent 4");
    await until(async () => (await status()).startsWith("Save canceled"), "canceled Save a copy");
    assert.equal(await token(), savedToken);
    assert.ok(await canSave());
    console.log("PASS canceling Save a copy keeps the active document");

    await checkPreview();
    console.log("PASS preview shows the posted thread and preserves its draft and save location");

    await checkSharing();
    console.log("PASS HTML and attached email draft reach the native share sheet");

    await click('[data-reply-to="desktop-root"]');
    await type("#comment-body", "Recovered Android 16 reply");
    await pause(1000);
    shell("input keyevent 4");
    let exitDialog;
    await until(() => { exitDialog = ui(); return exitDialog.some(node => node.text === "Save before closing?"); }, "Back prompt", 12);
    assert.ok(exitDialog.some(node => node.text === "Save before closing?"));
    tap(exitDialog, node => node.text?.toLowerCase() === "keep editing", "Keep editing");
    await until(async () => (await checkpoint())?.body === "Recovered Android 16 reply", "draft checkpoint");
    await restart();
    assert.equal(await evaluate("document.querySelector('#comment-body').value"), "Recovered Android 16 reply");
    assert.ok(await canSave(), "Recovered draft reconnects to the original URI");
    assert.equal(await token(), savedToken);
    await click("#post-submit");
    await until(async () => (await status()).startsWith("Saved "), "save after restart");
    assert.ok(readFile(originalPath).includes("Recovered Android 16 reply"));
    const latestToken = await token();
    assert.notEqual(latestToken, savedToken);
    console.log("PASS Android Back prompt and saving to the same file after process restart");

    // Simulate a process interruption between the native write completing and
    // the corresponding recovery checkpoint. The older epoch must stay unbound.
    await pause(1200);
    await evaluate("(async () => {const snapshot=" + JSON.stringify(await checkpoint()) +
        ";snapshot.documentToken=" + JSON.stringify(savedToken) + ";" +
        "const db=await new Promise(r=>{const q=indexedDB.open('dysociate',1);q.onsuccess=()=>r(q.result)});" +
        "await new Promise((r,j)=>{const t=db.transaction('editor','readwrite');" +
        "t.objectStore('editor').put(snapshot,'working');t.oncomplete=r;t.onabort=()=>j(t.error)});db.close()})()");
    await restart();
    assert.ok(!await canSave(), "Older checkpoint cannot bind to a newer saved file");
    console.log("PASS interrupted-save recovery cannot overwrite a newer file");

    await openThread();
    const external = readFile(originalPath) + "\n<!-- changed outside the app -->\n";
    const externalFixture = path.join(fixtureDirectory, "external-change.html");
    fs.writeFileSync(externalFixture, external);
    command("push", externalFixture, "/sdcard/Download/Dysociate-External-QA.html");
    // Write into the same file. ADB push replaces the inode on some Android
    // images and invalidates the downloads provider's existing document ID.
    shell("cat /sdcard/Download/Dysociate-External-QA.html > " + quote(originalPath));
    await click('[data-reply-to="desktop-root"]');
    await type("#comment-body", "Local reply after external edit");
    await click("#post-submit");
    await until(async () => (await status()).includes("changed elsewhere"), "external-change protection");
    checkContents(originalPath, external);
    assert.ok(!await canSave());
    await click("#mobile-copy");
    tap(await savePicker(), node => node.text?.toLowerCase() === "save", "Save a copy");
    await until(async () => (await status()).startsWith("Saved "), "new copy");
    assert.ok(await canSave());
    checkContents(originalPath, external);
    await click("#share-page");
    await click("#mobile-share");
    await until(() => shell("dumpsys activity activities").includes("ChooserActivity"), "final HTML share");
    copyShared("*.html", "roundtrip.html");
    shell("input keyevent 4");
    assert.ok(fs.readFileSync(path.join(fixtureDirectory, "roundtrip.html"), "utf8").includes("Local reply after external edit"));
    console.log("PASS external edits are preserved and Save a copy keeps local work");

    // Replacing the underlying file can also invalidate its provider ID.
    // A manual save must then offer a new document instead of retrying it.
    await until(async () => !(await evaluate("document.querySelector('#save-html').disabled")), "share completion");
    const copiedName = await evaluate("document.querySelector('#save-state').textContent");
    assert.ok(copiedName.startsWith("Dysociate-Android-QA") && copiedName.endsWith(".html"));
    const copiedPath = "/sdcard/Download/" + copiedName;
    command("push", externalFixture, copiedPath);
    await click('[data-reply-to="desktop-root"]');
    await type("#comment-body", "Reply after provider replacement");
    await click("#post-submit");
    await until(async () => !(await canSave()), "invalid document fallback");
    checkContents(copiedPath, external);
    await click("#save-html");
    tap(await savePicker(), node => node.text?.toLowerCase() === "save", "Save picker after lost access");
    await until(async () => (await status()).startsWith("Saved "), "save after provider replacement");
    assert.ok(await canSave());
    console.log("PASS replaced document IDs fall back to a new save location");
    if (liveTitle) await checkLiveBrowser(liveTitle);
    console.log("PASS Android integration suite");
}

try {
    await run();
} finally {
    if (socket) socket.close();
    if (debuggerPort) command("forward", "--remove", "tcp:" + debuggerPort);
    if (pilot) {
        command("emu", "network", "delay", "none");
        command("emu", "network", "speed", "full");
    }
}
