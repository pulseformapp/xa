"""Stage the shared portable editor and Android-only assets.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""
import argparse
from html import escape
from pathlib import Path
import shutil
import sys

from PIL import Image


HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--shared", type=Path, required=True)
    parser.add_argument("--stage", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.shared.resolve()))
    from app_resources import KARMIC_LAW, KARMIC_SIGNOFF
    from build_offline_assets import build as build_offline_assets
    from pagebuilder_gui import Page, render_document

    assets = args.stage / "assets"
    drawable = args.stage / "res" / "drawable-nodpi"
    assets.mkdir(parents=True, exist_ok=True)
    build_offline_assets(assets)
    drawable.mkdir(parents=True, exist_ok=True)
    shutil.copytree(HERE / "app" / "res", args.stage / "res", dirs_exist_ok=True)

    document = render_document(Page(title="Untitled thread"))
    # Inject only into the packaged editor. These markers identify everything
    # the runtime strips before saving or sharing a portable thread.
    policy = (
        "default-src 'none'; script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src blob:; "
        "connect-src 'self'; base-uri 'none'; form-action 'none'; object-src 'none'"
    )
    insertions = {
        '<html lang="en">': '<html lang="en" data-android>',
        '<meta charset="utf-8">': (
            '<meta charset="utf-8">\n'
            '<meta data-android-only http-equiv="Content-Security-Policy" '
            f'content="{escape(policy, quote=True)}">\n'
            '<link data-android-only rel="stylesheet" href="/mobile.css">'
        ),
        '<p class="eyebrow">': (
            '<div class="mobile-brand" data-android-only>'
            '<p class="mobile-slogan">~ the original off grid clandestine social network xD welcome to the outernet ~</p>'
            '<div class="mobile-identity"><img src="/logo.png" alt="" width="52" height="52">'
            '<div><strong>dλsociate</strong>'
            '<p>OFFLINE THREADS / ONE HTML FILE / AI is kill /<br>'
            'created by luna love, lunasoft λ 2026</p></div></div></div>\n'
            '<p class="eyebrow">'
        ),
        '<div class="browser-tools">': (
            '<p id="mobile-feedback" data-android-only hidden></p>\n'
            '<div class="browser-tools">\n'
            '<details id="mobile-tools" data-android-only><summary>More</summary><div>'
            '<button id="mobile-preview" type="button" aria-haspopup="dialog">Preview</button>'
            '<button id="mobile-copy" type="button">Save a copy</button>'
            '<button id="mobile-help" type="button">Help</button>'
            '<button id="mobile-terms" type="button">Terms</button></div></details>\n'
        ),
        '<button id="new-post"': (
            '<button data-android-only id="mobile-fresh" type="button">Fresh Thread</button>\n'
            '<button data-android-only id="mobile-open" type="button" aria-haspopup="dialog">Launch</button>\n'
            '<button data-android-only id="mobile-live" type="button" aria-haspopup="dialog">Create live thread</button>\n'
            '<button data-android-only id="mobile-live-open" type="button" aria-haspopup="dialog">Open live link</button>\n'
            '<button data-android-only id="mobile-offline-library" type="button" aria-haspopup="dialog">Offline threads</button>\n'
            '<button id="new-post"'
        ),
        '<label for="comment-image">': (
            '<div class="mobile-attachments" data-android-only>'
            '<button id="mobile-photo" type="button">Add photo</button>'
            '<button id="mobile-record" type="button">Record reel</button>'
            '</div>\n'
            '<label for="comment-image">'
        ),
        '<button id="share-email"': (
            '<button data-android-only id="mobile-share" type="button">Share HTML file</button>\n'
            '<button data-android-only id="mobile-publish" type="button">Publish &amp; text link</button>\n'
            '<button data-android-only id="mobile-text" type="button">Text HTML attachment</button>\n'
            '<button data-android-only id="mobile-email-file" type="button">Email draft (.eml)</button>\n'
            '<button id="share-email"'
        ),
        '<p id="share-size"': (
            '<p data-android-only>Publish to text a browser link. Email and attachment options send an HTML file.</p>\n'
            '<p id="share-size"'
        ),
        '<dialog class="terms-dialog"': (
            '<dialog class="terms-dialog" data-android-only id="mobile-preview-dialog" aria-labelledby="mobile-preview-heading">'
            '<div class="mobile-preview-bar"><strong id="mobile-preview-heading">Thread preview</strong>'
            '<button type="button" id="mobile-preview-close" autofocus>Back to editor</button></div>'
            '<p id="mobile-preview-draft" hidden>Your unposted draft is still in the editor.</p>'
            '<div id="mobile-preview-content"></div></dialog>\n'
            '<dialog class="terms-dialog"'
        ),
    }
    for anchor, markup in insertions.items():
        if document.count(anchor) != 1:
            raise ValueError(f"Shared editor markup changed around {anchor!r}")
        document = document.replace(anchor, markup, 1)
    before, runtime, after = document.rpartition("<script>")
    if not runtime:
        raise ValueError("Shared editor runtime script is missing")
    document = before + '<script data-android-only src="/mobile.js"></script>\n' + runtime + after
    (assets / "index.html").write_text(document, encoding="utf-8", newline="\n")
    (assets / "karmic.txt").write_text(f"{KARMIC_LAW}\n\n{KARMIC_SIGNOFF}\n", encoding="utf-8")
    for name in ("mobile.js", "mobile.css", "help.txt"):
        shutil.copyfile(HERE / "app" / "assets" / name, assets / name)
    shutil.copyfile(args.shared / "LICENSE", assets / "LICENSE")
    with Image.open(args.shared / "assets" / "dysociate.png") as icon:
        icon.thumbnail((192, 192), Image.Resampling.LANCZOS)
        icon.save(drawable / "icon.png")


if __name__ == "__main__":
    main()
