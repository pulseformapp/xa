/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
package com.lunasoft.dysociate;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

/** Share targets get read-only exports. The editor can also update its own offline copies. */
public final class SharedFiles extends ContentProvider {
    static final String AUTHORITY = "com.lunasoft.dysociate.files";

    @Override public boolean onCreate() { return true; }

    private File find(Uri uri) throws FileNotFoundException {
        List<String> parts = uri.getPathSegments();
        if (parts.size() != 2 || !parts.get(0).matches("[a-zA-Z0-9-]+")) {
            throw new FileNotFoundException();
        }
        if ("offline".equals(parts.get(0))) {
            File directory = new File(getContext().getFilesDir(), "offline-threads");
            File file = new File(directory, parts.get(1));
            try {
                if (file.getName().equals(parts.get(1)) && file.getName().endsWith(".html") && file.isFile()
                    && file.getCanonicalFile().equals(new File(directory.getCanonicalFile(), file.getName()))) return file;
            } catch (java.io.IOException ignored) {}
            throw new FileNotFoundException();
        }
        File directory = new File(new File(getContext().getCacheDir(), "shared"), parts.get(0));
        File file = new File(directory, parts.get(1));
        try {
            if (file.getCanonicalFile().getParentFile().equals(directory.getCanonicalFile()) && file.isFile()) return file;
        } catch (java.io.IOException ignored) {}
        throw new FileNotFoundException();
    }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"r".equals(mode)) throw new FileNotFoundException();
        return ParcelFileDescriptor.open(find(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    static Uri offlineUri(File file) {
        return new Uri.Builder().scheme("content").authority(AUTHORITY).appendPath("offline")
            .appendPath(file.getName()).build();
    }

    static boolean isOfflineUri(Uri uri) {
        List<String> parts = uri.getPathSegments();
        return "content".equals(uri.getScheme()) && AUTHORITY.equals(uri.getAuthority())
            && parts.size() == 2 && "offline".equals(parts.get(0));
    }

    @Override public String getType(Uri uri) {
        String name = uri.getLastPathSegment();
        return name != null && name.endsWith(".eml") ? "message/rfc822" : "text/html";
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] args, String order) {
        String[] columns = projection == null ? new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE} : projection;
        MatrixCursor cursor = new MatrixCursor(columns);
        try {
            File file = find(uri);
            MatrixCursor.RowBuilder row = cursor.newRow();
            for (String column : columns) {
                if (OpenableColumns.DISPLAY_NAME.equals(column)) row.add(file.getName());
                else if (OpenableColumns.SIZE.equals(column)) row.add(file.length());
                else row.add(null);
            }
        } catch (FileNotFoundException ignored) {}
        return cursor;
    }

    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues values, String where, String[] args) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri, String where, String[] args) { throw new UnsupportedOperationException(); }
}
