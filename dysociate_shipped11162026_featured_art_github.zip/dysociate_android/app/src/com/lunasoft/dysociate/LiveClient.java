/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
package com.lunasoft.dysociate;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.ProviderException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.json.JSONException;
import org.json.JSONArray;
import org.json.JSONObject;

final class LiveClient {
    static final class Media {
        final String type;
        final byte[] bytes;

        Media(String type, byte[] bytes) {
            this.type = type;
            this.bytes = bytes;
        }
    }
    private static final String PRODUCTION = "https://dysociate.org";
    private static final String LOCAL = "http://127.0.0.1:8795";
    private static final String PILOT = "https://dysociate-live-pilot.pulseform.workers.dev";
    private static final Pattern INVITE = Pattern.compile("(?:l-)?[a-z0-9]{1,12}\\.[A-Za-z0-9_-]{22}\\.[A-Za-z0-9_-]{43}");
    private static final Pattern POST = Pattern.compile("p_[A-Za-z0-9_-]{22}");
    private static final Pattern TOKEN = Pattern.compile("[A-Za-z0-9_-]{43}");
    private static final int RESPONSE_LIMIT = 32 * 1024;
    private final SharedPreferences storage;
    private final String origin;

    static final class Draft {
        final String title, body;
        final boolean locked, attached;

        Draft(String title, String body, boolean locked, boolean attached) {
            this.title = title;
            this.body = body;
            this.locked = locked;
            this.attached = attached;
        }
    }

    static final class ThreadLink {
        final String title, url, postId;
        final boolean deleted;
        final long savedAt;

        ThreadLink(String title, String url, String postId, boolean deleted, long savedAt) {
            this.title = title;
            this.url = url;
            this.postId = postId;
            this.deleted = deleted;
            this.savedAt = savedAt;
        }

        JSONObject record() {
            return json("title", title, "url", url, "postId", postId, "deleted", deleted, "savedAt", savedAt);
        }

        boolean locked() { return url.contains("/t/l-"); }
    }

    LiveClient(Context context) {
        origin = hasBuildAsset(context, "live-loopback") ? LOCAL :
            hasBuildAsset(context, "live-pilot") ? PILOT : PRODUCTION;
        storage = context.getSharedPreferences(keyAlias(), Context.MODE_PRIVATE);
    }

    private static boolean hasBuildAsset(Context context, String name) {
        if ((context.getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) == 0) return false;
        try (InputStream marker = context.getAssets().open(name)) {
            return marker.read() == '1';
        } catch (IOException missing) { return false; }
    }

    boolean isLocal() { return LOCAL.equals(origin); }
    boolean isPilot() { return PILOT.equals(origin); }

    static String viewerUrl(Context context, String input) {
        if (input == null) return null;
        String link = input.trim();
        String[] allowed = hasBuildAsset(context, "live-loopback")
            ? new String[]{PRODUCTION, PILOT, LOCAL} : new String[]{PRODUCTION, PILOT};
        for (String candidate : allowed) {
            String prefix = candidate + "/t/";
            if (link.startsWith(prefix) && INVITE.matcher(link.substring(prefix.length())).matches()) return link;
        }
        return null;
    }

    private String keyAlias() {
        return isLocal() ? "live-local" : isPilot() ? "live-pilot" : "live";
    }

    Draft draft() {
        Draft draft = new Draft("", "", false, false);
        long latest = 0;
        for (Map.Entry<String, ?> entry : storage.getAll().entrySet()) {
            if (!entry.getKey().startsWith("pending:")) continue;
            JSONObject saved = readJson((String) entry.getValue());
            if (saved.optLong("savedAt") > latest) {
                latest = saved.optLong("savedAt");
                // The suffix already records the operation's options. Read
                // it for older pending drafts as well as newly saved ones.
                String key = entry.getKey();
                draft = new Draft(saved.optString("title"), saved.optString("body"),
                    key.contains(":locked:"), key.contains(":image/") || key.contains(":video/"));
            }
        }
        return draft;
    }

    List<ThreadLink> threads() {
        List<ThreadLink> result = new ArrayList<>();
        for (Map.Entry<String, ?> entry : storage.getAll().entrySet()) {
            if (!entry.getKey().startsWith("thread:")) continue;
            JSONObject saved = readJson((String) entry.getValue());
            String url = saved.optString("url");
            String postId = saved.optString("postId");
            if (invite(url) == null || !POST.matcher(postId).matches()) continue;
            result.add(new ThreadLink(saved.optString("title"), url, postId,
                saved.optBoolean("deleted"), saved.optLong("savedAt")));
        }
        result.sort(Comparator.comparingLong((ThreadLink item) -> item.savedAt).reversed());
        return result;
    }

    ThreadLink create(String title, String body) {
        return create(title, body, null);
    }

    ThreadLink create(String title, String body, Media media) {
        return create(title, body, media, false, "");
    }

    ThreadLink create(String title, String body, Media media, boolean locked, String passkey) {
        title = title.trim();
        body = body.trim();
        if (title.isEmpty() || title.codePointCount(0, title.length()) > 120) {
            throw new IllegalArgumentException("Enter a title of 1 to 120 characters.");
        }
        if ((body.isEmpty() && media == null) || body.getBytes(StandardCharsets.UTF_8).length > 4096) {
            throw new IllegalArgumentException("Enter an opening post of up to 4,096 UTF-8 bytes.");
        }
        passkey = locked ? passkey.trim() : "";
        if (!passkey.isEmpty() && (passkey.length() < 8 || passkey.getBytes(StandardCharsets.UTF_8).length > 128)) {
            throw new IllegalArgumentException("Use at least 8 characters and at most 128 UTF-8 bytes for the passkey.");
        }
        String token = credential(true);
        String pendingKey = pendingKey(title, body) + (media == null ? "" : ":" + media.type + ":" + sha256(media.bytes));
        if (locked) pendingKey += ":locked:" + passkeyFingerprint(token, passkey);
        JSONObject pending = readJson(storage.getString(pendingKey, "{}"));
        String operation = pending.optString("operationId");
        if (operation.isEmpty()) {
            operation = UUID.randomUUID().toString();
            pending = json("title", title, "body", body, "operationId", operation,
                "savedAt", System.currentTimeMillis());
            save(storage.edit().putString(pendingKey, pending.toString()));
        }
        // Save the operation before HTTP. A lost reply can follow a committed
        // write, so an unchanged retry must carry this same operation ID.
        JSONObject payload = json("operationId", operation, "title", title, "openingPost", json("body", body));
        if (locked) payload = json("operationId", operation, "title", title, "openingPost", json("body", body),
            "accessMode", "locked", "passkey", passkey.isEmpty() ? null : passkey);
        JSONObject result = request("POST", "/threads", token, payload, media);
        String url = result.optString("shareUrl");
        String invite = invite(url);
        JSONObject post = result.optJSONObject("post");
        if (invite == null || post == null || !POST.matcher(post.optString("id")).matches()) {
            throw new IllegalArgumentException("The live service returned an invalid thread.");
        }
        ThreadLink thread = new ThreadLink(title, url, post.optString("id"), !post.isNull("deletedAt"),
            System.currentTimeMillis());
        save(storage.edit().putString("thread:" + invite, thread.record().toString()).remove(pendingKey));
        return thread;
    }

    private String passkeyFingerprint(String token, String passkey) {
        try {
            Mac hmac = Mac.getInstance("HmacSHA256");
            hmac.init(new SecretKeySpec(token.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            return Base64.encodeToString(hmac.doFinal(passkey.getBytes(StandardCharsets.UTF_8)),
                Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
        } catch (GeneralSecurityException error) {
            throw new IllegalArgumentException("Could not protect the thread passkey.", error);
        }
    }

    String creatorLink(ThreadLink thread) {
        String invite = invite(thread.url);
        if (invite == null || !thread.locked()) throw new IllegalArgumentException("The locked link is invalid.");
        String url = request("POST", "/threads/" + invite + "/handoff", credential(false), json())
            .optString("creatorUrl");
        if (!url.matches(Pattern.quote(thread.url) + "#creator=[A-Za-z0-9_-]{43}")) {
            throw new IllegalArgumentException("The live service returned an invalid creator link.");
        }
        return url;
    }

    List<JoinRequest> joinRequests(ThreadLink thread, JoinRequest selected, boolean approve) {
        String invite = invite(thread.url);
        if (invite == null || !thread.locked()) throw new IllegalArgumentException("The locked link is invalid.");
        String route = "/threads/" + invite + "/requests";
        String token = credential(false);
        JSONObject response = selected == null ? request("GET", route, token, null)
            : request("POST", route + "/" + selected.id, token,
                json("decision", approve ? "approved" : "declined"));
        JSONArray items = response.optJSONArray("requests");
        if (items == null) throw new IllegalArgumentException("The live service returned an invalid join request list.");
        List<JoinRequest> requests = new ArrayList<>();
        for (int index = 0; index < items.length(); index++) {
            JSONObject item = items.optJSONObject(index);
            if (item == null || !item.optString("id").matches("[A-Za-z0-9_-]{22}")) {
                throw new IllegalArgumentException("The live service returned an invalid join request.");
            }
            requests.add(new JoinRequest(item.optString("id"), item.optString("name"), item.optString("requestedAt")));
        }
        return requests;
    }

    static final class JoinRequest {
        final String id, name, time;

        JoinRequest(String id, String name, String time) {
            this.id = id;
            this.name = name;
            this.time = time;
        }
    }
    void deleteOpeningPost(ThreadLink thread) {
        String invite = invite(thread.url);
        if (invite == null || !POST.matcher(thread.postId).matches()) {
            throw new IllegalArgumentException("The opening post reference is invalid.");
        }
        JSONObject result = request("DELETE", "/threads/" + invite + "/posts/" + thread.postId,
            credential(false), null);
        JSONObject post = result.optJSONObject("post");
        if (post == null || !thread.postId.equals(post.optString("id")) || post.isNull("deletedAt")) {
            throw new IllegalArgumentException("The live service did not confirm deletion. Try again.");
        }
        ThreadLink deleted = new ThreadLink(thread.title, thread.url, thread.postId, true, thread.savedAt);
        save(storage.edit().putString("thread:" + invite, deleted.record().toString()));
    }

    private String credential(boolean create) {
        String saved = storage.getString("protectedCredential", "");
        if (!saved.isEmpty()) {
            String token = new String(credentialCipher(Base64.decode(saved, Base64.NO_WRAP), false),
                StandardCharsets.UTF_8);
            if (!TOKEN.matcher(token).matches()) throw new IllegalArgumentException("The saved live credential is invalid.");
            return token;
        }
        if (!create) throw new IllegalArgumentException("This installation no longer has the credential for this thread.");
        String token = request("POST", "/session", null, json("client", "native")).optString("credential");
        if (!TOKEN.matcher(token).matches()) throw new IllegalArgumentException("The live service returned an invalid credential.");
        byte[] protectedToken = credentialCipher(token.getBytes(StandardCharsets.UTF_8), true);
        save(storage.edit().putString("protectedCredential", Base64.encodeToString(protectedToken, Base64.NO_WRAP)));
        return token;
    }

    private byte[] credentialCipher(byte[] data, boolean encrypt) {
        // Preferences store the IV and ciphertext. Android Keystore keeps the
        // per-installation key outside the app's data files and backups.
        String alias = "dysociate-" + keyAlias();
        try {
            KeyStore store = KeyStore.getInstance("AndroidKeyStore");
            store.load(null);
            SecretKey key = (SecretKey) store.getKey(alias, null);
            if (key == null && encrypt) {
                KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
                generator.init(new KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
                key = generator.generateKey();
            }
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            if (encrypt) {
                cipher.init(Cipher.ENCRYPT_MODE, key);
                byte[] iv = cipher.getIV();
                byte[] ciphertext = cipher.doFinal(data);
                if (iv.length != 12) throw new GeneralSecurityException("Unexpected GCM IV length");
                byte[] protectedToken = Arrays.copyOf(iv, iv.length + ciphertext.length);
                System.arraycopy(ciphertext, 0, protectedToken, iv.length, ciphertext.length);
                return protectedToken;
            }
            if (key == null || data.length < 28) throw new GeneralSecurityException("Missing key or ciphertext");
            cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, data, 0, 12));
            return cipher.doFinal(data, 12, data.length - 12);
        } catch (GeneralSecurityException | IOException | ProviderException error) {
            throw new IllegalArgumentException("Could not access the phone’s protected live thread credential.");
        }
    }

    private String invite(String url) {
        String prefix = origin + "/t/";
        if (!url.startsWith(prefix)) return null;
        String invite = url.substring(prefix.length());
        return INVITE.matcher(invite).matches() ? invite : null;
    }

    private static String pendingKey(String title, String body) {
        return "pending:" + sha256(json("title", title, "body", body).toString().getBytes(StandardCharsets.UTF_8));
    }

    private static String sha256(byte[] input) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(input);
            return Base64.encodeToString(hash, Base64.NO_WRAP);
        } catch (NoSuchAlgorithmException error) { throw new AssertionError(error); }
    }

    private static void save(SharedPreferences.Editor change) {
        if (!change.commit()) throw new IllegalArgumentException("Could not save live thread information on this phone.");
    }

    private JSONObject request(String method, String path, String token, JSONObject payload) {
        return request(method, path, token, payload, null);
    }

    private JSONObject request(String method, String path, String token, JSONObject payload, Media media) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(origin + "/api/v1" + path).openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(10_000);
            connection.setReadTimeout(media == null ? 10_000 : 45_000);
            connection.setRequestMethod(method);
            connection.setRequestProperty("Accept", "application/json");
            if (token != null) connection.setRequestProperty("Authorization", "Bearer " + token);
            if (payload != null) {
                byte[] data = payload.toString().getBytes(StandardCharsets.UTF_8);
                String boundary = UUID.randomUUID().toString();
                byte[] first = media == null ? new byte[0] :
                    ("--" + boundary + "\r\nContent-Disposition: form-data; name=\"payload\"\r\n\r\n").getBytes(StandardCharsets.US_ASCII);
                byte[] second = media == null ? new byte[0] : ("\r\n--" + boundary +
                    "\r\nContent-Disposition: form-data; name=\"media\"; filename=\"attachment\"\r\nContent-Type: " +
                    media.type + "\r\n\r\n").getBytes(StandardCharsets.US_ASCII);
                byte[] last = media == null ? new byte[0] : ("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.US_ASCII);
                connection.setRequestProperty("Content-Type", media == null ? "application/json; charset=utf-8" :
                    "multipart/form-data; boundary=" + boundary);
                connection.setFixedLengthStreamingMode(first.length + data.length + second.length +
                    (media == null ? 0 : media.bytes.length) + last.length);
                connection.setDoOutput(true);
                try (OutputStream output = connection.getOutputStream()) {
                    output.write(first);
                    output.write(data);
                    if (media != null) {
                        output.write(second);
                        output.write(media.bytes);
                        output.write(last);
                    }
                }
            }
            int status = connection.getResponseCode();
            boolean success = status == 200 || status == 201;
            JSONObject result = readResponse(success ? connection.getInputStream() : connection.getErrorStream());
            if (success) return result;
            JSONObject error = result.optJSONObject("error");
            throw new IllegalArgumentException(error == null
                ? "The live service returned an unexpected response. Try again."
                : error.optString("message", "The live service is unavailable. Try again."));
        } catch (IOException error) {
            throw new IllegalArgumentException("Could not reach the live service. Check your connection and try again.");
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static JSONObject readResponse(InputStream stream) throws IOException {
        if (stream == null) return new JSONObject();
        try (InputStream input = stream; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[2048];
            for (int count; (count = input.read(buffer)) != -1;) {
                if (output.size() + count > RESPONSE_LIMIT) {
                    throw new IllegalArgumentException("The live service returned an invalid response.");
                }
                output.write(buffer, 0, count);
            }
            return readJson(new String(output.toByteArray(), StandardCharsets.UTF_8));
        }
    }

    private static JSONObject readJson(String value) {
        try { return new JSONObject(value); }
        catch (JSONException error) { return new JSONObject(); }
    }

    private static JSONObject json(Object... entries) {
        JSONObject result = new JSONObject();
        try {
            for (int index = 0; index < entries.length; index += 2) {
                result.put((String) entries[index], entries[index + 1]);
            }
            return result;
        } catch (JSONException impossible) { throw new AssertionError(impossible); }
    }
}
