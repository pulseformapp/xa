/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
package com.lunasoft.dysociate;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;
import org.json.JSONTokener;
import android.app.AlertDialog;

/** Hosts the live web client in a view with no access to the HTML editor bridge. */
public final class LiveThreadActivity extends Activity {
    private static final int PICK_PHOTO = 421;
    private String address;
    private WebView viewer;
    private LinearLayout root;
    private TextView status;
    private Button retry;
    private Button save;
    private ValueCallback<Uri[]> photo;
    private final ExecutorService disk = Executors.newSingleThreadExecutor();
    private boolean saving;
    private SnapshotFile pendingSnapshot;

    static File library(Activity activity) { return new File(activity.getFilesDir(), "offline-threads"); }

    static void open(Activity activity, String address) {
        activity.startActivity(new Intent(activity, LiveThreadActivity.class).setData(Uri.parse(address)));
    }

    static void openBrowser(Activity activity, String address) {
        try {
            activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(address)).addCategory(Intent.CATEGORY_BROWSABLE));
        } catch (ActivityNotFoundException problem) {
            Toast.makeText(activity, "Browser unavailable. Use Copy link.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        address = LiveClient.viewerUrl(this, getIntent().getDataString());
        if (address == null) {
            finish();
            return;
        }
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xff090512);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets safe = insets.getInsets(WindowInsets.Type.systemBars()
                    | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
                return insets;
            });
        }
        LinearLayout controls = new LinearLayout(this);
        root.addView(controls);
        addButton(controls, "Back to editor", this::finish);
        addButton(controls, "Open in browser", () -> openBrowser(this, address));
        addButton(controls, "Copy link", this::copyLink);
        save = new Button(this);
        save.setAllCaps(false);
        save.setText("Save offline");
        save.setEnabled(false);
        save.setOnClickListener(view -> {
            if (Uri.parse(address).getPath().startsWith("/t/l-")) {
                new AlertDialog.Builder(this).setTitle("Save offline")
                    .setMessage("Anyone who gets the saved HTML file can read it. Save this locked thread?")
                    .setNegativeButton("Cancel", null).setPositiveButton("Save", (dialog, choice) -> beginSave()).show();
            } else beginSave();
        });
        root.addView(save);
        status = new TextView(this);
        status.setTextColor(0xfffff1fa);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        root.addView(status);
        retry = new Button(this);
        retry.setText("Retry");
        retry.setVisibility(View.GONE);
        retry.setOnClickListener(view -> {
            if (viewer == null) attachViewer();
            else viewer.loadUrl(address);
        });
        root.addView(retry);
        setContentView(root);
        attachViewer();
    }

    private void addButton(LinearLayout row, String label, Runnable action) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(label);
        button.setOnClickListener(view -> action.run());
        row.addView(button, new LinearLayout.LayoutParams(0, -2, 1));
    }

    private void copyLink() {
        ClipboardManager clipboard = getSystemService(ClipboardManager.class);
        clipboard.setPrimaryClip(ClipData.newPlainText("dλsociate live thread", address));
        if (Build.VERSION.SDK_INT < 33)
            Toast.makeText(this, "Link copied.", Toast.LENGTH_SHORT).show();
    }

    private void attachViewer() {
        try {
            viewer = new WebView(this);
        } catch (RuntimeException unavailable) {
            showProblem("Viewer unavailable. Update Android System WebView or open in your browser.");
            return;
        }
        viewer.setBackgroundColor(0xff090512);
        viewer.getSettings().setJavaScriptEnabled(true);
        viewer.getSettings().setDomStorageEnabled(true);
        viewer.getSettings().setAllowFileAccess(false);
        viewer.getSettings().setAllowContentAccess(false);
        viewer.getSettings().setSupportMultipleWindows(false);
        CookieManager.getInstance().setAcceptThirdPartyCookies(viewer, false);
        viewer.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.isForMainFrame() || !address.equals(request.getUrl().toString());
            }

            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
                saving = false;
                discardSnapshot();
                save.setEnabled(false);
                retry.setVisibility(View.GONE);
                status.setText("Opening live thread…");
                status.setVisibility(View.VISIBLE);
            }

            @Override public void onPageFinished(WebView view, String url) {
                if (retry.getVisibility() == View.GONE && address.equals(url)) {
                    save.setEnabled(!saving);
                    if (!saving) status.setVisibility(View.GONE);
                }
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame())
                    showProblem("Could not load the thread. Check your connection.");
            }

            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                saving = false;
                discardSnapshot();
                discardViewer();
                showProblem("Live viewer closed. Tap Retry to reopen it.");
                return true;
            }
        });
        viewer.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) { request.deny(); }

            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> result,
                                                       FileChooserParams options) {
                if (photo != null) photo.onReceiveValue(null);
                photo = result;
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("image/*").putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/jpeg", "image/png"});
                try { startActivityForResult(pick, PICK_PHOTO); }
                catch (ActivityNotFoundException unavailable) { finishPhoto(null); }
                return true;
            }
        });
        root.addView(viewer, new LinearLayout.LayoutParams(-1, 0, 1));
        viewer.loadUrl(address);
    }

    private void showProblem(String message) {
        save.setEnabled(false);
        status.setText(message);
        status.setVisibility(View.VISIBLE);
        retry.setVisibility(View.VISIBLE);
    }

    private String asset(String name) throws IOException {
        try (InputStream input = getAssets().open(name)) {
            java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
            byte[] buffer = new byte[16384];
            for (int count; (count = input.read(buffer)) != -1;) bytes.write(buffer, 0, count);
            return bytes.toString("UTF-8");
        }
    }

    private boolean activeSave() {
        return saving && viewer != null && address.equals(viewer.getUrl()) && !isFinishing() && !isDestroyed();
    }

    private void beginSave() {
        if (saving || viewer == null || !address.equals(viewer.getUrl())) return;
        saving = true;
        save.setEnabled(false);
        status.setText("Downloading history…");
        status.setVisibility(View.VISIBLE);
        try {
            viewer.evaluateJavascript(asset("live-snapshot.js"), value -> {
                if ("true".equals(value)) pollSave();
                else finishSave("Could not start the download. Try again.");
            });
        } catch (IOException error) { finishSave("Offline export is unavailable in this build."); }
    }

    private void pollSave() {
        if (!activeSave()) return;
        viewer.evaluateJavascript("window.dysociateOfflineCapture?.status()", raw -> {
            if (!activeSave()) return;
            try {
                JSONObject capture = new JSONObject(raw);
                switch (capture.getString("state")) {
                    case "ready": writeSnapshot(capture.getString("title")); break;
                    case "error": finishSave(capture.getString("text")); break;
                    default:
                        status.setText(capture.getString("text"));
                        status.postDelayed(this::pollSave, 160);
                }
            } catch (Exception error) { finishSave("Could not download the whole thread. Try again."); }
        });
    }

    private final class SnapshotFile {
        final File stage, destination;
        final BufferedWriter writer;
        SnapshotFile(String title) throws IOException {
            File dir = library(LiveThreadActivity.this);
            Files.createDirectories(dir.toPath());
            String label = title.replaceAll("[^\\p{L}\\p{N} _-]", "_").trim();
            if (label.length() > 54) label = label.substring(0, 54).trim();
            String stamp = new SimpleDateFormat("yyyy-MM-dd HHmmss", Locale.ROOT).format(new Date());
            String name = stamp + " " + UUID.randomUUID().toString().substring(0, 8) + " - ";
            destination = new File(dir, name + (label.isEmpty() ? "Thread" : label) + ".html");
            String head = asset("offline-head.txt");
            stage = File.createTempFile("snapshot-", ".tmp", dir);
            try {
                writer = Files.newBufferedWriter(stage.toPath(), StandardCharsets.UTF_8);
            } catch (IOException error) {
                stage.delete();
                throw error;
            }
            try { writer.write(head); }
            catch (IOException error) {
                discard();
                throw error;
            }
        }
        void discard() {
            try { writer.close(); } catch (IOException ignored) {}
            stage.delete();
        }
    }

    private void writeSnapshot(String title) {
        status.setText("Writing offline HTML…");
        disk.execute(() -> {
            try {
                SnapshotFile file = new SnapshotFile(title);
                runOnUiThread(() -> {
                    if (!activeSave()) { file.discard(); return; }
                    pendingSnapshot = file;
                    copyChunk(file, 0);
                });
            } catch (IOException error) { runOnUiThread(() -> finishSave("Could not create the offline file.")); }
        });
    }

    private void copyChunk(SnapshotFile file, int offset) {
        if (!activeSave()) return;
        viewer.evaluateJavascript("window.dysociateOfflineCapture.take(" + offset + ")", raw -> {
            if (!activeSave()) return;
            disk.execute(() -> {
                try {
                    Object value = new JSONTokener(raw).nextValue();
                    if (!(value instanceof String)) throw new IOException("Incomplete capture");
                    String piece = (String)value;
                    int end = offset + piece.length();
                    if (end > 62 * 1024 * 1024) throw new IOException("Capture too large");
                    if (!piece.isEmpty()) {
                        file.writer.write(piece);
                        runOnUiThread(() -> copyChunk(file, end));
                        return;
                    }
                    file.writer.write(asset("offline-tail.txt"));
                    file.writer.close();
                    if (file.stage.length() > 64L * 1024 * 1024) throw new IOException("Capture too large");
                    Files.move(file.stage.toPath(), file.destination.toPath(), StandardCopyOption.ATOMIC_MOVE);
                    runOnUiThread(() -> finishSave("Saved. Find it under Offline threads in the editor."));
                } catch (Exception error) {
                    file.discard();
                    runOnUiThread(() -> finishSave("Could not save the whole thread. Try again."));
                }
            });
        });
    }

    private void finishSave(String message) {
        saving = false;
        pendingSnapshot = null;
        if (isFinishing() || isDestroyed()) return;
        status.setText(message);
        status.setVisibility(View.VISIBLE);
        save.setEnabled(viewer != null && address.equals(viewer.getUrl()));
        if (viewer != null) viewer.evaluateJavascript("window.dysociateOfflineCapture?.clear()", null);
    }

    private void discardSnapshot() {
        SnapshotFile file = pendingSnapshot;
        pendingSnapshot = null;
        if (file != null) disk.execute(file::discard);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_PHOTO) {
            Uri uri = result == RESULT_OK && data != null ? data.getData() : null;
            finishPhoto(uri != null && "content".equals(uri.getScheme()) ? new Uri[]{uri} : null);
        }
    }

    private void finishPhoto(Uri[] selection) {
        ValueCallback<Uri[]> pending = photo;
        photo = null;
        if (pending != null) pending.onReceiveValue(selection);
    }

    @Override protected void onPause() {
        if (viewer != null) viewer.onPause();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (viewer != null) viewer.onResume();
    }

    private void discardViewer() {
        finishPhoto(null);
        if (viewer == null) return;
        root.removeView(viewer);
        viewer.destroy();
        viewer = null;
    }

    @Override protected void onDestroy() {
        saving = false;
        discardSnapshot();
        disk.shutdown();
        discardViewer();
        super.onDestroy();
    }
}
