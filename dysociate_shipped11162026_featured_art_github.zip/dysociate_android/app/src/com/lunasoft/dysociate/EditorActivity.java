/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
package com.lunasoft.dysociate;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.UriPermission;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.OpenableColumns;
import android.provider.Telephony;
import android.text.InputType;
import android.util.Base64;
import android.view.View;
import android.view.WindowInsets;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import org.json.JSONObject;

public final class EditorActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String HOME = "https://" + HOST + "/index.html";
    private static final int OPEN_THREAD = 10, OPEN_IMAGE = 11, SAVE = 12, PICK_PHONE = 13,
        CAMERA_PERMISSIONS = 14, LIVE_PHOTO = 15;
    private static final int THREAD_LIMIT = 64 * 1024 * 1024, MEDIA_LIMIT = 20 * 1024 * 1024;
    private static final int BG = 0xff090512, ACCENT = 0xffff76cf, SECONDARY = 0xffff9ddd;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private FrameLayout frame;
    private WebView web;
    private Uri launchDocument;
    private volatile Incoming incoming;
    private volatile Document document;
    private boolean ready, termsOpen;
    private volatile boolean reading;
    private volatile int picker;
    private Export active;
    private OnBackInvokedCallback backCallback;
    private Consumer<String> contactRecipient;
    private ReelRecorder reelRecorder;
    private Consumer<Uri> livePhoto;
    private Consumer<byte[]> liveReel;
    private volatile String publisherKey = "";

    private static final class Document {
        final Uri uri;
        final String name;
        final byte[] hash;
        final String token;
        Document(Uri uri, String name, byte[] hash) {
            this(uri, name, hash, UUID.randomUUID().toString());
        }
        Document(Uri uri, String name, byte[] hash, String token) {
            this.uri = uri; this.name = name; this.hash = hash; this.token = token;
        }
    }

    private static final class Incoming {
        final String token = UUID.randomUUID().toString();
        final File file;
        final Uri uri;
        final String kind, name, mime;
        final boolean writable;
        final byte[] hash;
        Incoming(File file, Uri uri, String kind, String name, String mime, boolean writable, byte[] hash) {
            this.file = file; this.uri = uri; this.kind = kind; this.name = name; this.mime = mime;
            this.writable = writable; this.hash = hash;
        }
    }

    private static final class Export {
        final String mode, name, mime, subject, body, recipient;
        final File file;
        final Writer writer;
        int characters;
        boolean staged;
        Export(String mode, String name, String mime, String subject, String body, String recipient, File file) throws IOException {
            this.mode = mode; this.name = name; this.mime = mime; this.file = file;
            this.subject = subject; this.body = body;
            this.recipient = recipient;
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8));
        }
    }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        frame = new FrameLayout(this);
        frame.setBackgroundColor(BG);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            frame.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets safe = insets.getInsets(WindowInsets.Type.systemBars()
                    | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
                return insets;
            });
        }
        setContentView(frame);
        // Android 16 stops calling onBackPressed for apps targeting API 36.
        // Register the platform callback on newer phones and share the same
        // save/quit flow with the older Android back-button entry point.
        if (Build.VERSION.SDK_INT >= 33) {
            backCallback = this::requestClose;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCallback);
        }
        launchDocument = attachment(getIntent());
        io.execute(this::clearOldShares);
        showAgreement(false, true);
    }

    private Uri attachment(Intent intent) {
        Uri uri = Intent.ACTION_VIEW.equals(intent.getAction()) ? intent.getData() :
            Intent.ACTION_SEND.equals(intent.getAction()) ? intent.getParcelableExtra(Intent.EXTRA_STREAM) : null;
        return uri != null && "content".equals(uri.getScheme()) ? uri : null;
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Uri uri = attachment(intent);
        if (uri == null) return;
        if (ready) importFile(uri, "thread", false);
        else launchDocument = uri;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private TextView text(String content, int size, int color) {
        TextView view = new TextView(this);
        view.setTypeface(Typeface.MONOSPACE);
        view.setTextColor(color);
        view.setTextSize(size);
        view.setTextIsSelectable(false);
        view.setText(content);
        return view;
    }

    private String assetText(String name) {
        try (InputStream input = getAssets().open(name); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            transfer(input, output, THREAD_LIMIT, null);
            return output.toString("UTF-8");
        } catch (IOException error) { return ""; }
    }

    private void showAgreement(boolean karma, boolean startup) {
        termsOpen = true;
        frame.removeAllViews();
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(18), dp(12), dp(18), dp(10));
        frame.addView(layout, new FrameLayout.LayoutParams(-1, -1));
        layout.addView(text(karma ? "02 / KARMIC LAW" : "01 / LICENSE AGREEMENT", 22, SECONDARY));
        TextView hint = text("Scroll to the end to agree", 13, ACCENT);
        layout.addView(hint);
        ScrollView scroll = new ScrollView(this);
        TextView words = text(assetText(karma ? "karmic.txt" : "LICENSE"), karma ? 20 : 14, Color.WHITE);
        words.setPadding(0, dp(12), 0, dp(18));
        scroll.addView(words);
        layout.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout actions = new LinearLayout(this);
        layout.addView(actions);
        Button decline = new Button(this);
        decline.setText(startup ? "Decline and exit" : "Close");
        decline.setOnClickListener(v -> { if (startup) finish(); else restoreEditor(); });
        actions.addView(decline, new LinearLayout.LayoutParams(0, -2, 1));
        Button agree = new Button(this);
        agree.setText("I agree");
        agree.setTextColor(Color.BLACK);
        agree.setBackgroundTintList(ColorStateList.valueOf(ACCENT));
        agree.setVisibility(View.INVISIBLE);
        actions.addView(agree, new LinearLayout.LayoutParams(0, -2, 1));
        Runnable reveal = () -> {
            if (scroll.getHeight() > 0 && !scroll.canScrollVertically(1)) {
                agree.setVisibility(View.VISIBLE);
                hint.setText("End of agreement");
            }
        };
        scroll.getViewTreeObserver().addOnGlobalLayoutListener(reveal::run);
        scroll.setOnScrollChangeListener((v, x, y, oldX, oldY) -> reveal.run());
        agree.setOnClickListener(v -> {
            if (!karma) showAgreement(true, startup);
            else if (startup) startEditor();
            else restoreEditor();
        });
    }

    private void restoreEditor() {
        termsOpen = false;
        frame.removeAllViews();
        frame.addView(web, new FrameLayout.LayoutParams(-1, -1));
    }

    private void startEditor() {
        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);
        }
        web = new WebView(this);
        web.setBackgroundColor(BG);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setSupportMultipleWindows(false);
        web.addJavascriptInterface(new Bridge(), "DysociateDevice");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (HOME.equals(url.toString())) return false;
                if (request.isForMainFrame() && request.hasGesture()
                    && ("https".equals(url.getScheme()) || "http".equals(url.getScheme()) || "mailto".equals(url.getScheme()))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, url)); }
                    catch (android.content.ActivityNotFoundException error) { tell("No app can open that link."); }
                }
                return true;
            }

            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                // Only packaged code and one user-selected byte stream can
                // enter this origin. Received HTML is data, never a page.
                Uri url = request.getUrl();
                if ("https".equals(url.getScheme()) && HOST.equals(url.getHost())) {
                    String path = url.getPath();
                    try {
                        if ("/index.html".equals(path)) return response("text/html", getAssets().open("index.html"));
                        if ("/mobile.css".equals(path)) return response("text/css", getAssets().open("mobile.css"));
                        if ("/mobile.js".equals(path)) return response("application/javascript", getAssets().open("mobile.js"));
                        if ("/logo.png".equals(path)) {
                            int icon = getApplicationInfo().icon;
                            return new WebResourceResponse("image/png", null, getResources().openRawResource(icon));
                        }
                        Incoming selected = incoming;
                        if (selected != null && ("/incoming/" + selected.token).equals(path)) {
                            return response("application/octet-stream", new FileInputStream(selected.file));
                        }
                    } catch (IOException ignored) {}
                }
                return new WebResourceResponse("text/plain", "UTF-8", 404, "Not found",
                    Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
            }
        });
        restoreEditor();
        web.loadUrl(HOME);
    }

    private static WebResourceResponse response(String mime, InputStream bytes) {
        return new WebResourceResponse(mime, mime.startsWith("application/octet") ? null : "UTF-8", bytes);
    }

    private void call(String expression) {
        if (web != null && !isFinishing() && !isDestroyed()) web.evaluateJavascript(expression, null);
    }
    private void tell(String message) { call("DysociateAndroid.tell(" + JSONObject.quote(message) + ")"); }

    private void retainGrant(Uri uri, int flags) {
        int access = flags & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        if ((flags & Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) == 0 || access == 0) return;
        try { getContentResolver().takePersistableUriPermission(uri, access); }
        catch (SecurityException ignored) { /* Some providers offer session access only. */ }
    }

    private boolean hasDurableAccess(Uri uri) {
        if (SharedFiles.isOfflineUri(uri)) return true;
        for (UriPermission permission : getContentResolver().getPersistedUriPermissions()) {
            if (permission.getUri().equals(uri) && permission.isReadPermission() && permission.isWritePermission()) return true;
        }
        return false;
    }

    private synchronized void setDocument(Document next) {
        document = next;
        android.content.SharedPreferences.Editor preferences = getSharedPreferences("document", MODE_PRIVATE).edit();
        if (next != null && hasDurableAccess(next.uri)) {
            try {
                JSONObject state = new JSONObject();
                state.put("uri", next.uri.toString());
                state.put("name", next.name);
                state.put("hash", Base64.encodeToString(next.hash, Base64.NO_WRAP));
                state.put("token", next.token);
                preferences.putString("current", state.toString());
            } catch (org.json.JSONException error) { throw new IllegalStateException(error); }
        } else preferences.remove("current");
        // This runs on the bridge or I/O thread. Commit before reporting a
        // successful save so a recovered draft can pair with the same epoch.
        preferences.commit();
    }

    private synchronized boolean restoreDocument(String token) {
        if (token == null || token.isEmpty()) return false;
        try {
            JSONObject state = new JSONObject(getSharedPreferences("document", MODE_PRIVATE).getString("current", "{}"));
            if (!token.equals(state.optString("token"))) return false;
            Uri uri = Uri.parse(state.getString("uri"));
            byte[] hash = Base64.decode(state.getString("hash"), Base64.NO_WRAP);
            if (!"content".equals(uri.getScheme()) || hash.length != 32 || !hasDurableAccess(uri)) return false;
            document = new Document(uri, state.getString("name"), hash, token);
            return true;
        } catch (org.json.JSONException | RuntimeException error) { return false; }
    }

    private final class Bridge {
        @JavascriptInterface public void ready() {
            runOnUiThread(() -> {
                ready = true;
                if (launchDocument != null) {
                    Uri uri = launchDocument;
                    launchDocument = null;
                    importFile(uri, "thread", false);
                }
            });
        }
        @JavascriptInterface public void choose(String kind) { runOnUiThread(() -> chooseFile(kind)); }
        @JavascriptInterface public void recordReel() {
            runOnUiThread(() -> {
                if (reading || incoming != null || liveReel != null) return;
                recordLiveReel(clip -> { if (clip != null) stageOfflineReel(clip); });
            });
        }
        @JavascriptInterface public boolean canAutoSave() { return document != null; }
        @JavascriptInterface public String documentToken() {
            Document current = document;
            return current == null ? "" : current.token;
        }
        @JavascriptInterface public boolean restoreDocument(String token) { return EditorActivity.this.restoreDocument(token); }
        @JavascriptInterface public boolean resetDocument() {
            synchronized (EditorActivity.this) {
                if (active != null || reading || incoming != null || picker != 0) return false;
                setDocument(null);
                publisherKey = "";
                getPreferences(MODE_PRIVATE).edit().remove("publishedLink").apply();
                return true;
            }
        }
        @JavascriptInterface public void receiveResult(String token, boolean accepted) {
            synchronized (EditorActivity.this) {
                Incoming selected = incoming;
                if (selected == null || !selected.token.equals(token)) return;
                if (accepted && "thread".equals(selected.kind)) {
                    setDocument(selected.writable ? new Document(selected.uri, selected.name, selected.hash) : null);
                }
                incoming = null;
                selected.file.delete();
            }
        }
        @JavascriptInterface public boolean beginWrite(String mode, String name, String mime, String subject, String body, String recipient) {
            synchronized (EditorActivity.this) {
                if (active != null || !Arrays.asList("auto", "save", "copy", "share", "email", "browser", "text", "publish").contains(mode)) return false;
                if (!"text/html".equals(mime) && !("share".equals(mode) && "message/rfc822".equals(mime))) return false;
                String number = normalizePhone(recipient);
                if ("text".equals(mode) && number.isEmpty()) return false;
                try {
                    File file = File.createTempFile("export-", ".tmp", getCacheDir());
                    try { active = new Export(mode, filename(name, mime), mime, subject, body, number, file); }
                    catch (IOException error) { file.delete(); throw error; }
                    return true;
                } catch (IOException error) { return false; }
            }
        }
        @JavascriptInterface public boolean appendWrite(String chunk) {
            synchronized (EditorActivity.this) {
                if (active == null || active.staged || chunk.length() > 256 * 1024
                    || active.characters + chunk.length() > THREAD_LIMIT) return false;
                try {
                    active.writer.write(chunk);
                    active.characters += chunk.length();
                    return true;
                } catch (IOException error) { return false; }
            }
        }
        @JavascriptInterface public void abortWrite() {
            synchronized (EditorActivity.this) {
                if (active == null || active.staged) return;
                try { active.writer.close(); } catch (IOException ignored) {}
                active.file.delete();
                active = null;
            }
        }
        @JavascriptInterface public void finishWrite() {
            Export job;
            synchronized (EditorActivity.this) {
                job = active;
                if (job == null || job.staged) return;
                job.staged = true;
                try { job.writer.close(); }
                catch (IOException error) {
                    runOnUiThread(() -> completed(job, false, "", "Could not stage the file.", true));
                    return;
                }
            }
            runOnUiThread(() -> dispatch(job));
        }
        @JavascriptInterface public void showHelp() {
            runOnUiThread(() -> new AlertDialog.Builder(EditorActivity.this).setTitle("dλsociate for Android")
                .setMessage(assetText("help.txt")).setPositiveButton("Done", null).show());
        }
        @JavascriptInterface public void showLaunch() { runOnUiThread(EditorActivity.this::showLaunch); }
        @JavascriptInterface public void showLiveThreads() {
            runOnUiThread(() -> {
                if (ready && !termsOpen && !isFinishing() && !isDestroyed()) new LiveThreadDialog(EditorActivity.this).showCreate();
            });
        }
        @JavascriptInterface public void openLiveLink() {
            runOnUiThread(() -> {
                if (ready && !termsOpen && !isFinishing() && !isDestroyed()) new LiveThreadDialog(EditorActivity.this).promptOpen();
            });
        }
        @JavascriptInterface public void showOfflineThreads() {
            runOnUiThread(() -> {
                if (ready && !termsOpen && !isFinishing() && !isDestroyed()) openOfflineLibrary();
            });
        }
        @JavascriptInterface public void chooseTextRecipient() { runOnUiThread(EditorActivity.this::chooseTextRecipient); }
        @JavascriptInterface public void choosePublish() { runOnUiThread(EditorActivity.this::choosePublish); }
        @JavascriptInterface public void showTextShareError(String recipient, String reason) {
            runOnUiThread(() -> EditorActivity.this.showTextShareError(recipient, reason));
        }
        @JavascriptInterface public void showTerms() { runOnUiThread(() -> showAgreement(false, false)); }
        @JavascriptInterface public void exit() { runOnUiThread(EditorActivity.this::finish); }
    }

    private void chooseTextRecipient() {
        chooseTextRecipient(this::shareToNumber);
    }

    private void chooseTextRecipient(Consumer<String> action) {
        if (picker != 0 || reading || incoming != null) return;
        EditText number = new EditText(this);
        number.setSingleLine(true);
        number.setInputType(InputType.TYPE_CLASS_PHONE);
        number.setHint("Enter phone number");
        FrameLayout content = new FrameLayout(this);
        content.setPadding(dp(24), 0, dp(24), 0);
        content.addView(number, new FrameLayout.LayoutParams(-1, -2));
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Text message recipient")
            .setView(content)
            .setNeutralButton("Choose contact", (d, which) -> {
                Intent pick = new Intent(Intent.ACTION_PICK).setType(Phone.CONTENT_TYPE)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                if (launchPicker(pick, PICK_PHONE)) contactRecipient = action;
                else contactUnavailable(action, "The contacts picker could not open.");
            })
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Continue", null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String recipient = normalizePhone(number.getText().toString());
            if (recipient.isEmpty()) { number.setError("Enter a phone number with 3 to 15 digits."); return; }
            dialog.dismiss();
            action.accept(recipient);
        }));
        dialog.show();
    }

    private static String normalizePhone(String value) {
        if (value == null) return "";
        String number = value.replaceAll("[\\s\\p{Z}().-]", "");
        return number.matches("\\+?[0-9]{3,15}") ? number : "";
    }

    private void shareToNumber(String number) {
        call("DysociateAndroid.textRecipient(" + JSONObject.quote(number) + ")");
    }

    private void showTextShareError(String recipient, String reason) {
        if (isFinishing() || isDestroyed()) return;
        AlertDialog.Builder dialog = new AlertDialog.Builder(this)
            .setTitle("Could not text the HTML")
            .setMessage(reason)
            .setPositiveButton("Email HTML", (d, which) -> call("DysociateAndroid.emailThread()"))
            .setNegativeButton("Cancel", null);
        String number = normalizePhone(recipient);
        if (number.isEmpty()) {
            dialog.setNeutralButton("Enter number", (d, which) -> chooseTextRecipient());
        } else {
            Intent text = new Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", number, null));
            if (text.resolveActivity(getPackageManager()) != null) {
                dialog.setNeutralButton("Text only", (d, which) -> openPlainText(number, ""));
            }
        }
        dialog.show();
    }

    private void openPlainText(String number, String body) {
        Intent draft = new Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", number, null));
        if (!body.isEmpty()) draft.putExtra("sms_body", body);
        try {
            startActivity(draft);
        } catch (ActivityNotFoundException | SecurityException error) {
            showNotice("Could not open your texting app", body.isEmpty()
                ? "Open your texting app and enter the recipient there."
                : "Copy the published link and paste it into a message.");
        }
    }

    private void choosePublish() {
        askPublisherKey(false, key -> {
            publisherKey = key;
            call("DysociateAndroid.publishThread()");
        });
    }

    private void askPublisherKey(boolean removing, Consumer<String> action) {
        EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        field.setHint("Publisher key");
        field.setText(publisherKey);
        FrameLayout content = new FrameLayout(this);
        content.setPadding(dp(24), 0, dp(24), 0);
        content.addView(field, new FrameLayout.LayoutParams(-1, -2));
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
            .setTitle(removing ? "Remove published copy" : "Publish thread")
            .setMessage(removing ? "The published link will stop opening this copy."
                : "Anyone with the published link can open this copy.")
            .setView(content)
            .setNegativeButton("Cancel", null)
            .setPositiveButton(removing ? "Remove" : "Publish", null);
        String recent = getPreferences(MODE_PRIVATE).getString("publishedLink", "");
        if (!removing && PublisherClient.validLink(recent)) {
            builder.setNeutralButton("Latest link", (dialog, which) -> showPublishedLink(recent));
        }
        AlertDialog dialog = builder.create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String key = field.getText().toString().trim();
            if (!PublisherClient.validKey(key)) {
                field.setError("Enter your publisher key.");
                return;
            }
            dialog.dismiss();
            action.accept(key);
        }));
        dialog.show();
    }

    private void publish(Export job, String key) {
        try {
            String link = PublisherClient.publish(job.file, key);
            getPreferences(MODE_PRIVATE).edit().putString("publishedLink", link).apply();
            runOnUiThread(() -> {
                completed(job, false, "", "Thread published. Choose how to share the link.", false);
                if (!isFinishing() && !isDestroyed()) showPublishedLink(link);
            });
        } catch (IllegalArgumentException error) {
            runOnUiThread(() -> {
                completed(job, false, "", error.getMessage(), true);
                showNotice("Could not publish the thread", error.getMessage());
            });
        }
    }

    private void showPublishedLink(String link) {
        new AlertDialog.Builder(this).setTitle("Published thread link")
            .setItems(new String[]{"Text link", "Copy link", "Remove link"}, (dialog, which) -> {
                if (which == 0) chooseTextRecipient(number -> openPlainText(number, link));
                else if (which == 1) {
                    getSystemService(ClipboardManager.class).setPrimaryClip(ClipData.newPlainText("dλsociate link", link));
                    Toast.makeText(this, "Link copied.", Toast.LENGTH_SHORT).show();
                } else askPublisherKey(true, key -> io.execute(() -> removePublishedLink(link, key)));
            })
            .setNegativeButton("Close", null).show();
    }

    private void removePublishedLink(String link, String key) {
        try {
            PublisherClient.remove(link, key);
            runOnUiThread(() -> {
                if (link.equals(getPreferences(MODE_PRIVATE).getString("publishedLink", ""))) {
                    getPreferences(MODE_PRIVATE).edit().remove("publishedLink").apply();
                }
                showNotice("Published copy removed", "The link has been turned off.");
            });
        } catch (IllegalArgumentException error) {
            runOnUiThread(() -> showNotice("Could not remove the published copy", error.getMessage()));
        }
    }

    private void showNotice(String title, String message) {
        if (isFinishing() || isDestroyed()) return;
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show();
    }

    private void contactUnavailable(Consumer<String> action, String message) {
        if (isFinishing() || isDestroyed()) return;
        new AlertDialog.Builder(this).setTitle("Could not choose a phone number").setMessage(message)
            .setPositiveButton("Enter number", (dialog, which) -> chooseTextRecipient(action))
            .setNegativeButton("Cancel", null).show();
    }

    private void showLaunch() {
        new AlertDialog.Builder(this).setTitle("Launch")
            .setItems(new String[]{"Open HTML in browser", "Open HTML in dλsociate"},
                (dialog, which) -> {
                    if (which == 0) call("DysociateAndroid.launchInBrowser()");
                    else chooseFile("thread");
                })
            .setNegativeButton("Cancel", null).show();
    }

    private void chooseFile(String kind) {
        if (picker != 0 || reading || incoming != null) return;
        boolean image = "image".equals(kind);
        if (!image && !"thread".equals(kind)) return;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        // Files received by Bluetooth or download providers sometimes have
        // application/octet-stream despite their .html extension.
        intent.setType(image ? "image/*" : "*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if ("thread".equals(kind)) {
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        }
        launchPicker(intent, image ? OPEN_IMAGE : OPEN_THREAD);
    }

    private boolean cameraAllowed() {
        return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    boolean chooseLivePhoto(Consumer<Uri> consumer) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType("image/*").putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/jpeg", "image/png"});
        if (!launchPicker(intent, LIVE_PHOTO)) return false;
        livePhoto = consumer;
        return true;
    }

    void recordLiveReel(Consumer<byte[]> consumer) {
        if (liveReel != null) { consumer.accept(null); return; }
        liveReel = consumer;
        if (cameraAllowed()) openReelRecorder();
        else requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO},
            CAMERA_PERMISSIONS);
    }

    private void openReelRecorder() {
        reelRecorder = new ReelRecorder(this, this::finishLiveReel);
    }

    private void finishLiveReel(byte[] clip) {
        Consumer<byte[]> consumer = liveReel;
        reelRecorder = null;
        liveReel = null;
        if (consumer != null && !isFinishing() && !isDestroyed()) consumer.accept(clip);
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code != CAMERA_PERMISSIONS || liveReel == null) return;
        if (cameraAllowed() && !isFinishing() && !isDestroyed()) openReelRecorder();
        else {
            finishLiveReel(null);
            tell("Allow camera and microphone access to record a reel.");
        }
    }

    private void stageOfflineReel(byte[] clip) {
        // Reuse the bounded WebView import channel. Sending the whole clip
        // through evaluateJavascript would exceed Android's IPC limits.
        reading = true;
        io.execute(() -> {
            File staged = null;
            try {
                staged = File.createTempFile("import-reel-", ".mp4", getCacheDir());
                Files.write(staged.toPath(), clip);
                Incoming selected = new Incoming(staged, null, "video", "reel.mp4", "video/mp4", false, null);
                runOnUiThread(() -> {
                    reading = false;
                    if (isFinishing() || isDestroyed()) { selected.file.delete(); return; }
                    incoming = selected;
                    call("DysociateAndroid.receive('video'," + JSONObject.quote(selected.token) + ",'reel.mp4','video/mp4')");
                });
            } catch (IOException error) {
                if (staged != null) staged.delete();
                runOnUiThread(() -> { reading = false; tell("Could not attach the recording. Try recording again."); });
            }
        });
    }

    private boolean launchPicker(Intent intent, int code) {
        if (picker != 0) return false;
        try {
            picker = code;
            startActivityForResult(intent, code);
            return true;
        } catch (android.content.ActivityNotFoundException error) {
            picker = 0;
            if (code != PICK_PHONE) tell("Android could not open the system file picker.");
            return false;
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        picker = 0;
        Uri uri = result == RESULT_OK && data != null ? data.getData() : null;
        if (request == SAVE) {
            Export job;
            synchronized (this) { job = active; }
            if (job == null) return;
            if (uri == null) completed(job, false, "", "Save canceled. Your thread is still here.", false);
            else {
                retainGrant(uri, data.getFlags());
                io.execute(() -> save(job, uri, null));
            }
        } else if (request == LIVE_PHOTO) {
            Consumer<Uri> consumer = livePhoto;
            livePhoto = null;
            if (consumer != null) consumer.accept(uri);
        } else if (request == PICK_PHONE) {
            Consumer<String> action = contactRecipient;
            contactRecipient = null;
            if (uri != null && action != null) readContactPhone(uri, action);
        } else if (uri != null && (request == OPEN_THREAD || request == OPEN_IMAGE)) {
            boolean writable = (data.getFlags() & Intent.FLAG_GRANT_WRITE_URI_PERMISSION) != 0;
            if (request == OPEN_THREAD) retainGrant(uri, data.getFlags());
            importFile(uri, request == OPEN_IMAGE ? "image" : "thread", writable);
        }
    }

    private void readContactPhone(Uri uri, Consumer<String> action) {
        reading = true;
        io.execute(() -> {
            // The system picker grants temporary access to the chosen phone
            // number. The app never queries or keeps the address book.
            String recipient = "";
            try (Cursor row = getContentResolver().query(uri, new String[]{Phone.NUMBER}, null, null, null)) {
                if (row != null && row.moveToFirst()) recipient = normalizePhone(row.getString(0));
            } catch (RuntimeException ignored) { /* The contact may have been removed. */ }
            String selected = recipient;
            runOnUiThread(() -> {
                reading = false;
                if (isFinishing() || isDestroyed()) return;
                if (selected.isEmpty()) contactUnavailable(action, "Android could not read the selected phone number.");
                else action.accept(selected);
            });
        });
    }

    private void importFile(Uri uri, String kind, boolean writable) {
        if (reading || incoming != null || !"content".equals(uri.getScheme())) return;
        reading = true;
        io.execute(() -> {
            File staged = null;
            try {
                boolean thread = "thread".equals(kind);
                String mime = thread ? "text/html" : getContentResolver().getType(uri);
                if (mime == null) mime = "application/octet-stream";
                staged = File.createTempFile("import-", ".tmp", getCacheDir());
                MessageDigest digest = sha256();
                try (InputStream input = getContentResolver().openInputStream(uri);
                     OutputStream output = new FileOutputStream(staged)) {
                    transfer(input, output, thread ? THREAD_LIMIT : MEDIA_LIMIT, digest);
                }
                Incoming selected = new Incoming(staged, uri, kind, displayName(uri, thread ? "index.html" : "Attachment"),
                    mime, writable && thread, digest.digest());
                runOnUiThread(() -> {
                    reading = false;
                    if (isFinishing() || isDestroyed()) { selected.file.delete(); return; }
                    incoming = selected;
                    call("DysociateAndroid.receive(" + JSONObject.quote(selected.kind) + ","
                        + JSONObject.quote(selected.token) + "," + JSONObject.quote(selected.name) + ","
                        + JSONObject.quote(selected.mime) + ")");
                });
            } catch (IOException | RuntimeException error) {
                if (staged != null) staged.delete();
                runOnUiThread(() -> {
                    reading = false;
                    tell("Could not read that file. Choose an HTML thread under 64 MB or media of 20 MB or smaller.");
                });
            }
        });
    }

    private void openOfflineLibrary() {
        File[] copies = LiveThreadActivity.library(this).listFiles(file -> file.isFile() && file.getName().endsWith(".html"));
        if (copies == null || copies.length == 0) {
            new AlertDialog.Builder(this).setTitle("Offline threads")
                .setMessage("Choose Save offline in a live thread to keep it here.")
                .setPositiveButton("Done", null).show();
            return;
        }
        Arrays.sort(copies, (left, right) -> right.getName().compareTo(left.getName()));
        String[] titles = Arrays.stream(copies).map(file -> {
            String name = file.getName();
            int separator = name.indexOf(" - ");
            return separator >= 17 ? name.substring(0, 17) + " · " + name.substring(separator + 3, name.length() - 5) : name;
        }).toArray(String[]::new);
        new AlertDialog.Builder(this).setTitle("Offline threads")
            .setItems(titles, (dialog, selected) -> {
                Uri uri = SharedFiles.offlineUri(copies[selected]);
                new AlertDialog.Builder(this).setTitle("Open offline thread")
                    .setPositiveButton("Open in browser", (choice, button) -> launchHtmlInBrowser(uri, (failed, message) -> {
                        if (failed) showNotice("Could not open in browser", message);
                    }))
                    .setNeutralButton("Open in app", (choice, button) -> importFile(uri, "thread", true))
                    .setNegativeButton("Cancel", null).show();
            })
            .setNegativeButton("Cancel", null).show();
    }

    private void dispatch(Export job) {
        if (isFinishing() || isDestroyed()) { completed(job, false, "", "", false); return; }
        if (job.file.length() == 0 || job.file.length() > THREAD_LIMIT) {
            completed(job, false, "", "The file exceeds 64 MB. Use fewer or smaller images.", true);
            return;
        }
        if ("publish".equals(job.mode)) {
            String key = publisherKey;
            io.execute(() -> publish(job, key));
            return;
        }
        if (Arrays.asList("share", "email", "browser", "text").contains(job.mode)) {
            io.execute(() -> prepareExternalCopy(job));
            return;
        }
        Document target = document;
        if (!"copy".equals(job.mode) && target != null) {
            io.execute(() -> save(job, target.uri, target));
        } else if ("auto".equals(job.mode)) {
            completed(job, false, "", "", false);
        } else {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("text/html");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            intent.putExtra(Intent.EXTRA_TITLE, job.name);
            if (!launchPicker(intent, SAVE)) completed(job, false, "", "Could not choose a save location.", true);
        }
    }

    private void save(Export job, Uri uri, Document expected) {
        String name = displayName(uri, job.name);
        if (SharedFiles.isOfflineUri(uri)) {
            saveOfflineCopy(job, uri, expected, name);
            return;
        }
        File original = null;
        boolean writeStarted = false;
        boolean keepBackup = false;
        try {
            if (expected != null) {
                // SAF providers do not share an atomic replacement API. Stage
                // the complete output first, check for external edits, and
                // keep the last bytes available to restore if a write fails.
                original = File.createTempFile("backup-", ".tmp", getCacheDir());
                byte[] current = readDocument(uri, original);
                if (!Arrays.equals(expected.hash, current)) {
                    setDocument(null);
                    runOnUiThread(() -> completed(job, false, "", "The file changed elsewhere. Use Save a copy.", true));
                    return;
                }
            }
            writeStarted = true;
            byte[] hash = writeDocument(uri, job.file);
            // Each successful write advances the epoch. If Android kills the
            // process before IndexedDB checkpoints this version, an older
            // snapshot cannot bind to the newer file and overwrite its posts.
            setDocument(new Document(uri, name, hash));
            runOnUiThread(() -> completed(job, true, name, "Saved " + name + ".", false));
        } catch (IOException | RuntimeException error) {
            // A provider can invalidate a document ID when another app
            // replaces the file. Stop automatic retries against that URI.
            // The current thread remains in the editor and its checkpoint.
            if (expected != null && !writeStarted) setDocument(null);
            boolean restored = !writeStarted || original == null;
            if (writeStarted && original != null) {
                try { writeDocument(uri, original); restored = true; } catch (IOException | RuntimeException ignored) {}
            }
            String message = restored ? "Could not save. Your work is still here. Try Save a copy."
                : "The original file could not be restored after a write error. Save a copy of your current thread.";
            if (!restored) {
                setDocument(null);
                // Keep the old bytes if the provider fails a second time.
                // The user can still export the new version to another URI.
                keepBackup = true;
            }
            runOnUiThread(() -> completed(job, false, "", message, true));
        } finally {
            if (original != null && !keepBackup) original.delete();
        }
    }

    private void saveOfflineCopy(Export job, Uri uri, Document expected, String name) {
        File stage = null;
        try {
            File target = new File(LiveThreadActivity.library(this), uri.getLastPathSegment()).getCanonicalFile();
            if (!target.getParentFile().equals(LiveThreadActivity.library(this).getCanonicalFile()) || !target.isFile())
                throw new IOException("Saved copy is unavailable");
            stage = File.createTempFile("edit-", ".tmp", target.getParentFile());
            MessageDigest digest = sha256();
            try (InputStream input = new FileInputStream(job.file); OutputStream output = new FileOutputStream(stage)) {
                transfer(input, output, THREAD_LIMIT, digest);
            }
            if (expected != null && !Arrays.equals(expected.hash, readDocument(uri, null))) {
                setDocument(null);
                runOnUiThread(() -> completed(job, false, "", "The copy changed elsewhere. Use Save a copy.", true));
                return;
            }
            Files.move(stage.toPath(), target.toPath(), java.nio.file.StandardCopyOption.ATOMIC_MOVE,
                java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            setDocument(new Document(uri, name, digest.digest()));
            runOnUiThread(() -> completed(job, true, name, "Saved " + name + ".", false));
        } catch (IOException | RuntimeException error) {
            runOnUiThread(() -> completed(job, false, "", "Could not update this offline file. Try Save a copy.", true));
        } finally {
            if (stage != null) stage.delete();
        }
    }

    private byte[] readDocument(Uri uri, File copy) throws IOException {
        MessageDigest digest = sha256();
        try (InputStream input = getContentResolver().openInputStream(uri);
             OutputStream output = copy == null ? null : new FileOutputStream(copy)) {
            transfer(input, output, THREAD_LIMIT, digest);
        }
        return digest.digest();
    }

    private byte[] writeDocument(Uri uri, File file) throws IOException {
        MessageDigest digest = sha256();
        try (InputStream input = new FileInputStream(file);
             OutputStream output = getContentResolver().openOutputStream(uri, "rwt")) {
            if (output == null) throw new IOException("No output stream");
            transfer(input, output, THREAD_LIMIT, digest);
        }
        return digest.digest();
    }

    private void prepareExternalCopy(Export job) {
        String folder = UUID.randomUUID().toString();
        File directory = new File(new File(getCacheDir(), "shared"), folder);
        try {
            if (!directory.mkdirs()) throw new IOException("Could not create export directory");
            Files.copy(job.file.toPath(), new File(directory, job.name).toPath());
            Uri uri = new Uri.Builder().scheme("content").authority(SharedFiles.AUTHORITY)
                .appendPath(folder).appendPath(job.name).build();
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) { completed(job, false, "", "", false); return; }
                if ("browser".equals(job.mode)) {
                    openBrowser(job, uri);
                    return;
                }
                Intent send = new Intent(Intent.ACTION_SEND).setType(job.mime);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.setClipData(ClipData.newUri(getContentResolver(), job.name, uri));
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                if ("text".equals(job.mode)) {
                    openTextComposer(job, send);
                    return;
                }
                if ("email".equals(job.mode)) {
                    openEmailComposer(job, send);
                    return;
                }
                try {
                    startActivity(Intent.createChooser(send, "Share " + job.name));
                    completed(job, false, "", "Choose an app to share " + job.name + ".", false);
                } catch (android.content.ActivityNotFoundException error) {
                    completed(job, false, "", "No share app is available. Save an HTML copy instead.", true);
                }
            });
        } catch (IOException | RuntimeException error) {
            runOnUiThread(() -> completed(job, false, "", "Could not prepare the attachment.", true));
        }
    }

    private void openTextComposer(Export job, Intent send) {
        // Use the configured SMS app and keep the exported file's read grant
        // when changing the share intent into an addressed compose intent.
        String messagingApp = Telephony.Sms.getDefaultSmsPackage(this);
        if (messagingApp == null) {
            // Some Android images report no SMS package even though the
            // system can resolve a preferred app for composing texts.
            ResolveInfo composer = getPackageManager().resolveActivity(
                new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")), PackageManager.MATCH_DEFAULT_ONLY);
            if (composer != null && composer.match != 0) messagingApp = composer.activityInfo.packageName;
        }
        if (messagingApp == null) {
            completed(job, false, "", "Choose a default texting app in Android Settings.", true);
            return;
        }
        send.setPackage(messagingApp);
        Uri address = Uri.fromParts("smsto", job.recipient, null);
        Intent draft = new Intent(send).setAction(Intent.ACTION_SENDTO).setDataAndType(address, job.mime);
        if (draft.resolveActivity(getPackageManager()) == null) {
            if (send.resolveActivity(getPackageManager()) == null) {
                completed(job, false, "", "Your default texting app does not accept HTML attachments.", true);
                return;
            }
            // Some HTML-capable apps advertise SENDTO only without a MIME
            // type. The attachment still carries text/html in its ClipData.
            draft.setData(address);
        }
        try {
            startActivity(draft);
            completed(job, false, "", "Check the recipient and HTML attachment in your text app before sending.", false);
        } catch (ActivityNotFoundException error) {
            completed(job, false, "", "Your default texting app could not open the addressed draft.", true);
        } catch (SecurityException error) {
            completed(job, false, "", "Android blocked access to the HTML attachment.", true);
        }
    }

    private void openBrowser(Export job, Uri uri) {
        launchHtmlInBrowser(uri, (failed, message) -> completed(job, false, "", message, failed));
    }

    private void launchHtmlInBrowser(Uri uri, BiConsumer<Boolean, String> result) {
        Intent view = new Intent(Intent.ACTION_VIEW).setDataAndType(uri, "text/html")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        // Match browsers using a generic HTTPS intent without loading its URL.
        // Only offer browsers that also accept this specific local HTML URI.
        Intent webLink = new Intent(Intent.ACTION_VIEW, Uri.parse("https://example.invalid/"))
            .addCategory(Intent.CATEGORY_BROWSABLE);
        Map<String, CharSequence> browsers = matchingApps(webLink, view);
        if (browsers.isEmpty()) {
            result.accept(true, "No installed browser can open local HTML. Use the dλsociate app to open this thread.");
            return;
        }
        Consumer<String> launch = pkg -> {
            try {
                startActivity(view.setPackage(pkg));
                result.accept(false, "Opened in your browser. Save any browser edits as a separate copy.");
            } catch (ActivityNotFoundException | SecurityException error) {
                result.accept(true, "This browser could not open the HTML file.");
            }
        };
        ComponentName preferred = webLink.resolveActivity(getPackageManager());
        if (preferred != null && browsers.containsKey(preferred.getPackageName())) {
            launch.accept(preferred.getPackageName());
        } else {
            chooseTarget("Open HTML in browser", browsers, launch,
                () -> result.accept(false, "Browser launch canceled."));
        }
    }

    private void openEmailComposer(Export job, Intent send) {
        send.putExtra(Intent.EXTRA_SUBJECT, job.subject);
        send.putExtra(Intent.EXTRA_TEXT, job.body);
        // mailto identifies mail apps, but SEND is what carries the attachment.
        // Keep only packages that advertise both, and grant the file to the one
        // the user chooses. An unrestricted share sheet can offer text-only apps.
        Intent mailto = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
        Map<String, CharSequence> mailApps = matchingApps(mailto, send);
        if (mailApps.isEmpty()) {
            completed(job, false, "", "No compatible mail app found. Use Email draft (.eml) to share the prepared message.", true);
            return;
        }
        chooseTarget("Open email in", mailApps, pkg -> launchEmail(job, send, pkg), () -> cancelEmail(job));
    }

    private Map<String, CharSequence> matchingApps(Intent identity, Intent action) {
        PackageManager manager = getPackageManager();
        Map<String, CharSequence> matches = new LinkedHashMap<>();
        for (ResolveInfo app : manager.queryIntentActivities(identity, PackageManager.MATCH_DEFAULT_ONLY)) {
            String pkg = app.activityInfo.packageName;
            if (new Intent(action).setPackage(pkg).resolveActivity(manager) != null) {
                matches.put(pkg, app.activityInfo.applicationInfo.loadLabel(manager));
            }
        }
        return matches;
    }

    private void chooseTarget(String title, Map<String, CharSequence> targets, Consumer<String> select, Runnable cancel) {
        String[] packages = targets.keySet().toArray(new String[0]);
        if (packages.length == 1) {
            select.accept(packages[0]);
            return;
        }
        new AlertDialog.Builder(this).setTitle(title)
            .setItems(targets.values().toArray(new CharSequence[0]), (dialog, which) -> select.accept(packages[which]))
            .setNegativeButton("Cancel", (dialog, which) -> cancel.run())
            .setOnCancelListener(dialog -> cancel.run()).show();
    }

    private void launchEmail(Export job, Intent send, String pkg) {
        try {
            startActivity(send.setPackage(pkg));
            completed(job, false, "", "Email opened with the HTML attached. Choose a recipient in your mail app.", false);
        } catch (ActivityNotFoundException | SecurityException error) {
            completed(job, false, "", "Could not open that mail app. Use Email draft (.eml) to share the prepared message.", true);
        }
    }

    private void cancelEmail(Export job) {
        completed(job, false, "", "Email canceled.", true);
    }

    private void completed(Export job, boolean saved, String name, String message, boolean failed) {
        synchronized (this) {
            if (active != job) return;
            active = null;
        }
        job.file.delete();
        call("DysociateAndroid.writeResult(" + saved + "," + JSONObject.quote(name) + ","
            + JSONObject.quote(message) + "," + failed + ")");
    }

    private String displayName(Uri uri, String fallback) {
        try (Cursor row = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (row != null && row.moveToFirst() && row.getString(0) != null) return row.getString(0);
        } catch (RuntimeException ignored) {}
        return fallback;
    }

    private static String filename(String name, String mime) {
        if ("message/rfc822".equals(mime)) return "dysociate-email.eml";
        String cleaned = name.replaceAll("[\\\\/\\p{Cntrl}]", "_").trim();
        if (!cleaned.toLowerCase(java.util.Locale.ROOT).matches(".+\\.html?") || cleaned.length() > 120) return "index.html";
        return cleaned;
    }

    private static MessageDigest sha256() {
        try { return MessageDigest.getInstance("SHA-256"); }
        catch (NoSuchAlgorithmException error) { throw new IllegalStateException(error); }
    }

    private static void transfer(InputStream input, OutputStream output, int limit, MessageDigest digest) throws IOException {
        if (input == null) throw new IOException("No input stream");
        byte[] buffer = new byte[64 * 1024];
        int total = 0, count;
        while ((count = input.read(buffer)) != -1) {
            total += count;
            if (total > limit) throw new IOException("File too large");
            if (output != null) output.write(buffer, 0, count);
            if (digest != null) digest.update(buffer, 0, count);
        }
    }

    private void clearOldShares() {
        File[] directories = new File(getCacheDir(), "shared").listFiles();
        if (directories == null) return;
        long cutoff = System.currentTimeMillis() - 24 * 60 * 60 * 1000L;
        for (File directory : directories) {
            if (directory.lastModified() >= cutoff) continue;
            File[] files = directory.listFiles();
            if (files != null) for (File file : files) file.delete();
            directory.delete();
        }
    }

    @Override public void onBackPressed() { requestClose(); }

    private void requestClose() {
        if (termsOpen) { if (web == null) finish(); else restoreEditor(); return; }
        if (!ready) { finish(); return; }
        web.evaluateJavascript("DysociateAndroid.exitState()", state -> {
            if ("\"preview\"".equals(state)) call("DysociateAndroid.closePreview()");
            else if ("\"record\"".equals(state)) call("DysociateAndroid.closeRecorder()");
            else if ("\"reel\"".equals(state)) call("DysociateAndroid.closeReels()");
            else if ("\"busy\"".equals(state)) tell("Wait for the current operation to finish.");
            else if ("\"dirty\"".equals(state)) {
                new AlertDialog.Builder(this).setTitle("Save before closing?")
                    .setPositiveButton("Save and close", (d, w) -> call("DysociateAndroid.exit('save')"))
                    .setNeutralButton("Keep editing", null)
                    .setNegativeButton("Discard and close", (d, w) -> call("DysociateAndroid.exit('discard')")).show();
            } else call("DysociateAndroid.exit('keep')");
        });
    }

    @Override protected void onPause() {
        if (reelRecorder != null) reelRecorder.dismiss();
        if (ready) call("DysociateAndroid.pause()");
        super.onPause();
    }

    @Override protected void onDestroy() {
        ready = false;
        if (Build.VERSION.SDK_INT >= 33 && backCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);
        }
        Incoming selected = incoming;
        incoming = null;
        if (selected != null) selected.file.delete();
        synchronized (this) {
            if (active != null && (!active.staged || picker == SAVE)) {
                try { active.writer.close(); } catch (IOException ignored) {}
                active.file.delete();
                active = null;
            }
        }
        if (web != null) {
            web.removeJavascriptInterface("DysociateDevice");
            frame.removeView(web);
            web.destroy();
            web = null;
        }
        io.shutdown();
        super.onDestroy();
    }
}
