# dλsociate

The anti-AI / social media interface

**WE ARE THE SERVER. DATA = FREEDOM.**

Create a live thread. Share the link. Completely anonymous. Anyone with an open
thread link can join in a browser. The Windows and Android apps can also save
threads as portable HTML files you can use offline.

- [Create a live thread](https://dysociate.org/t/new)
- [Download for Windows or Android](https://dysociate.org/)
- [Help](https://dysociate.org/guide.html)

This November 16, 2026 snapshot covers **Windows 1.8.8**, **Android 1.8.9**,
and the current website and live Worker. It includes the public forum,
the invitation-only A Voice for Women forum, the donation inquiry form,
and the featured-art gallery and archive.

## Build from source

Run the commands from the repository root in PowerShell. Use a Windows Python
installation with Tcl/Tk and set up the build environment.

```powershell
py -3.11 -m venv .venv
& '.\.venv\Scripts\python.exe' -m pip install -r '.\python_pagebuilder\requirements-build.txt'
```

### Windows

Install Visual Studio Build Tools with C# support and Inno Setup 6. The app
uses Microsoft Edge WebView2 Runtime for its embedded live viewer and reel
recorder. Replace the compiler path with your copy of `ISCC.exe`.

```powershell
& '.\python_pagebuilder\build_distribution.ps1' -WebRelease `
    -Python (Resolve-Path '.\.venv\Scripts\python.exe').Path `
    -InnoCompiler 'C:\path\to\ISCC.exe'
```

The installer is written to `python_pagebuilder/release/dysociate/dysociate-setup.exe`.
See the [Windows source guide](python_pagebuilder/README.md) and
the [user manual](python_pagebuilder/docs/User_Manual.md).

### Android

Install JDK 17, Android SDK Platform 36, and Android Build-Tools 36.0.0.
Replace the SDK and JDK paths with your own. The APK is written to `dysociate_android/dist`.

```powershell
& '.\dysociate_android\build.ps1' `
    -SdkRoot 'C:\Android\Sdk' -JavaHome 'C:\Java\jdk-17' `
    -Python (Resolve-Path '.\.venv\Scripts\python.exe').Path
```

See the [Android build guide](dysociate_android/README.md) for release signing
and emulator tests.

### Browser and website

Generate the offline editor, then open its `index.html` in a browser.

```powershell
& '.\.venv\Scripts\python.exe' '.\python_pagebuilder\build_browser.py' '.\build\browser'
```

Follow the [live Worker guide](dysociate_live/README.md#run-locally) to run the
live browser app locally with Node.js and Wrangler. The public homepage source
lives in `dysociate_placeholder/dist`. See the
[site release guide](dysociate_placeholder/RELEASE.md) to stage its downloads.
The [forum guide](dysociate_forum/README.md) covers the moderation setup and
local tests. The [iPhone browser/PWA guide](dysociate_ios_web/README.md)
documents the optional offline browser edition.

## License

Copyright (c) 2026 Luna Love ~ LunaSoft. The software is licensed under
[GNU GPL v3 or later](LICENSE).

Created by luna love · [About](https://dysociate.org/about.html)
