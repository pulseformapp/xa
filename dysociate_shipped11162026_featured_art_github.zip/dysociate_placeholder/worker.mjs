/* Copyright (c) 2026 Luna Love ~ LunaSoft. GPL-3.0-or-later. */

import {supportPage} from "./support.mjs";
import {artArchive, withFeaturedArt} from "./art-features.mjs";

async function readCount(request, env) {
    try {
        const stats = await env.LIVE.fetch(new URL("/api/v1/stats", request.url), {signal: AbortSignal.timeout(2000)});
        if (stats.ok) {
            const {liveThreadsCreated} = await stats.json();
            if (Number.isSafeInteger(liveThreadsCreated) && liveThreadsCreated >= 0) return liveThreadsCreated;
        }
    } catch { /* The homepage can still load if the count is temporarily unavailable. */ }
    return null;
}

export default {
    async fetch(request, env) {
        const {pathname} = new URL(request.url);
        if (["GET", "POST"].includes(request.method) && ["/support", "/support.html"].includes(pathname)) return supportPage(request, env);
        if (request.method === "GET" && ["/art-archive", "/art-archive.html"].includes(pathname)) {
            const template = await env.ASSETS.fetch(new Request(request.url));
            if (!template.ok) return template;
            const response = new Response(template.body, template);
            response.headers.delete("ETag");
            response.headers.delete("Last-Modified");
            response.headers.set("Cache-Control", "no-store");
            return artArchive(response);
        }
        if (request.method !== "GET" || !["/", "/index.html"].includes(pathname)) return env.ASSETS.fetch(request);

        // The asset ETag describes the template. Fetch its full body even if
        // the browser has that ETag, since the number is rendered separately.
        const [page, count] = await Promise.all([
            env.ASSETS.fetch(new Request(request.url)), readCount(request, env),
        ]);
        if (!page.ok) return page;
        const response = new Response(page.body, page);
        response.headers.delete("ETag");
        response.headers.delete("Last-Modified");
        response.headers.set("Cache-Control", "no-store");
        const rewriter = withFeaturedArt(new HTMLRewriter());
        if (count !== null) {
            rewriter.on("#thread-count", {element: node => node.setAttribute("data-count", String(count))})
                .on("#thread-count strong", {element: node => node.setInnerContent(count.toLocaleString("en-US"))})
                .on("#thread-count span", {element: node => node.setInnerContent(count === 1 ? "live thread created" : "live threads created")});
        }
        return rewriter.transform(response);
    },
};
