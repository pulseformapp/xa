/* Copyright (c) 2026 Luna Love ~ LunaSoft. GPL-3.0-or-later. */

import features from "./art-features.json";

const history = [...features].sort((left, right) => right.featuredOn.localeCompare(left.featuredOn));
const dateFormat = new Intl.DateTimeFormat("en-US", {dateStyle: "long", timeZone: "UTC"});
const entities = {"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"};

function escape(value) {
    return String(value).replace(/[&<>"']/g, character => entities[character]);
}

function preview({image, alt, width, height}, className, eager) {
    return `<img class="${className}" src="${escape(image)}" width="${escape(width)}" height="${escape(height)}" alt="${escape(alt)}" ${eager ? 'fetchpriority="high"' : 'loading="lazy"'}>`;
}

function attribution(feature) {
    const submittedTitle = feature.title?.trim();
    return {
        title: submittedTitle || "Title not provided",
        artist: feature.credit?.trim() || "Anonymous",
        hasTitle: Boolean(submittedTitle),
    };
}

function credits({title, artist}) {
    return `<span class="art-title">TITLE: <strong>${escape(title)}</strong></span><span class="art-artist">FEATURED ARTIST: ${escape(artist)}</span>`;
}

function figure(feature, eager = false) {
    const {image, fullImage = image, featuredOn, note} = feature;
    const identity = attribution(feature);
    const label = identity.hasTitle ? identity.title : `artwork by ${identity.artist}`;
    const date = dateFormat.format(new Date(`${featuredOn}T00:00:00Z`));
    return `<figure class="art-figure">
      <a class="art-link" href="${escape(fullImage)}" data-art-view data-art-title="${escape(identity.title)}" data-art-credit="${escape(identity.artist)}" aria-label="View ${escape(label)} full screen">
        ${preview(feature, "art-preview", eager)}
        <span class="art-expand" aria-hidden="true">⤢</span>
      </a>
      <figcaption class="art-caption">
        <div>${credits(identity)}</div>
        <time datetime="${escape(featuredOn)}">Featured ${escape(date)}</time>
        ${note ? `<p>${escape(note)}</p>` : ""}
      </figcaption>
    </figure>`;
}

const viewer = `<dialog id="art-viewer" aria-labelledby="art-viewer-title">
  <header class="art-viewer-bar">
    <div><h2 id="art-viewer-title">TITLE: <span id="art-viewer-piece"></span></h2><p>FEATURED ARTIST: <span id="art-viewer-credit"></span></p></div>
    <form method="dialog"><button type="submit" autofocus>Close <span aria-hidden="true">×</span></button></form>
  </header>
  <img id="art-viewer-image" alt="">
</dialog>`;

function withViewer(rewriter) {
    return rewriter.on("body", {element: node => node.append(viewer, {html: true})});
}

export function withFeaturedArt(rewriter) {
    const feature = history[0];
    const artwork = `<a class="art-window" href="/art-archive" aria-label="View featured art and archive">
      ${preview(feature, "art", true)}
    </a><figcaption>${credits(attribution(feature))}</figcaption>`;
    return rewriter.on("#featured-art", {element: node => node.setInnerContent(artwork, {html: true})});
}

export function artArchive(page) {
    const [current, ...past] = history;
    // The newest feature also drives the homepage. Older entries remain
    // here with their original dates when a new approved entry is added.
    const collection = `<section class="art-archive-current" aria-labelledby="art-current-heading">
      <h2 id="art-current-heading">Currently featured</h2>${figure(current, true)}
    </section>
    <section aria-labelledby="art-past-heading">
      <h2 id="art-past-heading">Past features</h2>
      ${past.length ? `<div class="art-archive-grid">${past.map(entry => figure(entry)).join("")}</div>`
          : '<p class="art-archive-empty">Past artwork will appear here as new pieces are featured.</p>'}
    </section>`;
    return withViewer(new HTMLRewriter().on("#art-history", {element: node => node.setInnerContent(collection, {html: true})})).transform(page);
}
