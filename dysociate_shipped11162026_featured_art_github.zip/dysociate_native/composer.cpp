/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
#include "composer.h"

#include <algorithm>
#include <cmath>

namespace dysociate {

Layout layout(int width, float scale, Screen screen) {
    const auto px = [scale](int dp) { return static_cast<int>(std::lround(dp * scale)); };
    const int inset = std::min(px(22), width / 8);
    const int content = width - 2 * inset;
    const int gap = std::min(px(8), content / 8);
    const int button = std::min(px(148), (content - gap) / 2);
    if (screen != Screen::Draft) {
        const int half = (content - gap) / 2;
        const int second = inset + half + gap;
        const bool share = screen == Screen::LinkWithShare;
        Layout ready{};
        auto& fields = ready.fields;
        fields[Heading] = {inset, px(14), content, px(42)};
        fields[TitleLabel] = {inset, px(65), content, px(44)};
        fields[BodyLabel] = {inset, px(117), content, px(28)};
        fields[Body] = {inset, px(150), content, px(46)};
        fields[Status] = {inset, px(203), content, px(68)};
        fields[Create] = {inset, px(278), half, px(52)};
        fields[Copy] = {second, px(278), half, px(52)};
        if (share) fields[Share] = {inset, px(340), content, px(52)};
        fields[More] = {inset, px(share ? 402 : 340), half, px(52)};
        fields[Cancel] = {second, px(share ? 402 : 340), half, px(52)};
        ready.height = px(share ? 472 : 410);
        return ready;
    }
    return {{{
        {inset, px(14), content, px(42)},
        {inset, px(65), content, px(28)},
        {inset, px(96), content, px(48)},
        {inset, px(153), content, px(28)},
        {inset, px(184), content, px(104)},
        {inset, px(296), content, px(74)},
        {inset, px(374), content, px(48)},
        {width - inset - 2 * button - gap, px(430), button, px(52)},
        {width - inset - button, px(430), button, px(52)},
    }}, px(500)};
}

void paint(std::uint32_t* pixels, int width, int height, int stride, float scale, Screen screen) {
    // The platform owns the buffer. Coordinates are clipped here so a narrow
    // window and the partial frame during a resize can use the same painter.
    if (!pixels || width <= 0 || height <= 0 || width > max_width || height > max_height || stride < width) return;
    const auto fill = [&](Rect rect, std::uint32_t color) {
        const int right = std::min(width, rect.x + rect.width);
        const int bottom = std::min(height, rect.y + rect.height);
        const int left = std::max(0, rect.x);
        for (int y = std::max(0, rect.y); y < bottom && left < right; ++y) {
            std::fill(pixels + y * stride + left, pixels + y * stride + right, color);
        }
    };
    const auto frame = [&](Rect rect, std::uint32_t border, std::uint32_t inside) {
        fill({rect.x - 1, rect.y - 1, rect.width + 2, rect.height + 2}, border);
        fill(rect, inside);
    };
    for (int y = 0; y < height; ++y) {
        fill({0, y, width, 1}, y % 4 == 0 ? 0xff12091c : 0xff090512);
    }
    const auto ui = layout(width, scale, screen);
    const auto header = ui.fields[Heading];
    fill({header.x, header.y + header.height, header.width, 1}, accent_color);
    if (screen == Screen::Draft) frame(ui.fields[Title], 0xffb55b9d, field_color);
    else frame(ui.fields[Copy], 0xffb55b9d, field_color);
    if (screen == Screen::LinkWithShare) frame(ui.fields[Share], 0xffb55b9d, field_color);
    frame(ui.fields[Body], 0xffb55b9d, field_color);
    frame(ui.fields[More], 0xffb55b9d, field_color);
    frame(ui.fields[Cancel], 0xffb55b9d, field_color);
    frame(ui.fields[Create], accent_color, accent_color);
}

}  // namespace dysociate
