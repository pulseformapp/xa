// Copyright (c) 2026 Luna Love ~ LunaSoft
// SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

internal static class LiveThreadWindow
{
    private static readonly Regex ThreadPath = new Regex(
        @"\A/t/(?:l-)?[a-z0-9]{1,12}\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}\z");

    private static async Task SaveOffline(WebView2 viewer, Uri thread, string library, Label status)
    {
        string stage = null;
        try
        {
            if (thread.AbsoluteUri != viewer.CoreWebView2.Source)
                throw new InvalidOperationException("Open the live thread before saving.");
            var resources = AppDomain.CurrentDomain.BaseDirectory;
            var json = new JavaScriptSerializer { MaxJsonLength = 2 * 1024 * 1024 };
            await viewer.ExecuteScriptAsync(File.ReadAllText(Path.Combine(resources, "live-snapshot.js")));
            string title;
            while (true)
            {
                var raw = await viewer.ExecuteScriptAsync("window.dysociateOfflineCapture?.status()");
                var capture = json.DeserializeObject(raw) as System.Collections.Generic.Dictionary<string, object>;
                if (capture == null) throw new InvalidOperationException("The page closed before the thread could be saved.");
                if ((string)capture["state"] == "ready") { title = (string)capture["title"]; break; }
                if ((string)capture["state"] == "error") throw new InvalidOperationException((string)capture["text"]);
                status.Text = (string)capture["text"];
                await Task.Delay(150);
            }
            Directory.CreateDirectory(library);
            var label = Regex.Replace(title, @"[^\p{L}\p{N} _-]", "_").Trim();
            if (label.Length > 54) label = label.Substring(0, 54).Trim();
            if (label.Length == 0) label = "Thread";
            var id = DateTime.Now.ToString("yyyy-MM-dd HHmmss") + " " + Guid.NewGuid().ToString("N").Substring(0, 8);
            var destination = Path.Combine(library, id + " - " + label + ".html");
            stage = Path.Combine(library, Guid.NewGuid().ToString("N") + ".tmp");
            status.Text = "Writing offline HTML…";
            using (var file = new FileStream(stage, FileMode.CreateNew, FileAccess.Write))
            using (var writer = new StreamWriter(file, new UTF8Encoding(false)))
            {
                writer.Write(File.ReadAllText(Path.Combine(resources, "offline-head.txt")));
                for (int offset = 0; ;)
                {
                    var piece = json.Deserialize<string>(
                        await viewer.ExecuteScriptAsync("window.dysociateOfflineCapture.take(" + offset + ")"));
                    if (piece == null) throw new InvalidOperationException("The download ended before the file was complete.");
                    if (piece.Length == 0) break;
                    offset += piece.Length;
                    if (offset > 62 * 1024 * 1024) throw new IOException("Thread is too large for the offline editor.");
                    writer.Write(piece);
                }
                writer.Write(File.ReadAllText(Path.Combine(resources, "offline-tail.txt")));
            }
            if (new FileInfo(stage).Length > 64L * 1024 * 1024) throw new IOException("Thread is too large for the offline editor.");
            File.Move(stage, destination);
            status.Text = "Saved. Find it under Offline threads in the editor.";
        }
        catch (InvalidOperationException error) { if (!status.IsDisposed) status.Text = error.Message; }
        catch (Exception) { if (!status.IsDisposed) status.Text = "Could not save the whole thread. Try again."; }
        finally
        {
            if (stage != null)
                try { File.Delete(stage); } catch (IOException) {} catch (UnauthorizedAccessException) {}
            if (!viewer.IsDisposed && viewer.CoreWebView2 != null)
                try { await viewer.ExecuteScriptAsync("window.dysociateOfflineCapture?.clear()"); } catch (Exception) {}
        }
    }

    [STAThread]
    private static int Main(string[] args)
    {
        Uri thread;
        if ((args.Length != 2 && args.Length != 3)
            || !Uri.TryCreate(args[0], UriKind.Absolute, out thread)
            || args[0] != thread.AbsoluteUri || !ThreadPath.IsMatch(thread.AbsolutePath)
            || thread.Query.Length != 0 || thread.Fragment.Length != 0 || thread.UserInfo.Length != 0)
            return 2;
        string origin = thread.GetLeftPart(UriPartial.Authority);
        if (origin != "https://dysociate.org" && origin != "https://dysociate-live-pilot.pulseform.workers.dev"
            && !(args.Length == 3 && args[2] == "--local" && origin == "http://127.0.0.1:8795"))
            return 2;

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        using (var window = new Form())
        using (var viewer = new WebView2())
        {
            window.Text = "Live thread · dλsociate";
            window.ClientSize = new Size(780, 740);
            window.MinimumSize = new Size(380, 360);
            window.StartPosition = FormStartPosition.CenterScreen;
            window.BackColor = Color.FromArgb(9, 5, 18);
            viewer.Dock = DockStyle.Fill;
            viewer.DefaultBackgroundColor = window.BackColor;
            var controls = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(6) };
            var open = new Button { Text = "Open in browser", AutoSize = true };
            var copy = new Button { Text = "Copy link", AutoSize = true };
            var retry = new Button { Text = "Retry", AutoSize = true, Enabled = false };
            var save = new Button { Text = "Save offline", AutoSize = true, Enabled = false };
            var status = new Label { Text = "Opening live thread…", ForeColor = Color.FromArgb(255, 118, 207),
                AutoSize = true, Margin = new Padding(8, 8, 3, 0) };
            controls.Controls.AddRange(new Control[] {open, copy, save, retry, status});
            window.Controls.Add(viewer);
            window.Controls.Add(controls);
            open.Click += delegate
            {
                try { Process.Start(new ProcessStartInfo(thread.AbsoluteUri) { UseShellExecute = true }); }
                catch (System.ComponentModel.Win32Exception) { status.Text = "Could not open the browser."; }
            };
            copy.Click += delegate
            {
                try { Clipboard.SetText(thread.AbsoluteUri); status.Text = "Link copied."; }
                catch (System.Runtime.InteropServices.ExternalException) { status.Text = "Clipboard unavailable. Try again."; }
            };
            retry.Click += delegate { viewer.CoreWebView2.Navigate(thread.AbsoluteUri); };
            var saving = false;
            window.FormClosing += (sender, closing) => { if (saving) closing.Cancel = true; };
            save.Click += async delegate
            {
                if (thread.AbsolutePath.StartsWith("/t/l-", StringComparison.Ordinal) &&
                    MessageBox.Show(window, "A saved HTML copy can be read by anyone who gets the file. Save this locked thread?",
                        "Save offline", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                        != DialogResult.Yes) return;
                saving = true;
                save.Enabled = retry.Enabled = false;
                try
                {
                    await SaveOffline(viewer, thread, Path.Combine(Path.GetDirectoryName(args[1]), "OfflineThreads"), status);
                }
                finally
                {
                    saving = false;
                    if (!save.IsDisposed) save.Enabled = true;
                }
            };
            window.Shown += async delegate
            {
                try
                {
                    var environment = await CoreWebView2Environment.CreateAsync(userDataFolder: args[1]);
                    if (window.IsDisposed) return;
                    await viewer.EnsureCoreWebView2Async(environment);
                    if (window.IsDisposed) return;
                    var view = viewer.CoreWebView2;
                    view.Settings.AreHostObjectsAllowed = false;
                    view.Settings.IsWebMessageEnabled = false;
                    view.Settings.AreDevToolsEnabled = false;
                    view.Settings.AreDefaultContextMenusEnabled = false;
                    // Serve a single confirmed invite in this window. The
                    // embedded page receives no file/editor bridge or token.
                    view.NavigationStarting += (sender, navigation) =>
                    {
                        navigation.Cancel = navigation.Uri != thread.AbsoluteUri;
                        if (!navigation.Cancel) status.Text = "Opening live thread…";
                    };
                    view.NewWindowRequested += (sender, request) => request.Handled = true;
                    view.DownloadStarting += (sender, download) => download.Cancel = true;
                    view.PermissionRequested += (sender, request) =>
                    {
                        request.State = CoreWebView2PermissionState.Deny;
                        request.SavesInProfile = false;
                    };
                    view.NavigationCompleted += (sender, navigation) =>
                    {
                        retry.Enabled = !navigation.IsSuccess;
                        save.Enabled = navigation.IsSuccess && !saving;
                        status.Text = navigation.IsSuccess ? "" : "Could not load the thread. Check your connection.";
                    };
                    view.Navigate(thread.AbsoluteUri);
                }
                catch (Exception)
                {
                    if (!window.IsDisposed)
                        status.Text = "Viewer unavailable. Check the Microsoft Edge WebView2 Runtime.";
                }
            };
            Application.Run(window);
        }
        return 0;
    }
}
