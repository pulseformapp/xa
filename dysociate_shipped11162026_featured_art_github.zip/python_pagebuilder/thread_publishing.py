"""Publish a thread snapshot and manage its browser link.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""

import http.client
import json
import re
import uuid


HOST = "threads.dysociate.org"
ORIGIN = "https://" + HOST
MAX_BYTES = 8 * 1024 * 1024
LINK_PATH = re.compile(r"/t/\d{3}-[a-f0-9]{32}")


def publisher_key_valid(value):
    return re.fullmatch(r"[A-Za-z0-9_-]{32,256}", value) is not None


def _link_path(link):
    path = link.removeprefix(ORIGIN)
    if not link.startswith(ORIGIN + "/") or not LINK_PATH.fullmatch(path):
        raise ValueError("The service returned an invalid thread link.")
    return path


def _request(method, path, key, body=None, publish_id=None):
    if not publisher_key_valid(key):
        raise ValueError("Enter a valid publisher key.")
    headers = {"Authorization": "Bearer " + key}
    if body is not None:
        headers.update({"Content-Type": "text/html; charset=utf-8", "X-Publish-Id": publish_id})
    # The exact same ID can be retried if the response was lost after the
    # server stored the file. HTTPSConnection also keeps redirects explicit.
    for attempt in range(2):
        connection = http.client.HTTPSConnection(HOST, timeout=12)
        try:
            connection.request(method, path, body, headers)
            response = connection.getresponse()
            status = response.status
            data = response.read(4097)
        except (OSError, http.client.HTTPException):
            if attempt == 0:
                continue
            raise ValueError("Could not reach the publishing service. Check the connection and try again.") from None
        finally:
            connection.close()
        break
    if len(data) > 4096:
        raise ValueError("The publishing service returned an invalid response.")
    try:
        result = json.loads(data) if data else {}
    except (ValueError, UnicodeError):
        result = {}
    if not isinstance(result, dict):
        result = {}
    if status not in (200, 201, 204):
        if status == 401:
            raise ValueError("The publisher key was rejected.")
        reason = result.get("error")
        raise ValueError(reason if isinstance(reason, str) else "The publishing service returned HTTP " + str(status) + ".")
    return result


def publish_thread(path, key):
    with path.open("rb") as source:
        body = source.read(MAX_BYTES + 1)
    if len(body) > MAX_BYTES:
        raise ValueError("Published threads can be up to 8 MiB. Use fewer or smaller images.")
    link = _request("POST", "/api/threads", key, body, uuid.uuid4().hex).get("url")
    if not isinstance(link, str):
        raise ValueError("The publishing service returned an invalid thread link.")
    _link_path(link)
    return link


def remove_thread(link, key):
    _request("DELETE", "/api/threads/" + _link_path(link)[3:], key)
