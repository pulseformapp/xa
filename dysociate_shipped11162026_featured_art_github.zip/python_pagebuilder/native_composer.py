"""Win32 bridge for the optional native live composer.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""

import ctypes
import sys
from ctypes import wintypes
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from queue import Empty, SimpleQueue
from threading import Thread
from tkinter import TclError


Submit = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_int, wintypes.LPCWSTR, wintypes.LPCWSTR)
# Use a pointer rather than LPWSTR here. ctypes converts an LPWSTR callback
# argument to a Python string, which cannot write to the native status buffer.
Poll = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.POINTER(ctypes.c_wchar), ctypes.c_int)
LinkAction = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_int)

@dataclass(frozen=True)
class OptionsDraft:
    title: str
    body: str


@lru_cache(maxsize=1)
def _library():
    # Cache the DLL while Windows has a registered
    # window class pointing at code in that DLL.
    root = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
    return ctypes.CDLL(str(root / 'native' / 'dysociate_composer.dll'))


def _collector():
    compose = _library().DysociateComposeThreadWithOptions
    compose.argtypes = [wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.LPCWSTR, Submit, Poll]
    compose.restype = ctypes.c_int
    return compose


def _parent_window(dialog):
    get_ancestor = ctypes.windll.user32.GetAncestor
    get_ancestor.argtypes = [wintypes.HWND, wintypes.UINT]
    get_ancestor.restype = wintypes.HWND
    return get_ancestor(dialog.winfo_id(), 2) if dialog is not None else None  # GA_ROOT gets Tk's outer HWND.


def compose_thread(dialog, title, body, notice, work):
    windows_body = body.replace('\r\n', '\n').replace('\n', '\r\n')
    outcome = SimpleQueue()
    created = None
    options_draft = None

    @Submit
    def submit(action, new_title, new_body):
        nonlocal options_draft
        new_body = new_body.replace('\r\n', '\n')
        if action == 2:
            options_draft = OptionsDraft(new_title, new_body)
            return 1

        def run():
            try:
                outcome.put((True, work(new_title, new_body)))
            except Exception as error:
                # Always settle the pending state across the native callback
                # boundary, including an unexpected service client failure.
                outcome.put((False, str(error) or 'Could not create the thread. Try again.'))

        try:
            Thread(target=run, daemon=True).start()
        except RuntimeError:
            return 0
        return 1

    @Poll
    def poll(buffer, capacity):
        nonlocal created
        try:
            success, result = outcome.get_nowait()
        except Empty:
            return 0
        if success:
            created = result
            return 1
        # Leave space for the terminator and cut on a UTF-16 boundary. Error
        # messages can include characters represented by a surrogate pair.
        encoded = result.encode('utf-16-le', errors='replace')[:2 * (capacity - 1)]
        encoded = encoded.decode('utf-16-le', errors='ignore').encode('utf-16-le') + b'\0\0'
        ctypes.memmove(buffer, encoded, len(encoded))
        return -1

    if _collector()(_parent_window(dialog), title, windows_body, notice, submit, poll) < 0:
        raise OSError('The native preview could not open on this display.')
    return options_draft if options_draft is not None else created


def show_thread_link(dialog, thread, open_link, copy_link):
    show = _library().DysociateShowThreadLink
    show.argtypes = [wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR, LinkAction]
    show.restype = ctypes.c_int

    @LinkAction
    def action(kind):
        try:
            if kind == 1:
                return bool(open_link(thread.link))
            copy_link(thread.link)
            return 1
        except (OSError, RuntimeError, TclError):
            return 0

    # Return True for Manage thread and fall back to the full dialog if the
    # native result cannot open. The saved link remains available either way.
    return show(_parent_window(dialog), thread.title, thread.link, action) != 0
