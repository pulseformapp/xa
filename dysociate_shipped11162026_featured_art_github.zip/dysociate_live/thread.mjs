/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import {randomId} from "./identity.mjs";
import {mediaQuota} from "./media.mjs";
import {ThreadPush, pushSchema} from "./thread-push.mjs";

const schema = `
    CREATE TABLE IF NOT EXISTS thread (
        singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
        id TEXT NOT NULL,
        title TEXT NOT NULL,
        creator_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        access_mode TEXT NOT NULL CHECK (access_mode = 'wild-west'),
        head_seq INTEGER NOT NULL,
        schema_version INTEGER NOT NULL,
        invite_key_id TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS posts (
        id TEXT PRIMARY KEY,
        parent_id TEXT,
        author_id TEXT NOT NULL,
        display_name TEXT NOT NULL,
        body TEXT,
        created_at TEXT NOT NULL,
        created_seq INTEGER NOT NULL,
        updated_seq INTEGER NOT NULL,
        deleted_at TEXT,
        CHECK ((deleted_at IS NULL AND body IS NOT NULL) OR (deleted_at IS NOT NULL AND body IS NULL))
    );
    CREATE UNIQUE INDEX IF NOT EXISTS posts_created_seq ON posts (created_seq);
    CREATE UNIQUE INDEX IF NOT EXISTS posts_updated_seq ON posts (updated_seq);
    CREATE TABLE IF NOT EXISTS receipts (
        actor_id TEXT NOT NULL,
        operation_id TEXT NOT NULL,
        request_digest TEXT NOT NULL,
        post_id TEXT NOT NULL,
        PRIMARY KEY (actor_id, operation_id)
    );
    CREATE TABLE IF NOT EXISTS posting_window (
        singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
        minute INTEGER NOT NULL,
        accepted INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS attachments (
        post_id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        size INTEGER NOT NULL,
        duration REAL
    );
    CREATE TABLE IF NOT EXISTS attachment_parts (
        post_id TEXT NOT NULL,
        part INTEGER NOT NULL,
        bytes BLOB NOT NULL,
        PRIMARY KEY (post_id, part)
    );
    CREATE TABLE IF NOT EXISTS locked_access (
        singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
        code_verifier TEXT
    );
    CREATE TABLE IF NOT EXISTS join_requests (
        actor_id TEXT PRIMARY KEY,
        id TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'declined')),
        requested_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS pending_join_requests ON join_requests (state, requested_at);
    CREATE TABLE IF NOT EXISTS creator_browsers (actor_id TEXT PRIMARY KEY);
    CREATE TABLE IF NOT EXISTS creator_handoff (
        singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
        digest TEXT NOT NULL,
        expires INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS passkey_window (
        singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
        minute INTEGER NOT NULL,
        attempts INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS posts_parent ON posts (parent_id);
    CREATE TABLE IF NOT EXISTS reply_roots (
        post_id TEXT PRIMARY KEY,
        root_id TEXT NOT NULL,
        created_seq INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS replies_by_root ON reply_roots (root_id, created_seq);
    CREATE TABLE IF NOT EXISTS reply_totals (root_id TEXT PRIMARY KEY, count INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS reply_index_ready (singleton INTEGER PRIMARY KEY CHECK (singleton = 1));
    CREATE TRIGGER IF NOT EXISTS index_reply AFTER INSERT ON posts WHEN NEW.parent_id IS NOT NULL BEGIN
        INSERT INTO reply_roots VALUES (NEW.id,
            COALESCE((SELECT root_id FROM reply_roots WHERE post_id = NEW.parent_id), NEW.parent_id), NEW.created_seq);
        INSERT INTO reply_totals SELECT root_id, 1 FROM reply_roots WHERE post_id = NEW.id
            ON CONFLICT(root_id) DO UPDATE SET count = count + 1;
    END;
    CREATE TABLE IF NOT EXISTS thread_agreements (actor_id TEXT PRIMARY KEY, version TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS likes (
        post_id TEXT NOT NULL,
        actor_id TEXT NOT NULL,
        liked INTEGER NOT NULL,
        revision INTEGER NOT NULL,
        operation_id TEXT NOT NULL,
        PRIMARY KEY (post_id, actor_id)
    );
    CREATE TABLE IF NOT EXISTS like_totals (
        post_id TEXT PRIMARY KEY,
        count INTEGER NOT NULL,
        revision INTEGER NOT NULL
    );
`;

const partSize = 1024 * 1024;
const postsWithMedia = `SELECT posts.*, attachments.type, attachments.size, attachments.duration,
    reply_roots.root_id, COALESCE(reply_totals.count, 0) AS reply_count,
    parent.display_name AS parent_name, substr(parent.body, 1, 96) AS parent_excerpt
    FROM posts LEFT JOIN attachments ON attachments.post_id = posts.id
    LEFT JOIN reply_roots ON reply_roots.post_id = posts.id
    LEFT JOIN reply_totals ON reply_totals.root_id = COALESCE(reply_roots.root_id, posts.id)
    LEFT JOIN posts AS parent ON parent.id = posts.parent_id`;

function postRecord(row, grouped = false) {
    return {
        id: row.id,
        parentId: row.parent_id,
        authorId: row.author_id,
        displayName: row.display_name,
        body: row.body,
        createdAt: row.created_at,
        createdSeq: row.created_seq,
        updatedSeq: row.updated_seq,
        deletedAt: row.deleted_at,
        ...(grouped ? {
            rootId: row.root_id || row.id,
            rootReplyCount: row.reply_count ?? 0,
            ...(row.parent_id ? {parentContext: {name: row.parent_name, excerpt: row.parent_excerpt}} : {}),
        } : {}),
        ...(row.type ? {media: {type: row.type, size: row.size, ...(row.duration === null ? {} : {duration: row.duration})}} : {}),
    };
}

function threadRecord(row) {
    return {id: row.id, title: row.title, createdAt: row.created_at, accessMode: row.locked ? "locked" : row.access_mode};
}

function error(status, code, message) {
    return Response.json({error: {code, message}}, {status});
}

export class LiveThread {
    constructor(state, env) {
        this.state = state;
        this.storage = state.storage;
        this.sql = this.storage.sql;
        this.sequenceLimit = Number(env.THREAD_SEQUENCE_LIMIT || 0);
        this.postsPerMinute = Number(env.POSTS_PER_MINUTE || 0);
        this.push = new ThreadPush(this, env);
        this.storage.transactionSync(() => {
            this.sql.exec(schema);
            this.sql.exec(pushSchema);
            if (!this.sql.exec("SELECT 1 FROM reply_index_ready").toArray().length) {
                // Existing posts form a tree ordered by creation. Build the
                // index once without changing any post, receipt, or sequence.
                this.sql.exec(`WITH RECURSIVE branch(id, root_id, seq) AS (
                    SELECT id, id, created_seq FROM posts WHERE parent_id IS NULL
                    UNION ALL
                    SELECT child.id, branch.root_id, child.created_seq
                    FROM posts AS child JOIN branch ON child.parent_id = branch.id
                ) INSERT OR IGNORE INTO reply_roots SELECT id, root_id, seq FROM branch WHERE id != root_id`);
                this.sql.exec("INSERT INTO reply_totals SELECT root_id, COUNT(*) FROM reply_roots GROUP BY root_id");
                this.sql.exec("INSERT INTO reply_index_ready VALUES (1)");
            }
        });
    }

    threadRow() {
        return this.sql.exec("SELECT thread.*, locked_access.singleton AS locked FROM thread " +
            "LEFT JOIN locked_access ON locked_access.singleton = thread.singleton WHERE thread.singleton = 1").toArray()[0];
    }

    access(thread, actorId) {
        if (!thread.locked) return {state: "open", role: "guest", actorId};
        if (actorId && (thread.creator_id === actorId ||
            this.sql.exec("SELECT 1 FROM creator_browsers WHERE actor_id = ?", actorId).toArray().length)) {
            return {state: "approved", role: "creator", actorId};
        }
        const request = actorId && this.sql.exec("SELECT state FROM join_requests WHERE actor_id = ?", actorId).toArray()[0];
        return {state: request?.state || "unrequested", role: "guest", actorId};
    }

    authorize(actorId, locked) {
        const thread = this.threadRow();
        if (!thread || Boolean(thread.locked) !== locked) {
            return error(404, "thread_unavailable", "This thread is unavailable.");
        }
        const access = this.access(thread, actorId);
        if (!thread.locked || access.state === "approved") return access;
        return error(403, "join_required", "This thread requires approval or its passkey.");
    }

    accessStatus(thread, actorId) {
        const {state, role} = this.access(thread, actorId);
        const passkey = thread.locked && this.sql.exec("SELECT code_verifier FROM locked_access").one().code_verifier;
        return Response.json({state, role, passkey: Boolean(passkey)});
    }

    notifyCreator() {
        for (const socket of this.state.getWebSockets("creator")) {
            try { socket.send('{"type":"access.requests"}'); } catch { /* Pending requests remain in SQLite. */ }
        }
    }

    join(thread, command) {
        let requested = false;
        const result = this.storage.transactionSync(() => {
            const {state} = this.access(thread, command.actorId);
            if (state === "approved" || (state === "pending" && !command.verifier)) {
                return this.accessStatus(thread, command.actorId);
            }
            if (state === "declined") return error(403, "join_declined", "The creator declined this request.");
            if (command.verifier) {
                // Limit distributed guesses as well as requests from one IP.
                const minute = Math.floor(Date.now() / 60_000);
                const attempts = this.sql.exec("SELECT attempts FROM passkey_window WHERE minute = ?", minute).toArray()[0]?.attempts || 0;
                if (attempts >= 20) return Response.json({
                    error: {code: "passkey_rate_limited", message: "Too many passkey attempts. Try again in a minute."},
                }, {status: 429, headers: {"Retry-After": "60"}});
                this.sql.exec("INSERT OR REPLACE INTO passkey_window VALUES (1, ?, ?)", minute, attempts + 1);
                if (!this.sql.exec("SELECT 1 FROM locked_access WHERE code_verifier = ?", command.verifier).toArray().length) {
                    return error(403, "invalid_passkey", "That passkey did not match.");
                }
            }
            if (state === "unrequested") {
                const count = this.sql.exec("SELECT COUNT(*) AS n FROM join_requests WHERE state = 'pending'").one().n;
                if (!command.verifier && count >= 100) return error(409, "join_queue_full", "The join queue is full. Try again later.");
                const total = this.sql.exec("SELECT COUNT(*) AS n FROM join_requests").one().n;
                if (total >= 2000) return error(409, "join_capacity", "This thread has reached its access limit.");
                this.sql.exec("INSERT INTO join_requests VALUES (?, ?, ?, ?, ?)", command.actorId, randomId(16),
                    command.name, command.verifier ? "approved" : "pending", new Date().toISOString());
                requested = !command.verifier;
            } else {
                this.sql.exec("UPDATE join_requests SET state = 'approved' WHERE actor_id = ?", command.actorId);
                requested = true;
            }
            return this.accessStatus(thread, command.actorId);
        });
        if (requested) this.notifyCreator();
        return result;
    }

    creatorAccess(path, thread, command) {
        if (path === "/claim") {
            return this.storage.transactionSync(() => {
                const found = this.sql.exec("SELECT 1 FROM creator_handoff WHERE digest = ? AND expires > ?",
                    command.digest, Date.now()).toArray().length;
                if (!found) return error(403, "handoff_expired", "Creator link expired. Open the thread again from dλsociate.");
                // Tabs in one browser profile share a credential. Keep a
                // waiting guest in that role and let a separate profile
                // redeem the same handoff.
                const pending = this.sql.exec("SELECT 1 FROM join_requests WHERE actor_id = ? AND state = 'pending'",
                    command.actorId).toArray().length;
                if (pending) return error(409, "guest_request_pending",
                    "This browser profile is waiting for approval. Open the original creator link in a different browser profile.");
                this.sql.exec("DELETE FROM creator_handoff");
                // Preserve access across browser restarts for each browser
                // explicitly opened by the original app.
                this.sql.exec("INSERT OR IGNORE INTO creator_browsers VALUES (?)", command.actorId);
                return this.accessStatus(thread, command.actorId);
            });
        }
        if (this.access(thread, command.actorId).role !== "creator") {
            return error(403, "creator_required", "Only the thread creator can manage requests.");
        }
        if (path === "/handoff") {
            // Only the original installation can grant creator access to
            // another browser. A newer handoff supersedes an unused one.
            if (command.actorId !== thread.creator_id) return error(403, "creator_required", "Open the thread from the original app.");
            this.sql.exec("INSERT OR REPLACE INTO creator_handoff VALUES (1, ?, ?)", command.digest, Date.now() + 300_000);
            return Response.json({});
        }
        if (path === "/decision") {
            const changed = this.sql.exec("UPDATE join_requests SET state = ? WHERE id = ? AND state = 'pending' RETURNING id",
                command.decision, command.id).toArray().length;
            const row = this.sql.exec("SELECT state FROM join_requests WHERE id = ?", command.id).toArray()[0];
            if (row?.state !== command.decision) return error(409, "join_decided", "That request is no longer pending.");
            if (changed) this.notifyCreator();
        }
        const requests = this.sql.exec("SELECT id, name, requested_at AS requestedAt FROM join_requests " +
            "WHERE state = 'pending' ORDER BY requested_at, id").toArray();
        return Response.json({requests});
    }

    postRow(id) {
        return this.sql.exec(postsWithMedia + " WHERE posts.id = ?", id).toArray()[0];
    }

    attach(postId, media, bytes) {
        this.sql.exec("INSERT INTO attachments VALUES (?, ?, ?, ?)", postId, media.type, media.size, media.duration ?? null);
        for (let start = 0; start < bytes.byteLength; start += partSize) {
            this.sql.exec("INSERT INTO attachment_parts VALUES (?, ?, ?)", postId, start / partSize,
                bytes.slice(start, start + partSize));
        }
    }

    attachment(postId, range, method) {
        const row = this.sql.exec("SELECT type, size FROM attachments JOIN posts ON posts.id = post_id " +
            "WHERE post_id = ? AND deleted_at IS NULL", postId).toArray()[0];
        if (!row) return error(404, "media_unavailable", "This attachment is unavailable.");
        const headers = {"Content-Type": row.type, "Accept-Ranges": "bytes"};
        let start = 0;
        let end = row.size - 1;
        if (range && method === "GET") {
            const match = /^bytes=(\d*)-(\d*)$/.exec(range);
            if (match?.[1]) {
                start = Number(match[1]);
                if (match[2]) end = Math.min(end, Number(match[2]));
            } else if (match?.[2]) {
                start = Math.max(0, row.size - Number(match[2]));
            } else {
                start = row.size;
            }
            if (!Number.isSafeInteger(start) || start > end || end < 0) {
                return new Response(null, {status: 416, headers: {...headers, "Content-Range": "bytes */" + row.size}});
            }
            headers["Content-Range"] = "bytes " + start + "-" + end + "/" + row.size;
        }
        headers["Content-Length"] = String(end - start + 1);
        if (method === "HEAD") return new Response(null, {headers});
        const bytes = new Uint8Array(end - start + 1);
        let written = 0;
        const parts = this.sql.exec("SELECT part, bytes FROM attachment_parts WHERE post_id = ? " +
            "AND part BETWEEN ? AND ? ORDER BY part", postId, Math.floor(start / partSize), Math.floor(end / partSize));
        for (const part of parts) {
            const offset = part.part * partSize;
            const slice = new Uint8Array(part.bytes).subarray(Math.max(0, start - offset), end - offset + 1);
            bytes.set(slice, written);
            written += slice.byteLength;
        }
        if (written !== bytes.byteLength) return error(503, "media_unavailable", "This attachment is temporarily unavailable.");
        return new Response(bytes, {status: headers["Content-Range"] ? 206 : 200, headers});
    }

    create(command, bytes) {
        return this.storage.transactionSync(() => {
            const current = this.threadRow();
            if (current) {
                const receipt = this.sql.exec(
                    "SELECT request_digest, post_id FROM receipts WHERE actor_id = ? AND operation_id = ?",
                    command.authorId, command.operationId,
                ).toArray()[0];
                if (!receipt || receipt.request_digest !== command.requestDigest) {
                    return error(409, "operation_conflict", "This request ID was used with different content.");
                }
                if (command.agreementVersion) this.acceptAgreement(command.authorId, command.agreementVersion);
                const post = this.postRow(receipt.post_id);
                return Response.json({
                    thread: threadRecord(current), post: postRecord(post),
                    headSeq: current.head_seq, inviteKeyId: current.invite_key_id,
                });
            }

            const time = new Date().toISOString();
            const id = "p_" + randomId(16);
            const {roomId, authorId, operationId, title, openingPost, requestDigest, inviteKeyId} = command;
            this.sql.exec(
                "INSERT INTO thread VALUES (1, ?, ?, ?, ?, 'wild-west', 1, 1, ?)",
                roomId, title, authorId, time, inviteKeyId,
            );
            if (command.locked) this.sql.exec("INSERT INTO locked_access VALUES (1, ?)", command.codeVerifier ?? null);
            this.sql.exec(
                "INSERT INTO posts VALUES (?, NULL, ?, ?, ?, ?, 1, 1, NULL)",
                id, authorId, openingPost.displayName, openingPost.body, time,
            );
            this.sql.exec("INSERT INTO receipts VALUES (?, ?, ?, ?)", authorId, operationId, requestDigest, id);
            if (command.agreementVersion) this.acceptAgreement(authorId, command.agreementVersion);
            if (command.media) this.attach(id, command.media, bytes);
            return Response.json({
                thread: threadRecord(this.threadRow()),
                post: postRecord(this.postRow(id)),
                headSeq: 1, inviteKeyId,
            }, {status: 201});
        });
    }

    hasAgreement(actorId, version) {
        return Boolean(actorId && this.sql.exec("SELECT 1 FROM thread_agreements WHERE actor_id = ? AND version = ?",
            actorId, version).toArray().length);
    }

    acceptAgreement(actorId, version) {
        this.sql.exec("INSERT INTO thread_agreements VALUES (?, ?) ON CONFLICT(actor_id) DO UPDATE SET" +
            " version = excluded.version WHERE thread_agreements.version != excluded.version", actorId, version);
    }

    snapshot(viewerAuthorId, grouped, agreementVersion) {
        // Read the rows and the sequence in one transaction so a later
        // client can subscribe and catch up from exactly this snapshot.
        return this.storage.transactionSync(() => {
            const row = this.threadRow();
            if (!row) return error(404, "thread_unavailable", "This thread is unavailable.");
            const recent = this.sql.exec(postsWithMedia + (grouped ? " WHERE posts.parent_id IS NULL" : "") +
                " ORDER BY posts.created_seq DESC LIMIT 51").toArray();
            const hasOlder = recent.length > 50;
            if (hasOlder) recent.pop();
            return Response.json({
                thread: threadRecord(row),
                posts: recent.reverse().map(post => postRecord(post, grouped)),
                headSeq: row.head_seq,
                olderCursor: hasOlder ? recent[0].created_seq : null,
                viewerAuthorId,
                ...(grouped ? {agreementAccepted: this.hasAgreement(viewerAuthorId, agreementVersion)} : {}),
            });
        });
    }

    history(before, grouped) {
        if (!this.threadRow()) return error(404, "thread_unavailable", "This thread is unavailable.");
        const rows = this.sql.exec(
            postsWithMedia + " WHERE posts.created_seq < ?" + (grouped ? " AND posts.parent_id IS NULL" : "") +
                " ORDER BY posts.created_seq DESC LIMIT 51", before,
        ).toArray();
        const hasOlder = rows.length > 50;
        if (hasOlder) rows.pop();
        rows.reverse();
        return Response.json({posts: rows.map(post => postRecord(post, grouped)), olderCursor: hasOlder ? rows[0].created_seq : null});
    }

    branch(rootId, after) {
        const root = this.postRow(rootId);
        if (!root || root.parent_id) return error(404, "post_unavailable", "This post is unavailable.");
        const replies = this.sql.exec(postsWithMedia + " WHERE reply_roots.root_id = ? AND reply_roots.created_seq > ?" +
            " ORDER BY reply_roots.created_seq LIMIT 51", rootId, after).toArray();
        const more = replies.length > 50;
        if (more) replies.pop();
        return Response.json({root: postRecord(root, true), posts: replies.map(post => postRecord(post, true)),
            nextAfter: more ? replies.at(-1).created_seq : null});
    }

    target(postId) {
        const post = this.postRow(postId);
        if (!post) return error(404, "post_unavailable", "This post is unavailable.");
        const root = post.parent_id ? this.postRow(post.root_id) : post;
        return Response.json({root: postRecord(root, true), post: postRecord(post, true)});
    }

    reactions(postIds, actorId) {
        const slots = postIds.map(() => "?").join(",");
        return this.sql.exec(`SELECT posts.id AS postId, COALESCE(like_totals.count, 0) AS count,
            COALESCE(like_totals.revision, 0) AS revision, COALESCE(likes.liked, 0) AS liked,
            COALESCE(likes.revision, 0) AS actorRevision FROM posts
            LEFT JOIN like_totals ON like_totals.post_id = posts.id
            LEFT JOIN likes ON likes.post_id = posts.id AND likes.actor_id = ?
            WHERE posts.deleted_at IS NULL AND posts.id IN (${slots})`, actorId, ...postIds).toArray()
            .map(row => ({...row, liked: Boolean(row.liked)}));
    }

    setLike({postId, actorId, liked, actorRevision, operationId}) {
        const result = this.storage.transactionSync(() => {
            const post = this.sql.exec("SELECT deleted_at FROM posts WHERE id = ?", postId).toArray()[0];
            if (!post || post.deleted_at) return error(404, "post_unavailable", "This post is unavailable.");
            const current = this.sql.exec("SELECT liked, revision, operation_id FROM likes WHERE post_id = ? AND actor_id = ?",
                postId, actorId).toArray()[0];
            if (current?.operation_id === operationId && Boolean(current.liked) === liked) return {changed: false};
            if ((current?.revision ?? 0) !== actorRevision)
                return error(409, "reaction_changed", "This Like changed in another tab. Try again.");
            if (Boolean(current?.liked) === liked) return {changed: false};
            // Keep a bounded number of actor records, including unlikes. A
            // stale retry must still see an actor revision after an unlike.
            if (!current && this.sql.exec("SELECT COUNT(*) AS n FROM likes WHERE post_id = ?", postId).one().n >= 512)
                return error(409, "reaction_capacity", "This post has reached its Like limit.");
            this.sql.exec(`INSERT INTO likes VALUES (?, ?, ?, ?, ?) ON CONFLICT(post_id, actor_id)
                DO UPDATE SET liked = excluded.liked, revision = excluded.revision, operation_id = excluded.operation_id`,
                postId, actorId, Number(liked), actorRevision + 1, operationId);
            this.sql.exec("INSERT OR IGNORE INTO like_totals VALUES (?, 0, 0)", postId);
            this.sql.exec("UPDATE like_totals SET count = count + ?, revision = revision + 1 WHERE post_id = ?",
                liked ? 1 : -1, postId);
            return {changed: true};
        });
        if (result instanceof Response) return result;
        const [reaction] = this.reactions([postId], actorId);
        if (result.changed) this.broadcast({type: "reaction.changed", postId, revision: reaction.revision}, "groups");
        return Response.json(reaction);
    }

    changes(after, grouped) {
        return this.storage.transactionSync(() => {
            const thread = this.threadRow();
            if (!thread) return error(404, "thread_unavailable", "This thread is unavailable.");
            if (after > thread.head_seq) return error(400, "invalid_cursor", "The cursor is ahead of the thread.");
            const rows = this.sql.exec(
                postsWithMedia + " WHERE posts.updated_seq > ? ORDER BY posts.updated_seq LIMIT 101", after,
            ).toArray();
            const hasMore = rows.length > 100;
            if (hasMore) rows.pop();
            // A post can have several committed changes but only its current
            // state is replayed. The watermark covers superseded sequences.
            const nextAfter = hasMore ? rows.at(-1).updated_seq : thread.head_seq;
            return Response.json({posts: rows.map(post => postRecord(post, grouped)), nextAfter, hasMore});
        });
    }

    publishChange(row) {
        for (const [tag, grouped] of [["groups", true], ["flat", false]]) {
            this.broadcast({type: "post.changed", seq: row.updated_seq, post: postRecord(row, grouped)}, tag);
        }
    }

    broadcast(event, tag) {
        const message = JSON.stringify(event);
        // The storage output gate holds these messages until the transaction
        // is durable. There is no await between mutation and broadcast.
        // Only flat events need to find pre-upgrade sockets with no view tag.
        for (const socket of this.state.getWebSockets(tag === "groups" ? tag : undefined)) {
            if (tag === "flat" && this.state.getTags(socket).includes("groups")) continue;
            try { socket.send(message); } catch { /* A disconnected client catches up over HTTP. */ }
        }
    }

    checkPostingBudget(thread) {
        if (this.sequenceLimit && thread.head_seq >= this.sequenceLimit) {
            return error(409, "thread_capacity", "This thread has reached its posting limit. The existing history is still available.");
        }
        if (!this.postsPerMinute) return null;
        const minute = Math.floor(Date.now() / 60_000);
        const accepted = this.sql.exec(
            "SELECT accepted FROM posting_window WHERE singleton = 1 AND minute = ?", minute,
        ).toArray()[0]?.accepted || 0;
        if (accepted >= this.postsPerMinute) {
            return Response.json({error: {code: "thread_rate_limited", message: "This thread is receiving too many posts. Wait a minute and try again."}},
                {status: 429, headers: {"Retry-After": "60"}});
        }
        this.sql.exec("INSERT OR REPLACE INTO posting_window VALUES (1, ?, ?)", minute, accepted + 1);
        return null;
    }

    async addPost(command, bytes) {
        const result = this.storage.transactionSync(() => {
            const thread = this.threadRow();
            if (!thread) return error(404, "thread_unavailable", "This thread is unavailable.");
            const receipt = this.sql.exec(
                "SELECT request_digest, post_id FROM receipts WHERE actor_id = ? AND operation_id = ?",
                command.authorId, command.operationId,
            ).toArray()[0];
            if (receipt) {
                if (receipt.request_digest !== command.requestDigest) {
                    return error(409, "operation_conflict", "This request ID was used with different content.");
                }
                return {row: this.postRow(receipt.post_id), status: 200};
            }
            if (command.parentId && !this.sql.exec("SELECT 1 FROM posts WHERE id = ?", command.parentId).toArray().length) {
                return error(404, "post_unavailable", "The post you are replying to is unavailable.");
            }
            if (command.media && this.sql.exec("SELECT COALESCE(SUM(size), 0) AS total FROM attachments").one().total +
                command.media.size > mediaQuota) {
                return error(409, "media_capacity", "This thread has reached its attachment limit.");
            }
            // Count committed new posts only. The transaction rolls back the
            // window increment if the post or its receipt fails to commit.
            const limit = this.checkPostingBudget(thread);
            if (limit) return limit;
            const id = "p_" + randomId(16);
            const seq = thread.head_seq + 1;
            this.sql.exec(
                "INSERT INTO posts VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL)",
                id, command.parentId, command.authorId, command.displayName, command.body, new Date().toISOString(), seq, seq,
            );
            this.sql.exec("UPDATE thread SET head_seq = ? WHERE singleton = 1", seq);
            this.sql.exec("INSERT INTO receipts VALUES (?, ?, ?, ?)", command.authorId, command.operationId, command.requestDigest, id);
            if (command.media) this.attach(id, command.media, bytes);
            const queued = this.push.enqueue(id, command.authorId, command.parentId);
            return {row: this.postRow(id), status: 201, queued};
        });
        if (result instanceof Response) return result;
        if (result.status === 201) this.publishChange(result.row);
        // The outbox commits with the post. A retry can also repair an alarm
        // that failed to schedule. Push provider I/O runs only in alarm().
        if (result.queued || result.status === 200) await this.push.schedule().catch(() => {});
        return Response.json({post: postRecord(result.row, command.grouped)}, {status: result.status});
    }

    deletePost(command) {
        const result = this.storage.transactionSync(() => {
            const thread = this.threadRow();
            if (!thread) return error(404, "thread_unavailable", "This thread is unavailable.");
            const row = this.sql.exec("SELECT * FROM posts WHERE id = ?", command.postId).toArray()[0];
            if (!row) return error(404, "post_unavailable", "This post is unavailable.");
            if (row.author_id !== command.authorId) return error(403, "not_author", "Only the author can delete this post.");
            if (row.deleted_at) return {row: this.postRow(command.postId), changed: false};
            const seq = thread.head_seq + 1;
            this.sql.exec(
                "UPDATE posts SET body = NULL, deleted_at = ?, updated_seq = ? WHERE id = ?",
                new Date().toISOString(), seq, command.postId,
            );
            this.sql.exec("UPDATE thread SET head_seq = ? WHERE singleton = 1", seq);
            this.sql.exec("DELETE FROM attachment_parts WHERE post_id = ?", command.postId);
            this.sql.exec("DELETE FROM attachments WHERE post_id = ?", command.postId);
            this.sql.exec("DELETE FROM likes WHERE post_id = ?", command.postId);
            this.sql.exec("DELETE FROM like_totals WHERE post_id = ?", command.postId);
            return {row: this.postRow(command.postId), changed: true};
        });
        if (result instanceof Response) return result;
        if (result.changed) this.publishChange(result.row);
        return Response.json({post: postRecord(result.row, command.grouped)});
    }

    connect(role, grouped) {
        const thread = this.threadRow();
        if (!thread) return error(404, "thread_unavailable", "This thread is unavailable.");
        const [client, server] = Object.values(new WebSocketPair());
        this.state.acceptWebSocket(server, [...(role === "creator" ? ["creator"] : []), grouped ? "groups" : "flat"]);
        server.send(JSON.stringify({type: "ready", headSeq: thread.head_seq}));
        return new Response(null, {status: 101, webSocket: client});
    }

    webSocketMessage(socket) {
        socket.close(1008, "Use HTTPS to post.");
    }

    alarm() { return this.push.alarm(); }

    async fetch(request) {
        const path = new URL(request.url).pathname;
        if (path === "/live" || path.startsWith("/media/")) {
            const access = this.authorize(request.headers.get("X-Actor"), request.headers.get("X-Locked") === "true");
            if (access instanceof Response) return access;
            return path === "/live" ? this.connect(access.role, request.headers.get("X-Grouped") === "true") :
                this.attachment(path.slice(7), request.headers.get("Range"), request.method);
        }
        let command, bytes;
        if (request.headers.get("Content-Type") === "application/octet-stream") {
            // The edge Worker sent one JSON line followed by the verified bytes.
            const payload = new Uint8Array(await request.arrayBuffer());
            const boundary = payload.indexOf(10);
            command = JSON.parse(new TextDecoder().decode(payload.subarray(0, boundary)));
            bytes = payload.buffer.slice(boundary + 1);
        } else {
            command = await request.json();
        }
        if (path === "/create") return this.create(command, bytes);
        // A device can stop its own alerts even after losing thread admission.
        if (path === "/follow" && command.mode === "remove") return this.push.follow(command);
        if (["/access", "/join", "/requests", "/decision", "/handoff", "/claim"].includes(path)) {
            const thread = this.threadRow();
            if (!thread?.locked || !command.locked) return error(404, "thread_unavailable", "This thread is unavailable.");
            if (path === "/access") return this.accessStatus(thread, command.actorId);
            if (path === "/join") return this.join(thread, command);
            return this.creatorAccess(path, thread, command);
        }
        const access = this.authorize(command.actorId, command.locked);
        if (access instanceof Response) return access;
        if (path === "/follow") return this.push.follow(command);
        if (path === "/snapshot") return this.snapshot(access.actorId, command.grouped, command.agreementVersion);
        if (path === "/history") return this.history(command.before, command.grouped);
        if (path === "/branch") return this.branch(command.postId, command.after);
        if (path === "/target") return this.target(command.postId);
        if (path === "/reactions") return Response.json({reactions: this.reactions(command.postIds, access.actorId)});
        if (path === "/like") return this.setLike(command);
        if (path === "/agreement") {
            this.acceptAgreement(access.actorId, command.agreementVersion);
            return Response.json({accepted: true});
        }
        if (path === "/changes") return this.changes(command.after, command.grouped);
        if (path === "/post") {
            if (command.agreementVersion && !this.hasAgreement(access.actorId, command.agreementVersion))
                return error(403, "agreements_required", "Agree to the License Agreement and Karmic Law to post.");
            return this.addPost({...command, authorId: access.actorId}, bytes);
        }
        if (path === "/delete") return this.deletePost({...command, authorId: access.actorId});
        return error(404, "not_found", "This operation is unavailable.");
    }
}
