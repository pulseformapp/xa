/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

const encoder = new TextEncoder();
const invitePattern = /^(l-)?([a-z0-9]{1,12})\.([A-Za-z0-9_-]{22})\.([A-Za-z0-9_-]{43})$/;
export const sessionCookie = "__Host-dysociate-live";
const loopbackCookie = "dysociate-live-loopback";

export function browserCookieName(request, env) {
    // Old Android WebView rejects a Secure __Host- cookie over HTTP even on
    // loopback. Only the explicit local Worker can issue the test cookie.
    return env.ALLOW_LOOPBACK_COOKIE === "true" && new URL(request.url).origin === "http://127.0.0.1:8795"
        ? loopbackCookie : sessionCookie;
}

function encode(bytes) {
    return btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
}

function decode(value, size) {
    if (typeof value !== "string" || !/^[A-Za-z0-9_-]+$/.test(value) || value.length !== Math.ceil(size * 8 / 6)) return null;
    const binary = atob(value.replaceAll("-", "+").replaceAll("_", "/"));
    const bytes = Uint8Array.from(binary, character => character.charCodeAt(0));
    return bytes.length === size && encode(bytes) === value ? bytes : null;
}

export function randomId(size) {
    return encode(crypto.getRandomValues(new Uint8Array(size)));
}

async function hmacKey(bytes, usages) {
    return crypto.subtle.importKey("raw", bytes, {name: "HMAC", hash: "SHA-256"}, false, usages);
}

async function derive(bytes, message) {
    const key = await hmacKey(bytes, ["sign"]);
    return new Uint8Array(await crypto.subtle.sign("HMAC", key, encoder.encode(message)));
}

export async function digest(value) {
    return encodeDigest(encoder.encode(value));
}

export async function encodeDigest(bytes) {
    return encode(new Uint8Array(await crypto.subtle.digest("SHA-256", bytes)));
}

export function browserCredential(request, name = sessionCookie) {
    const cookie = (request.headers.get("Cookie") || "").split(";")
        .find(part => part.trim().startsWith(name + "="));
    const token = cookie?.trim().slice(name.length + 1);
    return decode(token, 32) ? token : null;
}

export function requestCredential(request, name = sessionCookie) {
    const header = request.headers.get("Authorization");
    if (header !== null) {
        const token = header.startsWith("Bearer ") ? header.slice(7) : "";
        return decode(token, 32) ? {token, client: "native"} : null;
    }
    const token = browserCredential(request, name);
    return token ? {token, client: "browser"} : null;
}

export async function roomForCreation(token, operationId) {
    // Retrying from the same app installation selects the same room even
    // when the service has rotated its separate invitation signing key.
    return encode((await derive(decode(token, 32), "room/v1/" + operationId)).slice(0, 16));
}

export async function authorForRoom(token, roomId) {
    const value = await derive(decode(token, 32), "author/v1/" + roomId);
    return "a_" + encode(value.slice(0, 16));
}

function inviteKey(env, id) {
    if (!/^[a-z0-9]{1,12}$/.test(id || "")) return null;
    const keys = JSON.parse(env.INVITE_KEYS || "{}");
    return keys && Object.hasOwn(keys, id) ? decode(keys[id], 32) : null;
}

export async function issueInvite(env, keyId, roomId, locked = false) {
    const bytes = inviteKey(env, keyId);
    if (!bytes) throw Error("Invitation signing key is unavailable.");
    // Older Workers reject the l- prefix. They cannot serve a locked room
    // after rollback, even though both releases understand its post schema.
    const label = locked ? "l-" + keyId : keyId;
    const value = await derive(bytes, "invite/v1/" + label + "/" + roomId);
    return label + "." + roomId + "." + encode(value);
}

export async function verifyInvite(env, invite) {
    const match = invitePattern.exec(invite);
    if (!match) return null;
    const [, locked, keyId, roomId, signature] = match;
    const bytes = inviteKey(env, keyId);
    const tag = decode(signature, 32);
    if (!bytes || !tag || !decode(roomId, 16)) return null;
    const key = await hmacKey(bytes, ["verify"]);
    const valid = await crypto.subtle.verify("HMAC", key, tag, encoder.encode("invite/v1/" + (locked || "") + keyId + "/" + roomId));
    return valid ? {roomId, keyId, locked: Boolean(locked)} : null;
}

export async function codeVerifier(env, keyId, roomId, code) {
    const bytes = inviteKey(env, keyId);
    if (!bytes) throw Error("Invitation signing key is unavailable.");
    return encode(await derive(bytes, "join-code/v1/" + roomId + "/" + code));
}

export async function lockedCreationDigest(token, data) {
    return encode(await derive(decode(token, 32), "locked-create/v1/" + JSON.stringify(data)));
}

export async function creationConsent(env, token, version, cookie) {
    const id = cookie?.split(".")[0] || env.ACTIVE_INVITE_KEY_ID;
    const bytes = inviteKey(env, id);
    if (!bytes) return null;
    const message = "web-create-agreements/v1/" + version + "/" + token;
    if (cookie === undefined) return id + "." + encode(await derive(bytes, message));
    const signature = decode(cookie.slice(id.length + 1), 32);
    if (!signature) return false;
    const key = await hmacKey(bytes, ["verify"]);
    return crypto.subtle.verify("HMAC", key, signature, encoder.encode(message));
}
