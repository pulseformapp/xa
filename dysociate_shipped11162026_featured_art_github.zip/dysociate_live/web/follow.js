/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import {browserSession, request} from "./thread-client.js";

const invitePath = /^\/t\/(?:l-)?[a-z0-9]{1,12}\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}$/;
const storeKey = "dysociate-following-v1";
export const modeLabels = {replies: "Replies to me", all: "All activity", muted: "Muted"};

export function inviteFrom(value) {
    try {
        const url = new URL(value, location.origin);
        return url.origin === location.origin && invitePath.test(url.pathname) ? url.pathname : null;
    } catch { return null; }
}

export function savedThreads() {
    try {
        const items = JSON.parse(localStorage.getItem(storeKey) || "[]");
        return items.filter(item => invitePath.test(item.path) && /^[A-Za-z0-9_-]{43}$/.test(item.id) &&
            typeof item.title === "string" && Object.hasOwn(modeLabels, item.mode));
    } catch { return []; }
}

function store(item, remove = false) {
    const items = savedThreads().filter(entry => entry.path !== item.path);
    if (!remove) items.unshift(item);
    localStorage.setItem(storeKey, JSON.stringify(items));
}

const b64 = bytes => btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
const keyBytes = key => Uint8Array.from(atob(key.replaceAll("-", "+").replaceAll("_", "/")), char => char.charCodeAt(0));
const endpoint = item => "/api/v1/threads/" + item.path.slice(3) + "/follow/" + item.id;

export async function removeFollow(item) {
    await browserSession();
    try { await request(endpoint(item), "DELETE"); }
    catch (error) { if (error.code !== "follow_session_changed") throw error; }
    store(item, true);
    // Releasing the last device subscription also stops a stale server
    // enrollment if the browser session was lost or reset.
    if (!savedThreads().some(entry => entry.mode !== "muted") && "serviceWorker" in navigator) {
        try {
            const worker = await navigator.serviceWorker.getRegistration("/t/");
            const active = await worker?.pushManager?.getSubscription();
            await active?.unsubscribe();
        } catch { /* The acknowledged server removal already stops delivery. */ }
    }
}

function isAppleMobile() {
    return /iPhone|iPad|iPod/.test(navigator.userAgent) ||
        (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
}

export function installHint() {
    return isAppleMobile() && !navigator.standalone && !matchMedia("(display-mode: standalone)").matches
        ? "In Safari, tap Share → Add to Home Screen. Open dλsociate from its icon, then paste this thread link if needed." : "";
}

export function bindFollow(client) {
    const panel = document.getElementById("follow-panel");
    const toggle = document.getElementById("follow-thread");
    const mode = document.getElementById("follow-mode");
    const save = document.getElementById("save-follow");
    const remove = document.getElementById("remove-follow");
    const status = document.getElementById("follow-status");
    const copy = document.getElementById("follow-copy");
    const path = location.pathname;
    let item = savedThreads().find(entry => entry.path === path);
    let registration, subscription, preparing = false, saving = false;

    const hint = installHint();
    const supported = "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;

    function alertProblem() {
        if (hint) return hint;
        if (!supported) return "Open this link in a browser that supports phone alerts. You can save the thread here with alerts muted.";
        if (!client.pushKey) return "Phone alerts are paused for this site. You can still save the thread to Following.";
        if (Notification.permission === "denied") return "Notifications are blocked. Allow them in your browser or device settings, then reopen this panel.";
        return "";
    }

    function showState() {
        toggle.textContent = item ? "Following ✓" : "Follow thread";
        remove.hidden = !item;
        const problem = alertProblem();
        for (const option of mode.options) option.disabled = Boolean(problem && option.value !== "muted");
        mode.value = item?.mode || (problem ? "muted" : "replies");
    }

    async function prepare() {
        const problem = alertProblem();
        copy.hidden = !hint;
        status.textContent = problem;
        if (problem || preparing) return;

        preparing = true;
        save.disabled = true;
        try {
            registration = await navigator.serviceWorker.register("/t/push-sw.js", {scope: "/t/"});
            registration = await navigator.serviceWorker.ready;
            subscription = await registration.pushManager.getSubscription();
        } catch {
            registration = null;
            status.textContent = "Couldn't prepare phone alerts. Reopen this panel to try again, or choose Muted to save the thread.";
        } finally {
            preparing = false;
            save.disabled = saving;
        }
        if (registration && item && item.mode !== "muted") {
            const saved = item;
            try {
                const state = subscription && await request(endpoint(saved));
                if (saving || item !== saved) return;
                if (!state?.mode) status.textContent = "Alerts are disconnected. Save again to reconnect this device.";
                else if (state.mode !== saved.mode) status.textContent = "Save again to update the alert mode.";
            } catch { /* Saving again can renew the enrollment. */ }
        }
    }

    toggle.hidden = false;
    showState();
    toggle.addEventListener("click", () => {
        panel.hidden = !panel.hidden;
        toggle.setAttribute("aria-expanded", String(!panel.hidden));
        if (panel.hidden) return;
        const share = document.getElementById("share");
        if (share.getAttribute("aria-expanded") === "true") share.click();
        showState();
        void prepare();
        mode.focus();
    });
    window.addEventListener("storage", () => {
        if (saving || preparing) return;
        item = savedThreads().find(entry => entry.path === path);
        showState();
    });
    copy.addEventListener("click", async () => {
        try {
            await navigator.clipboard.writeText(location.origin + path);
            status.textContent = "Link copied. Open dλsociate from the Home Screen and paste it under Following.";
        } catch { status.textContent = "Use Share link to copy the thread link, then paste it in the Home Screen app."; }
    });

    save.addEventListener("click", async () => {
        if (saving) return;
        saving = save.disabled = remove.disabled = true;
        const selection = mode.value;
        const entry = item ? {...item, mode: selection} : {
            path, id: b64(crypto.getRandomValues(new Uint8Array(32))), title: client.thread.title, mode: selection,
        };
        try {
            if (selection !== "muted") {
                const problem = alertProblem();
                if (problem) throw Error(problem);
                if (!registration) throw Error("Couldn't prepare phone alerts. Reopen this panel and try again.");
                // Call subscribe inside the click. iOS checks transient user
                // activation before asking the operating system for permission.
                if (!subscription) subscription = await registration.pushManager.subscribe({
                    userVisibleOnly: true, applicationServerKey: keyBytes(client.pushKey),
                });
            }
            // Save the capability locally before enabling delivery. If the
            // server fails, the local copy stays muted and can be retried.
            const previous = item;
            if (!previous) store({...entry, mode: "muted"});
            item ||= {...entry, mode: "muted"};
            if (selection !== "muted" || previous) {
                await request(endpoint(entry), "PUT", {mode: selection,
                    ...(selection !== "muted" ? {subscription: subscription.toJSON()} : {})});
            }
            item = entry;
            store(entry);
            status.textContent = selection === "muted" ? "Saved to Following. Alerts are muted." : "Saved. " + modeLabels[selection] + " alerts are on.";
        } catch (error) { status.textContent = alertProblem() || error.message || "Could not save this follow."; }
        finally {
            saving = remove.disabled = false;
            save.disabled = preparing;
            showState();
            // Keep the requested mode visible after a failed enrollment.
            if (!alertProblem()) mode.value = selection;
        }
    });

    remove.addEventListener("click", async () => {
        if (!item || saving) return;
        saving = save.disabled = remove.disabled = true;
        try {
            await removeFollow(item);
            item = null;
            status.textContent = "Removed from Following.";
        } catch (error) { status.textContent = error.message; }
        finally { saving = save.disabled = remove.disabled = false; showState(); }
    });
}
