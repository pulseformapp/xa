/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

// This module is also bundled in the offline editor used by Windows and
// Android. Each host decides whether it has a capture permission to grant.

// Some Windows camera sources keep delivering a live track of placeholder
// frames after the physical camera stops. Match the observed camera-off
// graphic by both its flat blue-black background and its crossed-camera shape.
// A dark room, a covered lens, or a still scene alone must never match.
function cameraOffScreen(context, video) {
    context.drawImage(video, 0, 0, 160, 120);
    const pixels = context.getImageData(0, 0, 160, 120).data;
    let background = 0;
    for (let i = 0; i < pixels.length; i += 16) {
        const red = pixels[i], green = pixels[i + 1], blue = pixels[i + 2];
        if (red <= 22 && green - red >= 4 && green - red <= 17 && blue - green >= 3 && blue - green <= 20) background++;
    }
    if (background < 4650) return false;
    const shape = [
        ".............#.....",
        "##########..##.....",
        "##.........##......",
        "##.......###...###.",
        "##......###.######.",
        "##.....###..###.##.",
        "##....###...##..##.",
        "##...##.....##..##.",
        "##..##......######.",
        "#..##.......######.",
        "..##........##..##.",
        ".##..#########.....",
        "##..##########.....",
    ];
    const bright = (x, y) => {
        const offset = (y * 160 + x) * 4;
        return pixels[offset] >= 75 && pixels[offset + 1] >= 75 && pixels[offset + 2] >= 75;
    };
    // Resize the template slightly for different capture modes, and allow
    // small offsets for the center pixel when a frame is downsampled.
    for (const scale of [1, 0.85, 1.15, 1.3]) {
        for (const dy of [-2, 0, 2]) {
            for (const dx of [-2, 0, 2]) {
                let matched = 0;
                let lit = 0;
                let expected = 0;
                for (let y = 0; y < shape.length; y++) {
                    for (let x = 0; x < shape[y].length; x++) {
                        const on = bright(Math.round(79 + (x - 10) * scale + dx), Math.round(59 + (y - 7) * scale + dy));
                        const stroke = shape[y][x] === "#";
                        lit += Number(on);
                        expected += Number(stroke);
                        matched += Number(on && stroke);
                    }
                }
                if (matched / expected >= 0.69 && matched / lit >= 0.52) return true;
            }
        }
    }
    return false;
}

export function bindReelRecorder(dialog, useClip) {
    const control = name => dialog.querySelector("[data-reel-" + name + "]");
    const video = control("video");
    const status = control("status");
    const record = control("record");
    const stop = control("stop");
    const retake = control("retake");
    const use = control("use");
    const picker = control("camera-picker");
    const cameras = control("camera");
    const maxBytes = 4 * 1024 * 1024;
    const frameTimeout = 5000;
    const sampleCanvas = document.createElement("canvas");
    sampleCanvas.width = 160;
    sampleCanvas.height = 120;
    const sampleContext = sampleCanvas.getContext("2d", {willReadFrequently: true});
    let cameraId = "";
    let cameraTrack, frameId, frameDeadline;
    let stream, recorder, preview, clip, timer, expires, generation = 0;

    function cleanup() {
        generation++;
        clearInterval(timer);
        clearTimeout(frameDeadline);
        if (frameId !== undefined) video.cancelVideoFrameCallback?.(frameId);
        frameId = cameraTrack = undefined;
        video.onloadedmetadata = video.onerror = null;
        if (recorder?.state === "recording") recorder.stop();
        stream?.getTracks().forEach(track => track.stop());
        stream = null;
        recorder = null;
        video.pause();
        video.srcObject = null;
        video.removeAttribute("src");
        video.controls = false;
        if (preview) URL.revokeObjectURL(preview);
        preview = clip = null;
    }

    function stage(message, {ready = false, recording = false, review = false, retry = false} = {}) {
        status.textContent = message;
        record.hidden = !ready;
        stop.hidden = !recording;
        retake.textContent = review ? "Retake" : ready ? "Restart camera" : "Try camera again";
        retake.hidden = !review && !retry && !ready;
        use.hidden = !review;
        cameras.disabled = recording;
    }

    function loseCamera(message, nextStep = "Check the camera privacy switch, choose another camera, or try again.") {
        cleanup();
        stage(message + " " + nextStep, {retry: true});
    }

    function cameraLive() {
        return cameraTrack?.readyState === "live" && !cameraTrack.muted && cameraTrack.enabled;
    }

    function cameraShowsPlaceholder() {
        return sampleContext && video.readyState >= 2 && cameraOffScreen(sampleContext, video);
    }

    function rejectPlaceholder() {
        loseCamera("Windows is sending a camera-off image.", "Close this recorder and check the preview in the Windows Camera app.");
    }

    async function listCameras(attempt, activeId) {
        try {
            const devices = (await navigator.mediaDevices.enumerateDevices())
                .filter(device => device.kind === "videoinput" && device.deviceId);
            if (attempt !== generation || !dialog.open) return;
            cameras.replaceChildren(...devices.map((device, index) =>
                new Option(device.label || "Camera " + (index + 1), device.deviceId)));
            cameras.value = activeId || cameraId;
            picker.hidden = devices.length < 2;
        } catch { /* Recording can continue with the browser's selected camera. */ }
    }

    function watchFrames(attempt) {
        if (!video.requestVideoFrameCallback) return;
        // Track events can miss a stalled preview. Watch displayed frames,
        // but stop observing when normal recording shutdown begins.
        let nextSample = 0;
        let offFrames = 0;
        function frame(now) {
            if (attempt !== generation) return;
            if (now >= nextSample) {
                nextSample = now + 200;
                offFrames = cameraShowsPlaceholder() ? offFrames + 1 : 0;
                if (offFrames >= 2) {
                    rejectPlaceholder();
                    return;
                }
            }
            clearTimeout(frameDeadline);
            frameDeadline = setTimeout(() => {
                if (!document.hidden && attempt === generation) loseCamera("The camera stopped sending video.");
            }, frameTimeout);
            frameId = video.requestVideoFrameCallback(frame);
        }
        frame(performance.now());
    }

    async function prepare() {
        cleanup();
        const attempt = generation;
        video.muted = true;
        stage("Waiting for camera and microphone…");
        const preferredCamera = cameraId ? {deviceId: {exact: cameraId}} : {facingMode: {ideal: "user"}};
        try {
            const capture = await navigator.mediaDevices.getUserMedia({
                audio: true,
                video: {...preferredCamera, width: {ideal: 480}, height: {ideal: 360}, frameRate: {ideal: 20, max: 24}},
            });
            if (attempt !== generation || !dialog.open) {
                capture.getTracks().forEach(track => track.stop());
                return;
            }
            stream = capture;
            cameraTrack = capture.getVideoTracks()[0];
            if (!cameraLive()) { loseCamera("No live camera video."); return; }
            void listCameras(attempt, cameraTrack.getSettings().deviceId);
            for (const event of ["mute", "ended"]) {
                cameraTrack.addEventListener(event, () => {
                    if (attempt === generation) loseCamera("Camera video was interrupted.");
                });
            }
            video.srcObject = stream;
            // A fulfilled play() can precede the first decoded video frame.
            // Starting at that point can produce an audio-only MP4 on Windows.
            const firstFrame = new Promise((resolve, reject) => {
                const deadline = setTimeout(() => reject(Error("No camera frames.")), frameTimeout);
                const ready = () => {
                    clearTimeout(deadline);
                    resolve();
                };
                video.play().then(() => {
                    if (attempt !== generation || !video.requestVideoFrameCallback) ready();
                    else video.requestVideoFrameCallback(ready);
                }, error => {
                    clearTimeout(deadline);
                    reject(error);
                });
            });
            await firstFrame;
            if (attempt !== generation || !dialog.open) return;
            if (!cameraLive()) { loseCamera("No live camera video."); return; }
            if (cameraShowsPlaceholder()) { rejectPlaceholder(); return; }
            stage("Record when you see a live picture. Up to 30 seconds.", {ready: true});
            watchFrames(attempt);
        } catch (error) {
            if (attempt !== generation) return;
            if (error.name === "OverconstrainedError" || error.name === "NotFoundError") cameraId = "";
            cleanup();
            stage("Camera or microphone unavailable. Check browser permissions and the camera privacy switch.", {retry: true});
        }
    }

    const preferredTypes = ["video/mp4;codecs=avc1.42001E,mp4a.40.2", "video/mp4"];
    const type = typeof MediaRecorder !== "undefined" && preferredTypes.find(value => MediaRecorder.isTypeSupported(value));
    const supported = Boolean(type && navigator.mediaDevices?.getUserMedia);

    function stopRecording() {
        if (cameraShowsPlaceholder()) { rejectPlaceholder(); return; }
        clearInterval(timer);
        clearTimeout(frameDeadline);
        if (frameId !== undefined) video.cancelVideoFrameCallback?.(frameId);
        frameId = undefined;
        if (recorder?.state === "recording") recorder.stop();
        stage("Preparing preview…");
        cameras.disabled = true;
    }

    record.addEventListener("click", () => {
        if (!stream || recorder?.state === "recording") return;
        if (!cameraLive()) { loseCamera("No live camera video."); return; }
        if (cameraShowsPlaceholder()) { rejectPlaceholder(); return; }
        const attempt = generation;
        const chunks = [];
        let size = 0;
        let tooLarge = false;
        try {
            recorder = new MediaRecorder(stream, {mimeType: type, videoBitsPerSecond: 760_000, audioBitsPerSecond: 64_000});
            recorder.ondataavailable = event => {
                if (attempt !== generation) return;
                size += event.data.size;
                tooLarge = size > maxBytes;
                if (!tooLarge && event.data.size) chunks.push(event.data);
                if (tooLarge && recorder.state === "recording") stopRecording();
            };
            recorder.onerror = () => {
                if (attempt !== generation) return;
                cleanup();
                stage("Recording stopped unexpectedly.", {retry: true});
            };
            recorder.onstop = () => {
                if (attempt !== generation) return;
                cleanup();
                if (!size || tooLarge) {
                    stage("The recording could not be used.", {retry: true});
                    return;
                }
                clip = new File(chunks, "reel.mp4", {type: "video/mp4"});
                preview = URL.createObjectURL(clip);
                video.muted = false;
                video.controls = true;
                const review = generation;
                stage("Preparing preview…");
                video.onloadedmetadata = () => {
                    if (generation !== review) return;
                    if (video.videoWidth) stage("Play the preview before using the clip.", {review: true});
                    else stage("No video was captured.", {retry: true});
                };
                video.onerror = () => {
                    if (generation !== review) return;
                    stage("Could not preview the video.", {retry: true});
                };
                video.src = preview;
            };
            recorder.start(250);
            // Leave room for the final audio/video packet within the
            // server's exact 30-second limit.
            expires = performance.now() + 29_600;
            stage("Recording · 30 seconds left", {recording: true});
            timer = setInterval(() => {
                const remaining = expires - performance.now();
                if (remaining <= 0) stopRecording();
                else status.textContent = "Recording · " + Math.ceil(remaining / 1000) + " seconds left";
            }, 100);
        } catch {
            cleanup();
            stage("This device could not start the recorder.", {retry: true});
        }
    });

    stop.addEventListener("click", () => {
        if (cameraLive()) stopRecording();
        else loseCamera("Camera video was interrupted.");
    });
    retake.addEventListener("click", prepare);
    cameras.addEventListener("change", () => {
        cameraId = cameras.value;
        void prepare();
    });
    use.addEventListener("click", () => {
        const selected = clip;
        if (!selected || use.hidden) return;
        dialog.close();
        cleanup();
        useClip(selected);
    });
    control("cancel").addEventListener("click", () => dialog.close());
    dialog.addEventListener("close", () => { if (!dialog.open) cleanup(); });
    addEventListener("pagehide", cleanup);
    document.addEventListener("visibilitychange", () => {
        if (document.hidden && recorder?.state === "recording") stopRecording();
        if (!document.hidden && cameraLive() && frameId !== undefined) {
            video.cancelVideoFrameCallback?.(frameId);
            watchFrames(generation);
        }
    });
    return {supported, open() {
        if (!supported || dialog.open) return;
        dialog.showModal();
        void prepare();
    }};
}
