/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import {ThreadClient} from "./thread-client.js";
import {bindReelRecorder} from "./reel-recorder.js";
import {reviewAgreements} from "./agreements.js";
import {bindFollow} from "./follow.js";

const byId = id => document.getElementById(id);
const timeline = byId("timeline");
const posts = byId("posts");
const composer = byId("composer");
const body = byId("body");
const displayName = byId("display-name");
const submit = byId("submit-post");
const feedback = byId("feedback");
const activity = byId("new-activity");
const client = new ThreadClient(location.pathname.slice(3), location.origin, render);
const creatorFragment = /^#creator=([A-Za-z0-9_-]{43})$/;
const creatorToken = creatorFragment.exec(location.hash)?.[1];
if (creatorToken) history.replaceState(null, "", location.pathname + location.search);
window.addEventListener("hashchange", () => {
    if (creatorFragment.test(location.hash)) location.reload();
    else if (initialized) openPostFragment();
});
const rows = new Map();
const branches = new Map();
const reactionRequests = new Set();
const likesInFlight = new Set();
let reactionTimer;
let initialized = false;
let parentId = null;
let pending = null;
let latestCreation = 0;
let unseenPostId = null;
let busy = false;
let olderBusy = false;
let attachment = null;
let photoPreview = null;
let attachmentHash = null;
let photoSelection = 0;
const mediaStatus = byId("media-status");
const photoInput = byId("post-photo");

function useAttachment(file) {
    photoSelection++;
    if (photoPreview) URL.revokeObjectURL(photoPreview);
    attachment = file;
    attachmentHash = null;
    photoPreview = file?.type.startsWith("image/") ? URL.createObjectURL(file) : null;
    const image = byId("photo-preview");
    image.hidden = !photoPreview;
    if (photoPreview) image.src = photoPreview;
    else image.removeAttribute("src");
    byId("remove-media").hidden = !file;
    body.required = !file;
    mediaStatus.textContent = file ? (photoPreview ? file.name : "Reel attached. Ready to post.") : "";
    updatePostLabel();
}

const reel = bindReelRecorder(byId("reel-recorder"), clip => {
    useAttachment(clip);
    submit.focus();
});
byId("choose-photo").addEventListener("click", () => photoInput.click());
byId("record-reel").addEventListener("click", () => reel.open());
byId("remove-media").addEventListener("click", () => useAttachment(null));
photoInput.addEventListener("change", async () => {
    const file = photoInput.files[0];
    photoInput.value = "";
    if (!file) return;
    const selection = ++photoSelection;
    if (!["image/jpeg", "image/png"].includes(file.type)) {
        mediaStatus.textContent = "Choose a JPEG or PNG photo.";
        return;
    }
    mediaStatus.textContent = "Preparing photo…";
    try {
        const image = new Image();
        const source = URL.createObjectURL(file);
        try {
            image.src = source;
            await image.decode();
            const width = image.naturalWidth;
            const height = image.naturalHeight;
            if (selection !== photoSelection || busy) return;
            if (file.size <= 1024 * 1024 && width <= 4096 && height <= 4096 && width * height <= 12_000_000) {
                useAttachment(file);
                return;
            }
            // A camera photo often exceeds the upload limit. Resize locally
            // before previewing it so the user can see the version they'll post.
            const canvas = document.createElement("canvas");
            const scale = Math.min(1, 1200 / Math.max(width, height));
            canvas.width = Math.max(1, Math.round(width * scale));
            canvas.height = Math.max(1, Math.round(height * scale));
            const context = canvas.getContext("2d", {alpha: false});
            context.drawImage(image, 0, 0, canvas.width, canvas.height);
            const photo = await new Promise(resolve => canvas.toBlob(resolve, "image/jpeg", 0.8));
            if (selection !== photoSelection || busy) return;
            if (!photo || photo.size > 1024 * 1024) throw Error();
            useAttachment(new File([photo], file.name.replace(/\.[^.]+$/, "") + ".jpg", {type: "image/jpeg"}));
        } finally {
            URL.revokeObjectURL(source);
        }
    } catch {
        if (selection === photoSelection) mediaStatus.textContent = "Could not prepare this photo. Try another JPEG or PNG.";
    }
});

function draftKey() { return "dysociate-live-draft-" + client.thread.id; }

function saveDraft() {
    if (!initialized) return;
    try {
        localStorage.setItem(draftKey(), JSON.stringify({
            body: body.value, displayName: displayName.value, parentId, pending,
        }));
    } catch { /* The composer still works when local storage is unavailable. */ }
}

function restoreDraft() {
    try {
        const saved = JSON.parse(localStorage.getItem(draftKey()) || "{}");
        if (typeof saved.body === "string") body.value = saved.body;
        if (typeof saved.displayName === "string") displayName.value = saved.displayName;
        if (typeof saved.parentId === "string" && /^p_[A-Za-z0-9_-]{22}$/.test(saved.parentId)) parentId = saved.parentId;
        if (saved.pending?.authorId === client.viewerAuthorId &&
            /^[A-Za-z0-9_-]{22,64}$/.test(saved.pending?.operationId || "") &&
            typeof saved.pending.signature === "string") pending = saved.pending;
    } catch { /* An unavailable or invalid draft starts with empty fields. */ }
}

function updatePostLabel() {
    const reelAttached = attachment?.type === "video/mp4";
    submit.textContent = reelAttached ? (parentId ? "Post reel reply" : "Post reel") : (parentId ? "Post reply" : "Post");
}

function replyLabel() {
    byId("reply-target").hidden = !parentId;
    byId("reply-label").textContent = parentId ?
        "Replying to " + (client.posts.get(parentId)?.displayName || "an earlier post") : "";
    updatePostLabel();
}

function chooseReply(post) {
    if (busy) return;
    parentId = post.id;
    replyLabel();
    saveDraft();
    body.focus();
}

function action(label, command) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = label;
    button.addEventListener("click", command);
    return button;
}

function element(tag, text, className) {
    const node = document.createElement(tag);
    node.textContent = text;
    if (className) node.className = className;
    return node;
}

function postRow(post, parentContext) {
    const row = document.createElement("article");
    row.dataset.postId = post.id;
    row.tabIndex = -1;
    row.append(element("h2", post.displayName));
    if (post.parentId) {
        const context = action("Reply to " + parentContext.name, () => void jumpToPost(post.parentId));
        context.className = "reply-context";
        row.append(context);
        if (parentContext.excerpt) row.append(element("p", parentContext.excerpt, "reply-excerpt"));
    }
    if (post.deletedAt) row.append(element("p", "Post deleted by author", "deleted"));
    else {
        if (post.body) row.append(element("p", post.body, "post-body"));
        if (post.media) {
            const src = client.api + "/media/" + post.id;
            if (post.media.type === "video/mp4") {
                const video = document.createElement("video");
                video.controls = video.playsInline = true;
                video.preload = "none";
                video.src = src;
                row.append(video);
            } else {
                const image = document.createElement("img");
                image.alt = "Photo posted by " + post.displayName;
                image.loading = "lazy";
                image.src = src;
                row.append(image);
            }
        }
    }
    const actions = element("div", "", "post-actions");
    actions.append(action("Reply", () => chooseReply(post)));
    if (!post.deletedAt) {
        const like = action("", () => void toggleLike(post.id));
        like.className = "like-button";
        actions.append(like);
    }
    if (!post.deletedAt && client.viewerAuthorId === post.authorId) {
        actions.append(action("Delete my post", event => removePost(post, event.currentTarget)));
    }
    row.append(actions);
    return row;
}

function ensureRow(post) {
    const parent = client.posts.get(post.parentId);
    const context = parent ? {name: parent.deletedAt ? "deleted post" : parent.displayName, excerpt: parent.body?.slice(0, 96)} :
        {name: post.parentContext?.excerpt === null ? "deleted post" : (post.parentContext?.name || "an earlier post"),
            excerpt: post.parentContext?.excerpt};
    const contextKey = JSON.stringify(context);
    let row = rows.get(post.id);
    if (!row || row.version !== post.updatedSeq || row.contextKey !== contextKey) {
        const replacement = postRow(post, context);
        if (row) row.element.replaceWith(replacement);
        row = {element: replacement, version: post.updatedSeq, contextKey};
        rows.set(post.id, row);
    }
    return row.element;
}

function moveRows(container, elements) {
    let next = container.firstElementChild;
    for (const node of elements) {
        if (node === next) next = next.nextElementSibling;
        else container.insertBefore(node, next);
    }
    while (next) {
        const obsolete = next;
        next = next.nextElementSibling;
        obsolete.remove();
    }
}

function branchFor(rootId) {
    let branch = branches.get(rootId);
    if (!branch) {
        const group = element("section", "", "post-group");
        const toggle = action("", () => void toggleBranch(rootId));
        const panel = element("div", "", "reply-branch");
        const list = element("div", "");
        const more = action("Load more replies", () => void fetchBranch(rootId));
        panel.id = "replies-" + rootId;
        toggle.setAttribute("aria-controls", panel.id);
        toggle.className = "branch-toggle";
        panel.append(list, more);
        group.append(toggle, panel);
        branch = {group, toggle, panel, list, more, open: false, after: 0, loading: false};
        branches.set(rootId, branch);
    }
    return branch;
}

async function fetchBranch(rootId) {
    const branch = branchFor(rootId);
    if (branch.loading || branch.after === null) return;
    branch.loading = true;
    render("interaction");
    try {
        const page = await client.loadBranch(rootId, branch.after);
        branch.after = page.nextAfter;
    } catch (error) { feedback.textContent = error.message; }
    finally {
        branch.loading = false;
        render("interaction");
    }
}

async function toggleBranch(rootId) {
    const branch = branchFor(rootId);
    branch.open = !branch.open;
    render("interaction");
    if (branch.open && branch.after === 0) await fetchBranch(rootId);
}

async function jumpToPost(postId) {
    try {
        const {root, post} = client.posts.has(postId) && client.posts.has(client.posts.get(postId).rootId)
            ? {post: client.posts.get(postId), root: client.posts.get(client.posts.get(postId).rootId)}
            : await client.loadTarget(postId);
        if (post.parentId) branchFor(root.id).open = true;
        render("interaction");
        const anchor = rows.get(postId)?.element;
        anchor?.focus({preventScroll: true});
        anchor?.scrollIntoView({block: "center"});
    } catch (error) { feedback.textContent = error.message; }
}

function openPostFragment() {
    const target = /^#post=(p_[A-Za-z0-9_-]{22})$/.exec(location.hash)?.[1];
    if (target) void jumpToPost(target);
}

function updateLike(postId, button) {
    const reaction = client.reactions.get(postId);
    const liked = reaction?.liked === true;
    const heart = liked ? "❤️" : "♡";
    button.textContent = reaction ? `${heart} · ${reaction.count}` : heart;
    button.setAttribute("aria-label", reaction ? `Like (${reaction.count})` : "Like");
    button.setAttribute("aria-pressed", String(liked));
    button.disabled = !reaction || likesInFlight.has(postId);
}

function queueReaction(postId) {
    reactionRequests.add(postId);
    if (reactionTimer) return;
    reactionTimer = setTimeout(async () => {
        reactionTimer = null;
        const ids = [...reactionRequests];
        reactionRequests.clear();
        try {
            await client.loadReactions(ids);
            for (const id of ids) {
                const button = rows.get(id)?.element.querySelector(".like-button");
                if (button) updateLike(id, button);
            }
        } catch { /* Reconnect reloads visible reactions. */ }
    }, 40);
}

async function toggleLike(postId) {
    const reaction = client.reactions.get(postId);
    if (!reaction || likesInFlight.has(postId)) return;
    const command = {liked: !reaction.liked, actorRevision: reaction.actorRevision, operationId: crypto.randomUUID()};
    likesInFlight.add(postId);
    updateLike(postId, rows.get(postId).element.querySelector(".like-button"));
    try {
        await client.like(postId, command);
    } catch (error) {
        if (!error.code) {
            // Reuse the same ID after an uncertain response. If another tab
            // already moved on, its actor revision prevents a stale write.
            try { await client.like(postId, command); return; }
            catch (retryError) { error = retryError; }
        }
        feedback.textContent = error.message;
        queueReaction(postId);
    } finally {
        likesInFlight.delete(postId);
        const button = rows.get(postId)?.element.querySelector(".like-button");
        if (button) updateLike(postId, button);
    }
}

function render(event) {
    if (event === "requests") {
        void refreshRequests();
        return;
    }
    if (event === "reaction-refresh") {
        for (const [id, row] of rows) if (row.element.isConnected && !row.element.closest("[hidden]")) queueReaction(id);
        return;
    }
    if (event?.type === "reaction.changed") {
        if (rows.get(event.postId)?.element.isConnected) queueReaction(event.postId);
        return;
    }
    const connection = byId("connection");
    connection.textContent = client.status;
    connection.dataset.live = String(client.status === "Live");
    if (!client.thread) {
        if (client.access) showAccess();
        return;
    }
    clearTimeout(accessTimer);
    byId("access-gate").hidden = true;
    if (!initialized) {
        initialized = true;
        byId("title").textContent = client.thread.title;
        byId("share").hidden = false;
        bindFollow(client);
        byId("creator-label").hidden = client.access?.role !== "creator";
        byId("join-requests").hidden = client.access?.role !== "creator";
        composer.hidden = false;
        byId("media-actions").hidden = !client.media?.photos;
        byId("record-reel").hidden = !client.media?.reels || !reel.supported;
        restoreDraft();
        replyLabel();
        queueMicrotask(openPostFragment);
    }
    byId("older").hidden = client.olderCursor === null;
    const atEnd = timeline.scrollHeight - timeline.scrollTop - timeline.clientHeight < 56;
    const grouped = new Map();
    for (const post of client.posts.values()) {
        if (post.parentId) {
            if (!grouped.has(post.rootId)) grouped.set(post.rootId, []);
            grouped.get(post.rootId).push(post);
        }
        if (post.createdSeq > latestCreation) {
            latestCreation = post.createdSeq;
            if (event !== "interaction" && (!atEnd || post.parentId)) {
                unseenPostId = post.id;
                activity.hidden = false;
            }
        }
    }
    const mounted = [];
    const groups = client.visibleRoots().map(root => {
        const branch = branchFor(root.id);
        const rootRow = ensureRow(root);
        if (branch.group.firstElementChild !== rootRow) branch.group.prepend(rootRow);
        mounted.push(root);
        const count = client.rootCounts.get(root.id) || 0;
        branch.toggle.hidden = count === 0;
        branch.toggle.textContent = branch.open ? "Hide replies" : `View ${count} ${count === 1 ? "reply" : "replies"}`;
        branch.toggle.setAttribute("aria-expanded", String(branch.open));
        branch.panel.hidden = !branch.open;
        if (branch.open) {
            const replies = (grouped.get(root.id) || []).sort((a, b) => a.createdSeq - b.createdSeq);
            moveRows(branch.list, replies.map(ensureRow));
            branch.more.hidden = branch.after === null;
            branch.more.disabled = branch.loading;
            branch.more.textContent = branch.loading ? "Loading replies…" : "Load more replies";
            mounted.push(...replies);
        }
        return branch.group;
    });
    moveRows(posts, groups);
    for (const post of mounted) {
        const button = rows.get(post.id).element.querySelector(".like-button");
        if (!button) continue;
        if (!client.reactions.has(post.id)) queueReaction(post.id);
        updateLike(post.id, button);
    }
    if (atEnd && !unseenPostId && event !== "interaction") jumpToEnd();
}

function jumpToEnd() {
    timeline.scrollTop = timeline.scrollHeight;
    activity.hidden = true;
    unseenPostId = null;
}

const accessGate = byId("access-gate");
const joinForm = byId("join-form");
const passkeyForm = byId("passkey-form");
let accessTimer;
let accessBusy = false;
let requestsBusy = false;
let requestsQueued = false;

function showAccess() {
    const {state, passkey} = client.access;
    byId("title").textContent = "Locked thread";
    accessGate.hidden = false;
    joinForm.hidden = state !== "unrequested";
    passkeyForm.hidden = !passkey || state === "declined";
    byId("access-state").textContent = {
        unrequested: "Ask the creator to let you in.",
        pending: "Request sent. This page will open the thread when you’re approved.",
        declined: "The creator declined this request.",
    }[state] || "";
    clearTimeout(accessTimer);
    if (state === "pending" && !document.hidden) accessTimer = setTimeout(checkAccess, 5000);
}

async function checkAccess() {
    if (accessBusy || document.hidden || client.thread || !["pending", "approved"].includes(client.access?.state)) return;
    try {
        await client.checkAccess();
        byId("access-feedback").textContent = client.claimError || "";
    } catch (error) {
        byId("access-feedback").textContent = error.message;
        accessTimer = setTimeout(checkAccess, 10000);
    }
}

async function requestAccess(event, withPasskey) {
    event.preventDefault();
    if (accessBusy) return;
    accessBusy = true;
    clearTimeout(accessTimer);
    const buttons = accessGate.querySelectorAll("button");
    buttons.forEach(button => { button.disabled = true; });
    byId("access-feedback").textContent = "";
    const payload = {name: byId("join-name").value.trim() || "Guest"};
    if (withPasskey) payload.passkey = byId("join-passkey").value;
    try {
        await client.join(payload);
        byId("join-passkey").value = "";
    } catch (error) {
        byId("access-feedback").textContent = error.message;
        if (["pending", "approved"].includes(client.access?.state)) accessTimer = setTimeout(checkAccess, 5000);
    } finally {
        accessBusy = false;
        buttons.forEach(button => { button.disabled = false; });
    }
}

function renderRequests(requests) {
    byId("request-count").textContent = requests.length ? "(" + requests.length + ")" : "";
    const list = byId("request-list");
    list.replaceChildren();
    if (!requests.length) list.append(element("p", "No pending requests."));
    for (const request of requests) {
        const row = element("div", "", "join-request");
        const name = element("p", request.name + " · " + new Date(request.requestedAt).toLocaleString());
        const buttons = element("div", "", "share-actions");
        buttons.append(action("Approve", () => decide(request.id, "approved", buttons)),
            action("Decline", () => decide(request.id, "declined", buttons)));
        row.append(name, buttons);
        list.append(row);
    }
}

async function refreshRequests() {
    if (requestsBusy) { requestsQueued = true; return; }
    requestsBusy = true;
    try {
        const {requests} = await client.request(client.api + "/requests");
        renderRequests(requests);
    } catch (error) {
        byId("request-feedback").textContent = error.message;
    } finally {
        requestsBusy = false;
        if (requestsQueued) {
            requestsQueued = false;
            void refreshRequests();
        }
    }
}

async function decide(id, decision, buttons) {
    for (const button of buttons.children) button.disabled = true;
    const feedback = byId("request-feedback");
    try {
        const {requests} = await client.request(client.api + "/requests/" + id, "POST", {decision});
        renderRequests(requests);
        feedback.textContent = decision === "approved" ? "Guest approved." : "Request declined.";
    } catch (error) {
        feedback.textContent = error.message;
        for (const button of buttons.children) button.disabled = false;
        void refreshRequests();
    }
}

joinForm.addEventListener("submit", event => void requestAccess(event, false));
passkeyForm.addEventListener("submit", event => void requestAccess(event, true));
byId("join-requests").addEventListener("toggle", event => {
    if (event.currentTarget.open) void refreshRequests();
});

function setBusy(value) {
    busy = value;
    for (const control of [body, displayName, submit, byId("cancel-reply"), photoInput,
        byId("choose-photo"), byId("record-reel"), byId("remove-media")]) control.disabled = value;
}

composer.addEventListener("submit", async event => {
    event.preventDefault();
    if (busy || (!body.value.trim() && !attachment)) return;
    const payload = {body: body.value.trim(), displayName: displayName.value.trim() || "Guest", parentId};
    setBusy(true);
    feedback.textContent = "Posting…";
    try {
        if (client.agreementsRequired && !client.agreementAccepted) {
            if (!await reviewAgreements(client.api + "/agreement")) {
                feedback.textContent = "Your draft is still here. Accept both agreements to post.";
                return;
            }
            client.agreementAccepted = true;
            feedback.textContent = "Agreements accepted. Your draft is ready to post.";
            return;
        }
        if (attachment && !attachmentHash) {
            const bytes = await crypto.subtle.digest("SHA-256", await attachment.arrayBuffer());
            attachmentHash = Array.from(new Uint8Array(bytes), byte => byte.toString(16).padStart(2, "0")).join("");
        }
        const signature = JSON.stringify({...payload, attachmentHash: attachmentHash ?? undefined});
        if (!pending || pending.signature !== signature) {
            pending = {signature, operationId: crypto.randomUUID(), authorId: client.viewerAuthorId};
        }
        saveDraft();
        const sentPost = await client.post({...payload, operationId: pending.operationId}, attachment);
        body.value = "";
        useAttachment(null);
        parentId = null;
        pending = null;
        replyLabel();
        saveDraft();
        feedback.textContent = "";
        if (payload.parentId) {
            if (unseenPostId === sentPost.id) {
                unseenPostId = null;
                activity.hidden = true;
            }
            void jumpToPost(sentPost.id);
        }
        else jumpToEnd();
    } catch (error) {
        if (error.code === "agreements_required") {
            client.agreementAccepted = false;
            client.agreementsRequired = true;
        }
        feedback.textContent = error.message + " Your draft is still here.";
    } finally { setBusy(false); }
});

async function removePost(post, button) {
    if (!window.confirm("Delete your post? Replies will stay in the thread.")) return;
    button.disabled = true;
    try { await client.delete(post.id); feedback.textContent = ""; }
    catch (error) { feedback.textContent = error.message; }
    finally { button.disabled = false; }
}

byId("older").addEventListener("click", async () => {
    if (olderBusy) return;
    olderBusy = true;
    byId("older").disabled = true;
    const viewportTop = timeline.getBoundingClientRect().top;
    const anchor = [...posts.children].find(row => row.getBoundingClientRect().bottom > viewportTop);
    try {
        const offset = anchor?.getBoundingClientRect().top;
        await client.loadOlder();
        if (anchor?.isConnected) timeline.scrollTop += anchor.getBoundingClientRect().top - offset;
    } catch (error) { feedback.textContent = error.message; }
    finally { olderBusy = false; byId("older").disabled = false; }
});

const shareButton = byId("share");
const sharePanel = byId("share-panel");
const shareUrl = byId("share-url");
const shareStatus = byId("share-status");
const copyLink = byId("copy-link");
const shareDevice = byId("share-device");
const shareData = {title: "dλsociate thread", url: location.origin + location.pathname};
shareUrl.value = shareData.url;
byId("share-email").href = "mailto:?subject=" + encodeURIComponent(shareData.title) +
    "&body=" + encodeURIComponent(shareData.url);

// Windows Edge hands Web Share to a system picker the page cannot dismiss.
// Keep the copy and email actions independent of that handoff.
const windows = /\bWindows\b/i.test(navigator.userAgentData?.platform || navigator.userAgent);
shareDevice.hidden = windows || typeof navigator.share !== "function";

function showSharePanel(open) {
    if (open && byId("follow-thread").getAttribute("aria-expanded") === "true") byId("follow-thread").click();
    sharePanel.hidden = !open;
    shareButton.setAttribute("aria-expanded", String(open));
    if (open) {
        shareStatus.textContent = "";
        copyLink.focus();
    } else {
        shareButton.focus();
    }
}

shareButton.addEventListener("click", () => showSharePanel(sharePanel.hidden));
sharePanel.addEventListener("keydown", event => {
    if (event.key !== "Escape") return;
    event.preventDefault();
    showSharePanel(false);
});

copyLink.addEventListener("click", async () => {
    try {
        await navigator.clipboard.writeText(shareData.url);
        shareStatus.textContent = "Link copied.";
    } catch {
        shareUrl.focus();
        shareUrl.select();
        shareStatus.textContent = "Copy the selected link.";
    }
});

shareDevice.addEventListener("click", async () => {
    if (shareDevice.hidden) return;
    shareDevice.disabled = true;
    try {
        await navigator.share(shareData);
    } catch (error) {
        if (error.name !== "AbortError") shareStatus.textContent = "Use Copy link or Email link to share.";
    } finally {
        shareDevice.disabled = false;
    }
});

byId("cancel-reply").addEventListener("click", () => { parentId = null; replyLabel(); saveDraft(); });
activity.addEventListener("click", () => {
    const target = unseenPostId;
    unseenPostId = null;
    activity.hidden = true;
    if (target) void jumpToPost(target);
    else jumpToEnd();
});
body.addEventListener("input", saveDraft);
displayName.addEventListener("input", saveDraft);
document.addEventListener("visibilitychange", () => {
    if (!document.hidden) {
        client.resume();
        void checkAccess();
    } else clearTimeout(accessTimer);
});
window.addEventListener("online", () => { client.resume(); void checkAccess(); });
window.visualViewport?.addEventListener("resize", () => {
    document.documentElement.style.setProperty("--view-height", Math.round(window.visualViewport.height) + "px");
});

async function open() {
    byId("title").textContent = "Opening thread…";
    byId("retry-open").hidden = true;
    feedback.textContent = "";
    try {
        await client.start(creatorToken);
        if (client.claimError && client.access?.role !== "creator") byId("access-feedback").textContent = client.claimError;
    }
    catch (error) {
        byId("title").textContent = "Thread unavailable";
        client.setStatus("Offline");
        feedback.textContent = error.message;
        byId("retry-open").hidden = false;
    }
}

byId("retry-open").addEventListener("click", open);
void open();
