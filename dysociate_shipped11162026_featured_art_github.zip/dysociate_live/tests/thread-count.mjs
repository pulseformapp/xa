/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import assert from "node:assert/strict";
import {randomUUID} from "node:crypto";

const origin = new URL(process.argv[2]);
assert.equal(origin.hostname, "127.0.0.1", "Use an isolated local Worker.");
const request = (path, options) => fetch(new URL(path, origin), {...options, signal: AbortSignal.timeout(10_000)});
const json = {"Content-Type": "application/json"};
const stats = async () => {
    const response = await request("/api/v1/stats");
    assert.equal(response.status, 200);
    const result = await response.json();
    assert.deepEqual(Object.keys(result), ["liveThreadsCreated"]);
    return result.liveThreadsCreated;
};

const before = await stats();
assert.equal((await request("/api/v1/stats", {method: "POST"})).status, 404);
const session = await request("/api/v1/session", {method: "POST", headers: json, body: '{"client":"native"}'});
assert.equal(session.status, 201);
const {credential} = await session.json();
const headers = {...json, Authorization: "Bearer " + credential};
const create = payload => request("/api/v1/threads", {method: "POST", headers, body: JSON.stringify(payload)});
const draft = {operationId: randomUUID(), title: "Counter QA", openingPost: {body: "Synthetic creation"}};
const replays = await Promise.all(Array.from({length: 4}, () => create(draft)));
assert.deepEqual(replays.map(response => response.status).sort(), [200, 200, 200, 201]);
const results = await Promise.all(replays.map(response => response.json()));
assert.equal(new Set(results.map(result => result.shareUrl)).size, 1);
assert.equal(await stats(), before + 1);

assert.equal((await create({...draft, title: "Conflicting retry"})).status, 409);
assert.equal((await create({...draft, operationId: randomUUID(), openingPost: {}})).status, 400);
assert.equal(await stats(), before + 1);

const locked = await create({...draft, operationId: randomUUID(), accessMode: "locked"});
assert.equal(locked.status, 201);
const privateThread = await locked.json();
assert.match(privateThread.shareUrl, /\/t\/l-/);
assert.equal(await stats(), before + 2);

const route = "/api/v1/threads/" + new URL(results[0].shareUrl).pathname.slice(3);
const {posts} = await (await request(route)).json();
assert.equal((await request(route + "/posts/" + posts[0].id, {method: "DELETE", headers})).status, 200);
assert.equal(await stats(), before + 2);
console.log("PASS public total, concurrent retries, invalid and conflicting requests, locked creation, and deletion");
