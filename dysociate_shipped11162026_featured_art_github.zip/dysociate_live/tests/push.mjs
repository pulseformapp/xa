/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import assert from "node:assert/strict";
import {createRequire} from "node:module";
import {randomBytes, randomUUID, createECDH, hkdfSync, createDecipheriv, createPublicKey, verify} from "node:crypto";
import {basename, dirname, resolve} from "node:path";
import {readdir, readFile} from "node:fs/promises";
import {setTimeout as sleep} from "node:timers/promises";
import {runInNewContext} from "node:vm";
import {checkSubscription, encryptPush} from "../push.mjs";

// RFC 8291 Section 5 known-answer vector. These are published fixture keys.
const publicBytes = Buffer.from("BP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A8", "base64url");
const curve = {name: "ECDH", namedCurve: "P-256"};
const keyPair = {
    publicKey: await crypto.subtle.importKey("raw", publicBytes, curve, true, []),
    privateKey: await crypto.subtle.importKey("jwk", {kty: "EC", crv: "P-256", x: publicBytes.subarray(1, 33).toString("base64url"),
        y: publicBytes.subarray(33).toString("base64url"), d: "yfWPiYE-n46HLnH0KqZOF1fJJU3MYrct3AELtAQ-oRw"}, curve, false, ["deriveBits"]),
};
const encrypted = await encryptPush({auth: "BTBZMqHH6r4Tts7J_aSIgg",
    p256dh: "BCVxsr7N_eNgVRqvHtD0zTZsEc6-VV-JvLexhqUzORcxaOzi6-AYWXvTBHm4bjyPjs7Vd8pZGH6SRpkNtoIAiw4"},
"When I grow up, I want to be a watermelon", {keyPair, salt: Buffer.from("DGv6ra1nlYgDCS1FRnbzlw", "base64url")});
assert.equal(Buffer.from(encrypted).toString("base64url"), "DGv6ra1nlYgDCS1FRnbzlwAAEABBBP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A_yl95bQpu6cVPTpK4Mqgkf1CXztLVBSt2Ks3oZwbuwXPXLWyouBWLVWGNWQexSgSxsj_Qulcy4a-fN");
console.log("PASS RFC 8291 encryption vector");

const events = new Map();
let notification, opened, pending;
let shown = 0, installed = false;
const serviceWorker = await readFile(new URL("../web/push-sw.js", import.meta.url), "utf8");
runInNewContext(serviceWorker, {URL, self: {
    addEventListener: (name, handler) => events.set(name, handler), location: {origin: "https://test.example"},
    skipWaiting: async () => { installed = true; },
    registration: {
        getNotifications: async ({tag}) => notification?.options.tag === tag ? [notification.options] : [],
        showNotification: async (title, options) => { shown++; notification = {title, options}; },
    },
    clients: {openWindow: async url => { opened = url; }},
}});
const validTarget = {followId: "a".repeat(43), postId: "p_" + "b".repeat(22)};
events.get("install")({waitUntil: promise => { pending = promise; }});
await pending;
assert.equal(installed, true);
const pushEvent = payload => ({data: {json: () => payload}, waitUntil: promise => { pending = promise; }});
events.get("push")(pushEvent({followId: "https://outside.example"}));
assert.equal(notification, undefined);
events.get("push")(pushEvent({...validTarget, title: "Private thread", body: "Private post"}));
await pending;
assert.equal(notification.title, "dλsociate");
assert.equal(notification.options.body, "New activity in a thread you follow.");
assert.equal(notification.options.renotify, true);
events.get("push")(pushEvent(validTarget));
await pending;
assert.equal(shown, 1);
const nextTarget = {...validTarget, postId: "p_" + "c".repeat(22)};
events.get("push")(pushEvent(nextTarget));
await pending;
assert.equal(shown, 2);
assert.equal(notification.options.tag, validTarget.followId);
assert.equal(notification.options.renotify, true);
events.get("notificationclick")({notification: {...notification.options, close() {}}, waitUntil: promise => { pending = promise; }});
await pending;
assert.equal(opened, `https://test.example/t/following#open=${nextTarget.followId}.${nextTarget.postId}`);
assert.equal(events.has("fetch"), false);
console.log("PASS worker activation, quiet duplicate handling, renewed alerts, and exact reply targets");

const [dependencies, bundle] = process.argv.slice(2);
if (!dependencies || !bundle) throw Error("Pass the Wrangler node_modules folder and built worker.js path.");
const {Miniflare, convertV4MiniflareOptions} = createRequire(resolve(dependencies, "worker-test.cjs"))("miniflare");
const vapid = await crypto.subtle.generateKey({name: "ECDSA", namedCurve: "P-256"}, true, ["sign", "verify"]);
const rawVapid = Buffer.from(await crypto.subtle.exportKey("raw", vapid.publicKey)).toString("base64url");
const verifyKey = createPublicKey({key: await crypto.subtle.exportKey("jwk", vapid.publicKey), format: "jwk"});
const subject = "https://dysociate.org";
const deliveries = [];
const devices = new Map();
const responseCodes = new Map();
const origin = "https://test.example";

function device(name) {
    const key = createECDH("prime256v1");
    const publicKey = key.generateKeys();
    const auth = randomBytes(16);
    devices.set(name, {key, publicKey, auth});
    return {endpoint: "https://fcm.googleapis.com/fcm/send/" + name,
        keys: {p256dh: publicKey.toString("base64url"), auth: auth.toString("base64url")}};
}

async function provider(request) {
    const url = new URL(request.url, "https://fcm.googleapis.com");
    const name = url.pathname.split("/").at(-1);
    const {key, publicKey, auth} = devices.get(name);
    const header = request.headers.authorization;
    const match = /^vapid t=([\w.-]+), k=([\w-]+)$/.exec(header);
    assert.equal(match[2], rawVapid);
    const [jwtHeader, claims, signature] = match[1].split(".");
    assert.equal(verify("sha256", Buffer.from(jwtHeader + "." + claims),
        {key: verifyKey, dsaEncoding: "ieee-p1363"}, Buffer.from(signature, "base64url")), true);
    assert.equal(JSON.parse(Buffer.from(claims, "base64url")).aud, url.origin);
    assert.equal(request.headers["content-encoding"], "aes128gcm");
    assert.equal(request.headers.urgency, "high");
    const parts = [];
    for await (const chunk of request) parts.push(chunk);
    const body = Buffer.concat(parts);
    const sender = body.subarray(21, 86);
    const shared = key.computeSecret(sender);
    const ikm = hkdfSync("sha256", shared, auth, Buffer.concat([Buffer.from("WebPush: info\0"), publicKey, sender]), 32);
    const cek = hkdfSync("sha256", ikm, body.subarray(0, 16), "Content-Encoding: aes128gcm\0", 16);
    const nonce = hkdfSync("sha256", ikm, body.subarray(0, 16), "Content-Encoding: nonce\0", 12);
    const decoder = createDecipheriv("aes-128-gcm", cek, nonce);
    decoder.setAuthTag(body.subarray(-16));
    const plaintext = Buffer.concat([decoder.update(body.subarray(86, -16)), decoder.final()]);
    assert.equal(plaintext.at(-1), 2);
    const payload = JSON.parse(plaintext.subarray(0, -1));
    assert.deepEqual(Object.keys(payload).sort(), ["followId", "postId"]);
    deliveries.push({name, ...payload});
    return responseCodes.get(name)?.shift() ?? 201;
}

const root = dirname(resolve(bundle));
const entry = basename(bundle);
const source = await readFile(bundle, "utf8");
const files = [...new Set([...source.matchAll(/from "\.\/([^"/]+)"/g)].map(match => match[1]))];
assert.ok(files.includes((await readdir(root)).find(name => name.endsWith("-push-sw.js"))));
const modules = [{path: resolve(bundle), type: "ESModule", contents: source}];
for (const file of files) {
    const binary = file.endsWith(".png");
    modules.push({path: resolve(root, file), type: binary ? "Data" : "Text",
        contents: await readFile(resolve(root, file), binary ? undefined : "utf8")});
}
assert.equal(entry, "worker.js");
const options = convertV4MiniflareOptions({workers: [{name: "push-qa", modulesRoot: root, modules, compatibilityDate: "2026-11-11",
    durableObjects: {THREADS: {className: "LiveThread", useSQLite: true}, PUSH_BUDGET: {className: "PushBudget", useSQLite: true}},
    outboundService: {node: async (request, response) => {
        try { response.writeHead(await provider(request)).end(); }
        catch (error) { console.error(error); response.writeHead(500).end(); }
    }}, bindings: {PUBLIC_ORIGIN: origin, ACTIVE_INVITE_KEY_ID: "v1",
        INVITE_KEYS: JSON.stringify({v1: randomBytes(32).toString("base64url")}), ENABLE_LOCKED: "true", ENABLE_WEB_PUSH: "true",
        PUSH_VAPID_PRIVATE_JWK: JSON.stringify(await crypto.subtle.exportKey("jwk", vapid.privateKey)),
        PUSH_VAPID_PUBLIC_KEY: rawVapid, PUSH_VAPID_SUBJECT: subject, PUSH_DAILY_LIMIT: "4"}}]});
const miniflare = new Miniflare(options);

async function call(path, method = "GET", payload, actor, expected = 200) {
    const headers = {"Content-Type": "application/json"};
    if (actor?.includes("=")) Object.assign(headers, {Cookie: actor, Origin: origin});
    else if (actor) headers.Authorization = "Bearer " + actor;
    if (payload?.client === "browser") headers.Origin = origin;
    const result = await miniflare.dispatchFetch(origin + path, {method, headers,
        body: payload === undefined ? undefined : JSON.stringify(payload)});
    const body = await result.json();
    assert.equal(result.status, expected, JSON.stringify(body));
    return {body, cookie: result.headers.get("Set-Cookie")?.split(";")[0]};
}

async function waitFor(count, timeout = 8000) {
    const start = Date.now();
    while (deliveries.length < count && Date.now() - start < timeout) await sleep(100);
    assert.equal(deliveries.length, count);
}

try {
    const {body: {credential: owner}} = await call("/api/v1/session", "POST", {client: "native"}, null, 201);
    const {cookie: alice} = await call("/api/v1/session", "POST", {client: "browser"});
    const {cookie: bob} = await call("/api/v1/session", "POST", {client: "browser"});
    const create = async locked => (await call("/api/v1/threads", "POST", {title: "Push QA", operationId: randomUUID(),
        openingPost: {body: "Opening"}, ...(locked ? {accessMode: "locked"} : {})}, owner, 201)).body;
    const room = await create(false);
    const locked = await create(true);
    const apiFor = thread => "/api/v1/threads/" + new URL(thread.shareUrl).pathname.slice(3);
    const api = apiFor(room);
    const aliceId = randomBytes(32).toString("base64url");
    const bobId = randomBytes(32).toString("base64url");
    const a = device("alice");
    const b = device("bob");
    await assert.rejects(() => checkSubscription({...a, endpoint: "https://push.apple.com.evil.example/secret"}));
    await assert.rejects(() => checkSubscription({...a, endpoint: "https://fcm.googleapis.com:8080/fcm/send/example"}));
    const follow = (id, mode, subscription, actor, status = 200, prefix = api) =>
        call(prefix + "/follow/" + id, "PUT", {mode, ...(subscription ? {subscription} : {})}, actor, status);
    await call(apiFor(locked) + "/join", "POST", {name: "Pending"}, alice);
    await follow(aliceId, "all", a, alice, 403, apiFor(locked));
    await follow(aliceId, "replies", a, alice);
    await follow(bobId, "all", b, bob);
    const post = async (actor, parentId, operationId = randomUUID()) => (await call(api + "/posts", "POST",
        {operationId, body: "Synthetic test post", ...(parentId ? {parentId} : {})}, actor, 201)).body.post;
    const parent = await post(alice);
    const reply = await post(owner, parent.id);
    await waitFor(2);
    assert.deepEqual(deliveries.sort((left, right) => left.name.localeCompare(right.name)), [
        {name: "alice", followId: aliceId, postId: reply.id}, {name: "bob", followId: bobId, postId: reply.id},
    ]);
    await follow(aliceId, "muted", null, alice);
    responseCodes.set("bob", [503, 410]);
    const next = await post(owner, parent.id);
    await waitFor(3);
    await waitFor(4, 18000);
    assert.deepEqual(deliveries.slice(2), Array.from({length: 2}, () => ({name: "bob", followId: bobId, postId: next.id})));
    assert.equal((await call(api + "/follow/" + bobId, "GET", undefined, bob)).body.mode, null);
    await follow(bobId, "all", b, bob);
    await post(bob); // A device never gets its own activity.
    await post(owner); // The account exhausted its four provider attempts.
    await sleep(6000);
    assert.equal(deliveries.length, 4);
    assert.equal((await call(api + "/follow/" + aliceId, "DELETE", undefined, alice)).body.mode, null);
    console.log("PASS real Durable Object alarms, opt-in modes, coalescing, locked access, encrypted delivery, retry, 410 cleanup, and account budget");
} finally { await miniflare.dispose(); }
