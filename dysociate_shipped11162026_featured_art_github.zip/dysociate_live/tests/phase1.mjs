/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import assert from "node:assert/strict";
import {randomUUID} from "node:crypto";

const origin = new URL(process.argv[2]);
assert.ok(origin.protocol === "http:" && origin.hostname === "127.0.0.1", "Use a local Worker.");

async function call(path, method = "GET", payload, credential, cookie) {
    const headers = {};
    if (credential) headers.Authorization = "Bearer " + credential;
    if (cookie) Object.assign(headers, {Cookie: cookie, Origin: origin.origin});
    if (payload?.client === "browser") headers.Origin = origin.origin;
    if (payload !== undefined) headers["Content-Type"] = "application/json";
    const result = await fetch(new URL(path, origin), {
        method, headers, body: payload === undefined ? undefined : JSON.stringify(payload),
        signal: AbortSignal.timeout(10000),
    });
    return {status: result.status, body: await result.json(), cookie: result.headers.get("Set-Cookie")?.split(";")[0]};
}

async function credential() {
    const result = await call("/api/v1/session", "POST", {client: "native"});
    assert.equal(result.status, 201);
    return result.body.credential;
}

async function create(owner) {
    const result = await call("/api/v1/threads", "POST", {
        operationId: randomUUID(), title: "Synthetic live test", openingPost: {body: "Opening post"},
    }, owner);
    assert.equal(result.status, 201);
    return {...result.body, api: "/api/v1/threads/" + new URL(result.body.shareUrl).pathname.slice(3)};
}

const [owner, guest] = await Promise.all([credential(), credential()]);
const [thread, elsewhere] = await Promise.all([create(owner), create(owner)]);
const posting = thread.api + "/posts";
const original = {operationId: randomUUID(), body: "Author's first reply", parentId: thread.post.id};
assert.equal((await call(posting, "POST", original)).status, 401);
assert.equal((await call(posting, "POST", {...original, parentId: elsewhere.post.id}, owner)).status, 404);
const copies = await Promise.all([call(posting, "POST", original, owner), call(posting, "POST", original, owner)]);
assert.deepEqual(copies.map(value => value.status).sort(), [200, 201]);
assert.deepEqual(copies[0].body, copies[1].body);
const authorPost = copies[0].body.post;
assert.equal(authorPost.createdSeq, 2);
assert.equal((await call(posting, "POST", {...original, body: "Changed"}, owner)).status, 409);
const reply = await call(posting, "POST", {
    operationId: randomUUID(), body: "Guest reply survives deletion", parentId: authorPost.id,
}, guest);
assert.equal(reply.status, 201);
assert.equal(reply.body.post.createdSeq, 3);
assert.equal((await call(posting + "/" + reply.body.post.id, "DELETE", undefined, owner)).status, 403);
assert.equal((await call(posting + "/" + authorPost.id, "DELETE", undefined, guest)).status, 403);
const deleted = await call(posting + "/" + authorPost.id, "DELETE", undefined, owner);
assert.equal(deleted.status, 200);
assert.equal(deleted.body.post.updatedSeq, 4);
assert.equal(deleted.body.post.body, null);
assert.equal(deleted.body.post.createdSeq, 2);
assert.deepEqual((await call(posting + "/" + authorPost.id, "DELETE", undefined, owner)).body, deleted.body);
assert.deepEqual((await call(posting, "POST", original, owner)).body, deleted.body);

const changes = (await call(thread.api + "/changes?after=1")).body;
assert.deepEqual(changes, {posts: [reply.body.post, deleted.body.post], nextAfter: 4, hasMore: false});
assert.equal((await call(thread.api + "/changes?after=-1")).status, 400);
assert.equal((await call(thread.api + "/changes?after=5")).status, 400);
assert.equal((await call(elsewhere.api)).body.headSeq, 1);

// Cross both page sizes and check that concurrent writers get unique,
// ordered sequences. Synthetic data stays in the local test namespace.
for (let start = 0; start < 104; start += 8) {
    const batch = Array.from({length: 8}, (_, i) => call(posting, "POST", {
        operationId: randomUUID(), body: "Pagination " + (start + i),
    }, guest));
    assert.ok((await Promise.all(batch)).every(result => result.status === 201));
}
const snapshot = (await call(thread.api)).body;
assert.equal(snapshot.headSeq, 108);
assert.equal(snapshot.posts.length, 50);
assert.equal(snapshot.olderCursor, snapshot.posts[0].createdSeq);
const seen = [...snapshot.posts];
let before = snapshot.olderCursor;
while (before !== null) {
    const page = (await call(thread.api + "/history?before=" + before)).body;
    seen.unshift(...page.posts);
    before = page.olderCursor;
}
assert.equal(seen.length, 107);
assert.equal(new Set(seen.map(post => post.id)).size, 107);
// Sequence 4 belongs to a deletion. History keeps each post's creation order.
const creationSequences = Array.from({length: 108}, (_, index) => index + 1).filter(seq => seq !== 4);
assert.deepEqual(seen.map(post => post.createdSeq), creationSequences);
assert.equal(seen[1].body, null);
assert.equal(seen[2].parentId, seen[1].id);
const first = (await call(thread.api + "/changes?after=0")).body;
assert.equal(first.posts.length, 100);
assert.equal(first.hasMore, true);
const last = (await call(thread.api + "/changes?after=" + first.nextAfter)).body;
assert.equal(last.hasMore, false);
assert.equal(last.nextAfter, 108);
const all = first.posts.concat(last.posts);
assert.equal(all.length, 107);
assert.ok(all.every((post, index) => index === 0 || post.updatedSeq > all[index - 1].updatedSeq));
assert.equal(all.find(post => post.id === authorPost.id).body, null);
console.log("PASS replies, ownership, deletion, retry deduplication, canonical replay, and pagination");

const [branchThread, consentThread] = await Promise.all([create(owner), create(owner)]);
const roots = branchThread.api + "?view=groups";
const rootId = branchThread.post.id;
let parentId = rootId;
for (let index = 0; index < 52; index++) {
    const response = await call(branchThread.api + "/posts", "POST", {
        operationId: randomUUID(), parentId, body: "Nested reply " + index,
    }, guest);
    assert.equal(response.status, 201);
    parentId = response.body.post.id;
}
const grouped = (await call(roots)).body;
assert.equal(grouped.posts.length, 1);
assert.equal(grouped.posts[0].rootReplyCount, 52);
const branch = (await call(branchThread.api + "/branch/" + rootId + "?after=0")).body;
assert.equal(branch.posts.length, 50);
const remaining = (await call(branchThread.api + "/branch/" + rootId + "?after=" + branch.nextAfter)).body;
assert.deepEqual(remaining.posts.map(post => post.rootId), [rootId, rootId]);
assert.equal(remaining.nextAfter, null);
const selected = await call(branchThread.api + "/target/" + parentId);
assert.equal(selected.body.root.id, rootId);
assert.equal(selected.body.post.id, parentId);
assert.equal((await call(consentThread.api + "/target/" + parentId)).status, 404);

const reaction = branchThread.api + "/like/" + rootId;
const like = {operationId: randomUUID(), liked: true, actorRevision: 0};
const pair = await Promise.all([call(reaction, "PUT", like, owner), call(reaction, "PUT", like, guest)]);
assert.ok(pair.every(result => result.status === 200));
const repeat = (await call(reaction, "PUT", like, owner)).body;
assert.equal(repeat.count, 2);
const unlike = (await call(reaction, "PUT", {operationId: randomUUID(), liked: false, actorRevision: repeat.actorRevision}, owner)).body;
assert.equal(unlike.count, 1);
assert.equal((await call(reaction, "PUT", like, owner)).status, 409);
assert.equal((await call(roots)).body.headSeq, grouped.headSeq);
await call(branchThread.api + "/posts/" + rootId, "DELETE", undefined, owner);
assert.equal((await call(reaction, "PUT", like, guest)).status, 404);
assert.equal((await call(branchThread.api + "/target/" + parentId)).body.root.body, null);
console.log("PASS deep reply groups, paged counts, target isolation, concurrent Likes, stale retries, and deleted roots");

if (process.argv.includes("--agreements")) {
    const browser = (await call("/api/v1/session", "POST", {client: "browser"})).cookie;
    const creation = {operationId: randomUUID(), title: "Agreement QA", openingPost: {body: "New room"}};
    const {version, license, karmicLaw} = (await call("/api/v1/agreements", "GET", undefined, null, browser)).body;
    assert.match(license, /GNU GENERAL PUBLIC LICENSE/);
    assert.ok(karmicLaw.endsWith("~ as above so below ~"));
    const data = {version, license: true, karmicLaw: true};
    assert.equal((await call("/api/v1/threads", "POST", creation, null, browser)).body.error.code, "agreements_required");
    assert.equal((await call("/api/v1/session", "POST", {client: "native"}, null, browser)).body.error.code, "browser_session_required");
    assert.equal((await call("/api/v1/threads", "POST", creation, owner, browser)).body.error.code, "browser_session_required");
    assert.equal((await call("/api/v1/agreements", "POST", {...data, karmicLaw: false}, null, browser)).status, 409);
    assert.equal((await call("/api/v1/agreements", "POST", {...data, version: "old"}, null, browser)).status, 409);
    const signed = (await call("/api/v1/agreements", "POST", data, null, browser)).cookie;
    const authorized = browser + "; " + signed;
    const otherBrowser = (await call("/api/v1/session", "POST", {client: "browser"})).cookie;
    assert.equal((await call("/api/v1/threads", "POST", creation, null, otherBrowser + "; " + signed)).status, 403);
    const made = await call("/api/v1/threads", "POST", creation, null, authorized);
    assert.equal(made.status, 201);
    const ownApi = "/api/v1/threads/" + new URL(made.body.shareUrl).pathname.slice(3);
    const message = {operationId: randomUUID(), body: "Same session, separate threads"};
    assert.equal((await call(ownApi + "/posts", "POST", message, null, authorized)).status, 201);
    const guestApi = consentThread.api;
    assert.equal((await call(guestApi, "GET", undefined, null, authorized)).status, 200);
    assert.equal((await call(guestApi + "/posts", "POST", message, null, authorized)).status, 403);
    assert.equal((await call(guestApi + "/agreement", "POST", data, null, authorized)).status, 200);
    assert.equal((await call(guestApi + "/posts", "POST", message, null, browser)).status, 201);
    assert.equal((await call(guestApi + "/posts", "POST", message, null, browser)).status, 200);
    assert.equal((await call(branchThread.api + "/posts", "POST", message, null, browser)).status, 403);
    console.log("PASS versioned creator consent, session binding, creator continuity, and per-thread guest consent");
}
