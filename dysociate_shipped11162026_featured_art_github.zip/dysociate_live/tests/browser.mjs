/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import assert from "node:assert/strict";
import {spawn} from "node:child_process";
import {randomUUID} from "node:crypto";
import {mkdir, mkdtemp, readFile, writeFile} from "node:fs/promises";
import path from "node:path";
import {setTimeout as pause} from "node:timers/promises";

const [address, executable, qa, ...modes] = process.argv.slice(2);
const origin = new URL(address);
const media = modes.includes("--media");
const locked = modes.includes("--locked");
const createInBrowser = modes.includes("--create");
const cameraOffTest = modes.includes("--camera-off");
const followTest = modes.includes("--following");
const backgroundPushTest = modes.includes("--push-background");
const pushEnrollmentTest = modes.includes("--push-enrollment");
const allowed = origin.protocol === "http:" && origin.hostname === "127.0.0.1" ||
    origin.origin === "https://dysociate-live-pilot.pulseform.workers.dev" ||
    (modes.includes("--production") && origin.origin === "https://dysociate.org");
assert.ok(allowed && executable && qa,
    "Usage: node tests/browser.mjs <origin> <Chromium executable> <QA folder> [--production]");
assert.ok(!(backgroundPushTest || pushEnrollmentTest) || origin.hostname === "127.0.0.1", "Use loopback for simulated push.");
await mkdir(qa, {recursive: true});
const profile = await mkdtemp(path.join(path.resolve(qa), "live-browser-"));

async function until(check, label, timeout = 12000) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
        const value = await check();
        if (value) return value;
        await pause(80);
    }
    throw Error("Timed out waiting for " + label);
}

const child = spawn(executable, [
    "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
    "--disable-background-networking", "--disable-component-update", "--disable-sync",
    ...(media ? ["--use-fake-device-for-media-stream", "--use-fake-ui-for-media-stream"] : []),
    "--remote-debugging-port=0", "--remote-debugging-address=127.0.0.1", "--user-data-dir=" + profile, "about:blank",
], {windowsHide: true, stdio: "ignore"});
child.on("error", () => {});
let socket;
let serial = 0;
const pending = new Map();
const registrations = new Map();

async function cdp(method, params = {}, sessionId) {
    const id = ++serial;
    return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
            pending.delete(id);
            reject(Error("Timed out in " + method));
        }, 15000);
        pending.set(id, message => {
            clearTimeout(timer);
            if (message.error) reject(Error(message.error.message));
            else resolve(message.result);
        });
        socket.send(JSON.stringify({id, method, params, sessionId}));
    });
}

async function browserSession(width, height, url, context) {
    const browserContextId = context ?? (await cdp("Target.createBrowserContext")).browserContextId;
    const {targetId} = await cdp("Target.createTarget", {url: "about:blank", browserContextId});
    const {sessionId} = await cdp("Target.attachToTarget", {targetId, flatten: true});
    const call = (method, params) => cdp(method, params, sessionId);
    await call("Page.enable");
    await call("DOM.enable");
    await call("Network.enable");
    await call("Emulation.setDeviceMetricsOverride", {width, height, deviceScaleFactor: 1, mobile: width < 600});
    if (width < 600) await call("Emulation.setTouchEmulationEnabled", {enabled: true});
    await call("Page.addScriptToEvaluateOnNewDocument", {source: `
        window.qaSockets = [];
        window.qaShares = [];
        window.qaCopied = [];
        window.WebSocket = class extends WebSocket {
            constructor(...args) { super(...args); window.qaSockets.push(this); }
        };
        window.confirm = () => true;
        const windows = ${width >= 600};
        Object.defineProperty(navigator, "userAgentData", {value: {platform: windows ? "Windows" : "Android"}});
        Object.defineProperty(navigator, "share", {value: data => {
            window.qaShares.push(data);
            // A system picker can remain open indefinitely. Keep this promise
            // pending on Windows so an accidental call fails the regression.
            return windows ? new Promise(() => {}) : Promise.resolve();
        }});
        Object.defineProperty(navigator, "clipboard", {value: {async writeText(url) {
            if (!windows) throw new DOMException("Clipboard denied", "NotAllowedError");
            window.qaCopied.push(url);
        }}});
        if (${media} && navigator.mediaDevices) {
            const media = navigator.mediaDevices;
            const capture = media.getUserMedia.bind(media);
            media.getUserMedia = async settings => {
                window.qaCameraChoice = settings.video.deviceId?.exact;
                if (window.qaCameraChoice === "qa-backup-camera") delete settings.video.deviceId;
                const stream = await capture(settings);
                window.qaCameraTrack = stream.getVideoTracks()[0];
                if (window.qaReplaceCamera) {
                    window.qaReplacementTrack = window.qaCameraCanvas.captureStream(20).getVideoTracks()[0];
                    window.qaCameraTrack.stop();
                    window.qaCameraTrack = window.qaReplacementTrack;
                    return new MediaStream([window.qaReplacementTrack, ...stream.getAudioTracks()]);
                }
                return stream;
            };
            const devices = media.enumerateDevices.bind(media);
            media.enumerateDevices = async () => [
                ...await devices(), {kind: "videoinput", deviceId: "qa-backup-camera", label: "Backup camera"},
            ];
            const nextFrame = HTMLVideoElement.prototype.requestVideoFrameCallback;
            HTMLVideoElement.prototype.requestVideoFrameCallback = function(callback) {
                return nextFrame.call(this, (...args) => {
                    if (!window.qaStallCamera) callback(...args);
                });
            };
        }
    `});
    await call("Page.navigate", {url});
    return {call, browserContextId, async eval(expression) {
        const result = await call("Runtime.evaluate", {expression, returnByValue: true, awaitPromise: true, userGesture: true});
        assert.ok(!result.exceptionDetails, result.exceptionDetails?.exception?.description || result.exceptionDetails?.text);
        return result.result.value;
    }};
}

async function checkBrowserCreation() {
    const creator = await browserSession(390, 844, new URL("/t/new", origin).href);
    if (modes.includes("--agreements")) {
        await until(() => creator.eval("Boolean(document.querySelector('.agreement-dialog[open]'))"), "creator agreements");
        assert.equal(await creator.eval("document.querySelector('#create-thread').hidden"), true);
        await creator.eval("document.querySelector('[data-decline]').click()");
        await until(() => creator.eval("location.pathname === '/'"), "creator can decline and return to the site");
        await creator.call("Page.navigate", {url: new URL("/t/new", origin).href});
        await until(() => creator.eval("Boolean(document.querySelector('.agreement-dialog[open]'))"), "creator reopens terms");
        await acceptTerms(creator);
    }
    await until(() => creator.eval("document.querySelector('#create-thread')?.hidden === false"), "creation form");
    const lockedAvailable = await creator.eval("!document.querySelector('#locked-options').hidden");
    assert.equal(lockedAvailable, !modes.includes("--text-only"));
    await creator.eval(`
        document.querySelector('#thread-title').value = 'Browser QA';
        document.querySelector('#opening-post').value = 'Created directly in a browser';
        document.querySelector('#locked').checked = ${lockedAvailable};
        document.querySelector('#locked').dispatchEvent(new Event('input', {bubbles: true}));
        document.querySelector('#passkey').value = 'SyntheticBrowserPasskey';
        window.qaCreationAttempts = [];
        const send = window.fetch;
        window.fetch = async (url, options) => {
            if (url !== '/api/v1/threads' || options?.method !== 'POST') return send(url, options);
            const payload = JSON.parse(options.body);
            qaCreationAttempts.push(payload.operationId);
            const response = await send(url, options);
            if (qaCreationAttempts.length === 1) {
                window.qaCommitted = await response.clone().json();
                throw new TypeError('Simulated lost create response');
            }
            return response;
        };
        document.querySelector('#create-thread').requestSubmit();
    `);
    await until(() => creator.eval("Boolean(window.qaCommitted?.shareUrl) && document.querySelector('#create-submit').textContent === 'Retry creation'"), "committed request with lost response");
    assert.equal(await creator.eval("sessionStorage.getItem('dysociate-live-create').includes('SyntheticBrowserPasskey')"), false);
    await creator.eval("document.querySelector('#create-thread').requestSubmit()");
    await until(() => creator.eval("!document.querySelector('#creation-result').hidden"), "creation retry result");
    const link = await creator.eval("document.querySelector('#thread-link').value");
    assert.equal(await creator.eval("qaCreationAttempts.length === 2 && qaCreationAttempts[0] === qaCreationAttempts[1] && qaCommitted.shareUrl === document.querySelector('#thread-link').value"), true);
    await creator.call("Page.reload");
    await until(() => creator.eval("!document.querySelector('#creation-result').hidden"), "receipt restored on reload");
    const guest = await browserSession(390, 844, link);
    await creator.call("Page.navigate", {url: link});
    await until(() => live(creator), "creator opened new thread");
    assert.equal(await deleteCount(creator), 1);
    assert.equal(await hasPost(creator, "Created directly in a browser"), true);
    if (lockedAvailable) {
        await until(() => guest.eval("!document.querySelector('#access-gate').hidden"), "locked guest gate");
        assert.equal(await hasPost(guest, "Created directly in a browser"), false);
        await guest.eval("document.querySelector('#ask-to-join').click()");
        await until(() => creator.eval("document.querySelector('#request-count').textContent === '(1)'"), "browser creator notified");
        await creator.eval("document.querySelector('#join-requests').open = true; document.querySelector('#request-list button').click()");
    }
    await until(() => live(guest), "guest can join created thread");
    await post(guest, "Browser-created thread reply", "Created directly in a browser");
    await acceptPostTerms(guest);
    await openReplies(creator, "Created directly in a browser");
    await until(() => hasPost(creator, "Browser-created thread reply"), "reply visible to browser creator");
    console.log("PASS mobile browser creation, idempotent retry, reload recovery, creator ownership, and guest replies");
}

const live = browser => browser.eval("document.querySelector('#connection')?.textContent === 'Live'");
const hasPost = (browser, text) => browser.eval(`
    [...document.querySelectorAll('.post-body')].some(node => node.textContent === ${JSON.stringify(text)} && !node.closest('[hidden]'))
`);
const deleteCount = browser => browser.eval(
    "[...document.querySelectorAll('.post-actions button')].filter(node => node.textContent === 'Delete my post').length",
);

async function post(browser, text, replyTo) {
    if (replyTo) await browser.eval(`
        [...document.querySelectorAll('.post-body')].find(node => node.textContent === ${JSON.stringify(replyTo)})
            .closest('article').querySelector('.post-actions button').click()
    `);
    await browser.eval(`
        document.querySelector('#body').value = ${JSON.stringify(text)};
        document.querySelector('#body').dispatchEvent(new Event('input'));
        document.querySelector('#composer').requestSubmit();
    `);
}

async function acceptTerms(browser) {
    const agree = "document.querySelector('.agreement-dialog [data-agree]')";
    assert.equal(await browser.eval(`${agree}?.hidden`), true);
    await browser.eval(`document.querySelector('.agreement-text').scrollTop = 1e7; void 0`);
    await until(() => browser.eval(`${agree}?.hidden === false`), "license end");
    await browser.eval(`${agree}.click()`);
    assert.equal(await browser.eval("document.querySelector('.agreement-text').textContent.endsWith('~ as above so below ~')"), true);
    await browser.eval("document.querySelector('.agreement-text').scrollTop = 1e7; void 0");
    await until(() => browser.eval(`${agree}?.hidden === false`), "Karmic Law end");
    await browser.eval(`${agree}.click()`);
    await until(() => browser.eval("!document.querySelector('.agreement-dialog')"), "agreement acceptance saved");
}

async function acceptPostTerms(browser) {
    if (!modes.includes("--agreements")) return;
    await until(() => browser.eval("Boolean(document.querySelector('.agreement-dialog[open]'))"), "guest agreements");
    await acceptTerms(browser);
    await until(() => browser.eval("!document.querySelector('#submit-post').disabled && document.querySelector('#body').value.length > 0"), "accepted terms return to draft");
    await browser.eval("document.querySelector('#composer').requestSubmit()");
}

async function openReplies(browser, text) {
    const toggle = `[...document.querySelectorAll('.post-group')].find(group =>
        group.querySelector('article .post-body')?.textContent === ${JSON.stringify(text)})?.querySelector('.branch-toggle')`;
    await until(() => browser.eval(`${toggle}?.hidden === false`), "reply group count");
    await browser.eval(`if (${toggle}.getAttribute('aria-expanded') === 'false') ${toggle}.click()`);
}

async function createThread() {
    const endpoint = path => new URL(path, origin);
    const session = await fetch(endpoint("/api/v1/session"), {
        method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({client: "native"}),
    });
    assert.equal(session.status, 201);
    const {credential} = await session.json();
    const created = await fetch(endpoint("/api/v1/threads"), {
        method: "POST",
        headers: {"Content-Type": "application/json", Authorization: "Bearer " + credential},
        body: JSON.stringify({operationId: randomUUID(), title: "Browser test thread", openingPost: {body: "Opening post"}}),
    });
    assert.equal(created.status, 201);
    return (await created.json()).shareUrl;
}

async function checkLockedThread() {
    const endpoint = path => new URL(path, origin);
    const session = await fetch(endpoint("/api/v1/session"), {
        method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({client: "native"}),
    });
    assert.equal(session.status, 201);
    const {credential} = await session.json();
    const native = (path, body) => fetch(endpoint(path), {
        method: "POST", headers: {"Content-Type": "application/json", Authorization: "Bearer " + credential},
        body: JSON.stringify(body),
    });
    const created = await native("/api/v1/threads", {operationId: randomUUID(), title: "Private browser QA",
        accessMode: "locked", openingPost: {body: "Approved viewers only"}});
    assert.equal(created.status, 201);
    const {shareUrl} = await created.json();
    const api = "/api/v1/threads" + new URL(shareUrl).pathname.slice(2);
    const response = await native(api + "/handoff", {});
    assert.equal(response.status, 200);
    const {creatorUrl} = await response.json();
    const [creator, guest, visitor] = await Promise.all([
        browserSession(1200, 800, creatorUrl),
        browserSession(390, 844, shareUrl),
        browserSession(390, 844, shareUrl),
    ]);
    await until(async () => await live(creator) && await guest.eval("!document.querySelector('#access-gate').hidden"), "locked gate and creator");
    assert.equal(await creator.eval("location.hash"), "");
    assert.equal(await creator.eval("document.querySelector('#share-url').value"), shareUrl);
    assert.equal(await guest.eval("document.querySelector('#composer').hidden"), true);
    assert.equal(await hasPost(guest, "Approved viewers only"), false);
    assert.equal(await guest.eval("document.querySelector('#passkey-form').hidden"), true);
    await guest.eval(`document.querySelector('#join-name').value = 'Browser Guest';
        document.querySelector('#ask-to-join').click()`);
    await until(() => guest.eval("document.querySelector('#access-state').textContent.startsWith('Request sent')"), "pending approval");
    await guest.call("Page.reload");
    await until(() => guest.eval("document.querySelector('#access-state').textContent.startsWith('Request sent')"), "pending survives reload");
    const mistakenHandoff = await native(api + "/handoff", {});
    assert.equal(mistakenHandoff.status, 200);
    await guest.call("Page.navigate", {url: (await mistakenHandoff.json()).creatorUrl});
    await until(() => guest.eval("document.querySelector('#access-feedback')?.textContent.includes('different browser profile')"),
        "same-profile creator link rejected");
    assert.equal(await guest.eval("document.querySelector('#composer').hidden"), true);
    assert.equal(await hasPost(guest, "Approved viewers only"), false);
    assert.equal(await creator.eval("document.querySelector('#creator-label').hidden"), false);
    await until(() => creator.eval("document.querySelector('#request-count').textContent === '(1)'"), "creator notified");
    await creator.eval("document.querySelector('#join-requests').open = true");
    await until(() => creator.eval("document.querySelector('#request-list').textContent.includes('Browser Guest')"), "guest is named");
    await creator.eval("document.querySelector('#request-list button').click()");
    await until(() => live(guest), "guest enters automatically after approval");
    assert.equal(await hasPost(guest, "Approved viewers only"), true);
    await post(guest, "Live reply from approved guest", "Approved viewers only");
    await acceptPostTerms(guest);
    await openReplies(creator, "Approved viewers only");
    await until(() => hasPost(creator, "Live reply from approved guest"), "creator receives guest reply");
    assert.equal(await deleteCount(creator), 0);
    assert.equal(await deleteCount(guest), 1);
    assert.equal(await hasPost(visitor, "Approved viewers only"), false);
    assert.equal(await visitor.eval("document.querySelector('#composer').hidden"), true);
    await creator.call("Page.reload");
    await until(() => live(creator), "creator access after reload");
    assert.equal(await creator.eval("document.querySelector('#join-requests').hidden"), false);

    const withCode = await native("/api/v1/threads", {operationId: randomUUID(), title: "Passkey browser QA",
        accessMode: "locked", passkey: "SyntheticBrowserCode", openingPost: {body: "Opened with a passkey"}});
    assert.equal(withCode.status, 201);
    const passkeyGuest = await browserSession(390, 844, (await withCode.json()).shareUrl);
    await until(() => passkeyGuest.eval("!document.querySelector('#passkey-form').hidden"), "passkey form visible");
    const enterCode = code => passkeyGuest.eval(`
        document.querySelector('#join-passkey').value = ${JSON.stringify(code)};
        document.querySelector('#passkey-form').requestSubmit()`);
    await enterCode("SyntheticWrongCode");
    await until(() => passkeyGuest.eval("document.querySelector('#access-feedback').textContent.includes('did not match')"), "incorrect passkey");
    assert.equal(await hasPost(passkeyGuest, "Opened with a passkey"), false);
    await enterCode("SyntheticBrowserCode");
    await until(() => live(passkeyGuest), "passkey grants live access");
    assert.equal(await hasPost(passkeyGuest, "Opened with a passkey"), true);
    console.log("PASS locked mobile browser gate, creator notification, durable request, automatic admission, and live reply");
    console.log("PASS creator access after reload and mobile passkey entry with wrong-code recovery");
}

async function checkSharing(desktop, phone, invite) {
    for (const view of [desktop, phone]) {
        await view.eval("document.querySelector('#share').click()");
        assert.deepEqual(await view.eval(`({
            visible: !document.querySelector('#share-panel').hidden,
            expanded: document.querySelector('#share').getAttribute('aria-expanded'),
            url: document.querySelector('#share-url').value,
            emailBody: new URLSearchParams(document.querySelector('#share-email').href.split('?')[1]).get('body'),
            shareCalls: window.qaShares.length
        })`), {visible: true, expanded: "true", url: invite, emailBody: invite, shareCalls: 0});
    }
    assert.equal(await desktop.eval("document.querySelector('#share-device').hidden"), true);
    await desktop.eval("document.querySelector('#copy-link').click()");
    await until(() => desktop.eval("document.querySelector('#share-status').textContent === 'Link copied.'"), "link copied");
    assert.deepEqual(await desktop.eval("window.qaCopied"), [invite]);
    assert.equal(await desktop.eval("window.qaShares.length"), 0);

    await phone.eval("document.querySelector('#copy-link').click()");
    assert.equal(await phone.eval(`
        (() => {
            const field = document.querySelector('#share-url');
            return document.activeElement === field && field.selectionStart === 0 &&
                field.selectionEnd === field.value.length;
        })()
    `), true);
    assert.equal(await phone.eval("document.querySelector('#share-device').hidden"), false);
    await phone.eval("document.querySelector('#share-device').click()");
    assert.deepEqual(await phone.eval("window.qaShares"), [{title: "dλsociate thread", url: invite}]);

    for (const view of [desktop, phone]) {
        await view.eval("document.activeElement.dispatchEvent(new KeyboardEvent('keydown', {key: 'Escape', bubbles: true}))");
        assert.equal(await view.eval("document.querySelector('#share-panel').hidden && document.activeElement.id === 'share'"), true);
    }
    console.log("PASS in-page sharing bypasses the Windows picker, copies the invite, and keeps mobile sharing available");
}

async function checkMedia(sender, viewer) {
    const {root} = await sender.call("DOM.getDocument");
    const {nodeId} = await sender.call("DOM.querySelector", {nodeId: root.nodeId, selector: "#post-photo"});
    const large = modes.includes("--large-photo");
    const photoPath = path.resolve(large ? qa : profile, large ? "large-photo.png" : "photo.png");
    if (!large) await writeFile(photoPath, Buffer.from(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j9uoAAAAASUVORK5CYII=", "base64"));
    await sender.call("DOM.setFileInputFiles", {nodeId, files: [photoPath]});
    await until(() => sender.eval("document.querySelector('#photo-preview').naturalWidth > 0"), "photo preview");
    if (large) {
        assert.equal(await sender.eval("document.querySelector('#photo-preview').naturalWidth"), 1200);
    }
    await post(sender, "Photo from the composer");
    await until(() => viewer.eval("document.querySelector('#posts img')?.naturalWidth > 0"), "live photo");

    assert.equal(await sender.eval("document.querySelector('#record-reel').hidden"), false, "MP4 capture is available");
    await sender.eval("document.querySelector('#record-reel').click()");
    await until(() => sender.eval("!document.querySelector('[data-reel-record]').hidden"), "camera ready");
    const record = () => sender.eval("document.querySelector('[data-reel-record]').click()");
    const stop = () => sender.eval("document.querySelector('[data-reel-stop]').click()");
    const ready = () => sender.eval("!document.querySelector('[data-reel-use]').hidden");
    const retake = () => sender.eval("document.querySelector('[data-reel-retake]').click()");
    await until(() => sender.eval("!document.querySelector('[data-reel-camera-picker]').hidden"), "camera choices");
    await sender.eval(`const select = document.querySelector('[data-reel-camera]');
        select.value = 'qa-backup-camera';
        select.dispatchEvent(new Event('change'))`);
    await until(() => sender.eval("window.qaCameraChoice === 'qa-backup-camera' && !document.querySelector('[data-reel-record]').hidden"), "replacement camera");
    await sender.eval("window.qaCameraTrack.dispatchEvent(new Event('mute'))");
    assert.equal(await sender.eval("document.querySelector('[data-reel-record]').hidden"), true);
    assert.equal(await ready(), false);
    assert.match(await sender.eval("document.querySelector('[data-reel-status]').textContent"), /interrupted/);
    await retake();
    await until(() => sender.eval("!document.querySelector('[data-reel-record]').hidden"), "camera retry");
    await record();
    await sender.eval("window.qaCameraTrack.stop(); window.qaCameraTrack.dispatchEvent(new Event('ended'))");
    assert.equal(await sender.eval("document.querySelector('[data-reel-stop]').hidden"), true);
    assert.equal(await ready(), false);
    assert.equal(await sender.eval("document.querySelector('#remove-media').hidden"), true);
    await retake();
    await until(() => sender.eval("!document.querySelector('[data-reel-record]').hidden"), "camera retry after interruption");
    await sender.eval("window.qaStallCamera = true");
    await until(() => sender.eval("document.querySelector('[data-reel-status]').textContent.includes('stopped sending video')"), "stalled camera");
    assert.equal(await ready(), false);
    await sender.eval("window.qaStallCamera = false");
    await retake();
    await until(() => sender.eval("!document.querySelector('[data-reel-record]').hidden"), "camera retry after stall");
    console.log("PASS changing cameras, interruption before and during recording, frame stall, and camera recovery");
    if (cameraOffTest) {
        const fixture = await readFile(path.join(qa, "camera-off.png"));
        await sender.eval(`(async () => {
            const picture = new Image();
            const bytes = Uint8Array.from(atob('${fixture.toString("base64")}'), value => value.charCodeAt(0));
            picture.src = URL.createObjectURL(new Blob([bytes], {type: 'image/png'}));
            await picture.decode();
            URL.revokeObjectURL(picture.src);
            window.qaCameraCanvas = document.createElement('canvas');
            qaCameraCanvas.width = 480;
            qaCameraCanvas.height = 360;
            const context = qaCameraCanvas.getContext('2d');
            window.qaReplaceCamera = true;
            window.qaDrawCamera = setInterval(() => {
                context.fillStyle = '#121212';
                context.fillRect(0, 0, 480, 360);
                if (window.qaShowCameraOff) context.drawImage(picture, 0, 0, 480, 360);
            }, 50);
        })()`);
        await retake();
        await until(() => sender.eval("!document.querySelector('[data-reel-record]').hidden"), "dark camera remains usable");
        await record();
        await sender.eval("window.qaShowCameraOff = true");
        await until(() => sender.eval("document.querySelector('[data-reel-status]').textContent.includes('camera-off image')"), "live camera-off frames");
        assert.equal(await ready(), false);
        assert.equal(await sender.eval("document.querySelector('#remove-media').hidden"), true);
        await sender.eval("window.qaReplaceCamera = false; clearInterval(window.qaDrawCamera)");
        await retake();
        await until(() => sender.eval("!document.querySelector('[data-reel-record]').hidden"), "camera retry after placeholder");
        console.log("PASS dark video is accepted and the camera-off graphic stops an active take");
    }
    await record();
    await pause(900);
    await stop();
    await until(ready, "first reel preview");
    await retake();
    await until(() => sender.eval("!document.querySelector('[data-reel-record]').hidden"), "camera ready after retake");
    await record();
    if (modes.includes("--long-reel")) {
        await until(ready, "automatic stop and reel preview", 34000);
    } else {
        await pause(1000);
        await stop();
        await until(ready, "second reel preview");
    }
    await sender.eval("document.querySelector('[data-reel-use]').click()");
    assert.equal(await sender.eval("document.querySelector('#submit-post').textContent"), "Post reel");
    assert.equal(await sender.eval("document.querySelector('#body').required"), false);
    await sender.eval("document.querySelector('#submit-post').click()");
    await until(() => viewer.eval("!!document.querySelector('#posts video')"), "live reel");
    await viewer.eval(`(() => {
        const video = document.querySelector('#posts video');
        video.muted = true;
        void video.play().catch(() => {});
    })()`);
    await until(() => viewer.eval("document.querySelector('#posts video').currentTime > 0"), "reel playing");
    console.log("PASS photo preview and live rendering, reel recording and retake, and playback on a second device viewport");
}

try {
    const addressFile = path.join(profile, "DevToolsActivePort");
    const [port, endpoint] = await until(async () => {
        try {
            const lines = (await readFile(addressFile, "utf-8")).trim().split(/\r?\n/);
            return lines.length === 2 ? lines : null;
        } catch { return null; }
    }, "temporary Chromium profile");
    socket = new WebSocket("ws://127.0.0.1:" + port + endpoint);
    await new Promise((resolve, reject) => {
        socket.addEventListener("open", resolve, {once: true});
        socket.addEventListener("error", reject, {once: true});
    });
    socket.onmessage = event => {
        const message = JSON.parse(event.data);
        if (message.method === "ServiceWorker.workerRegistrationUpdated") {
            for (const registration of message.params.registrations) registrations.set(registration.scopeURL, registration.registrationId);
        }
        const callback = pending.get(message.id);
        if (callback) {
            pending.delete(message.id);
            callback(message);
        }
    };

    if (origin.protocol === "http:") {
        const sourceUrl = new URL("../web/thread.html", import.meta.url).href;
        const source = await browserSession(800, 600, sourceUrl);
        await until(() => source.eval("location.protocol === 'file:' && document.readyState === 'complete'"), "source template opened");
        assert.equal(await source.eval("document.querySelector('#title').textContent"), "Open a live thread link");
        assert.equal(await source.eval("document.querySelector('#composer').hidden"), true);
        console.log("PASS opening the source template directly shows link instructions");
    }

    if (pushEnrollmentTest) await checkPushEnrollment();
    else if (backgroundPushTest) await checkBackgroundPush();
    else if (createInBrowser) await checkBrowserCreation();
    else if (locked) await checkLockedThread();
    else await checkWildWest();
} finally {
    if (socket?.readyState === WebSocket.OPEN) {
        // Send the close command without waiting for the browser to acknowledge
        // it after the debugger connection goes away.
        socket.send(JSON.stringify({id: ++serial, method: "Browser.close"}));
        socket.close();
    }
    if (child.exitCode === null) child.kill();
}

async function checkWildWest() {
    const [invite, otherInvite] = await Promise.all([createThread(), createThread()]);
    const [desktop, phone, other] = await Promise.all([
        browserSession(1280, 850, invite), browserSession(390, 844, invite), browserSession(400, 820, otherInvite),
    ]);
    await until(async () => await live(desktop) && await live(phone) && await live(other), "browsers live");
    assert.equal(await hasPost(phone, "Opening post"), true);
    assert.equal(await phone.eval("!document.querySelector('.agreement-dialog')"), true);
    assert.equal(await deleteCount(phone), 0);
    assert.equal(await phone.eval(`
        document.documentElement.scrollWidth === innerWidth &&
        document.querySelector('#submit-post').getBoundingClientRect().bottom <= innerHeight
    `), true);
    await checkSharing(desktop, phone, invite);
    if (followTest) await checkFollowing(phone, invite);

    const parent = "Desktop says hello <img src=x onerror=alert(1)>";
    const sent = performance.now();
    await post(desktop, parent);
    await acceptPostTerms(desktop);
    await until(() => hasPost(phone, parent), "desktop post in phone");
    const desktopToPhone = Math.round(performance.now() - sent);
    assert.equal(await phone.eval("document.querySelector('#posts img') === null"), true);
    assert.equal(await deleteCount(phone), 0);
    assert.equal(await deleteCount(desktop), 1);

    const replied = performance.now();
    await post(phone, "Phone replies", parent);
    if (modes.includes("--agreements")) {
        await until(() => phone.eval("Boolean(document.querySelector('.agreement-dialog[open]'))"), "guest terms on first reply");
        await phone.eval("document.querySelector('[data-decline]').click()");
        await until(() => phone.eval("!document.querySelector('.agreement-dialog') && !document.querySelector('#submit-post').disabled"), "decline returns to draft");
        assert.equal(await phone.eval("document.querySelector('#body').value"), "Phone replies");
        assert.equal(await hasPost(desktop, "Phone replies"), false);
        await phone.eval("document.querySelector('#composer').requestSubmit()");
        await acceptPostTerms(phone);
    }
    await openReplies(desktop, parent);
    await until(() => hasPost(desktop, "Phone replies"), "phone reply in desktop");
    await until(() => hasPost(phone, "Phone replies"), "sender opened the new reply branch");
    const phoneToDesktop = Math.round(performance.now() - replied);
    assert.equal(await deleteCount(phone), 1);
    assert.equal(await deleteCount(desktop), 1);
    assert.equal(await hasPost(other, parent), false);
    assert.equal(await hasPost(other, "Phone replies"), false);
    await desktop.eval(`
        [...document.querySelectorAll('.post-actions button')].find(button => button.textContent === 'Delete my post').click()
    `);
    await until(() => phone.eval("!!document.querySelector('.deleted')"), "author deletion in phone");
    assert.equal(await hasPost(phone, parent), false);
    assert.equal(await hasPost(phone, "Phone replies"), true);
    const like = "document.querySelector('.reply-branch .like-button')";
    const count = browser => browser.eval(`${like}?.textContent`);
    await until(() => phone.eval(`${like}?.disabled === false`), "reply Like loaded");
    assert.equal(await count(phone), '♡ · 0');
    assert.equal(await phone.eval(`${like}?.getAttribute('aria-label')`), 'Like (0)');
    await phone.eval(`${like}.click()`);
    await until(async () => (await count(desktop)) === '♡ · 1' && (await count(phone)) === '❤️ · 1', "like syncs without filling the other viewer's heart");
    assert.equal(await phone.eval(`${like}?.getAttribute('aria-pressed')`), 'true');

    await phone.eval("document.querySelector('.reply-context').click()");
    await until(() => phone.eval("document.activeElement?.querySelector('.deleted') !== null && document.activeElement?.tagName === 'ARTICLE'"), "jump to deleted parent");

    const network = {latency: 0, downloadThroughput: -1, uploadThroughput: -1};
    await phone.call("Network.emulateNetworkConditions", {...network, offline: true});
    await phone.eval("window.qaSockets.at(-1).dispatchEvent(new CloseEvent('close'))");
    await until(() => phone.eval("document.querySelector('#connection').textContent === 'Reconnecting…'"), "phone disconnect");
    await post(desktop, "Post while phone is offline");
    await until(() => hasPost(desktop, "Post while phone is offline"), "offline test post saved");
    assert.equal(await hasPost(phone, "Post while phone is offline"), false);
    await desktop.eval(`${like}.click()`);
    await until(async () => (await count(desktop)) === '❤️ · 2', "second viewer Like");
    await post(phone, "Keep this offline draft");
    await until(() => phone.eval("document.querySelector('#feedback').textContent.includes('Your draft is still here')"), "failed post feedback");
    assert.equal(await phone.eval("document.querySelector('#body').value"), "Keep this offline draft");
    await phone.call("Network.emulateNetworkConditions", {
        offline: false, latency: 250, downloadThroughput: 64_000, uploadThroughput: 32_000,
    });
    await phone.eval("window.dispatchEvent(new Event('online'))");
    await until(async () => await live(phone) && await hasPost(phone, "Post while phone is offline"), "phone catches up");
    await until(async () => (await count(phone)) === '❤️ · 2', "phone reloads missed reaction");
    await phone.eval(`${like}.click()`);
    await until(async () => (await count(phone)) === '♡ · 1' && (await count(desktop)) === '❤️ · 1', "unlike restores the outline and updates the shared count");
    assert.equal(await phone.eval(`${like}?.getAttribute('aria-pressed')`), 'false');
    await phone.eval("document.querySelector('#composer').requestSubmit()");
    await until(() => hasPost(desktop, "Keep this offline draft"), "retry reaches desktop");
    assert.equal(await desktop.eval("[...document.querySelectorAll('.post-body')].filter(node => node.textContent === 'Keep this offline draft').length"), 1);

    await phone.call("Page.reload");
    await until(() => live(phone), "phone reload and live reconnect");
    await phone.eval("document.querySelector('.branch-toggle:not([hidden])').click()");
    await until(() => hasPost(phone, "Phone replies"), "reply page reload");
    assert.equal(await deleteCount(phone), 2);
    const replyId = await phone.eval("document.querySelector('.reply-branch article').dataset.postId");
    await other.call("Page.navigate", {url: invite + "#post=" + replyId});
    await until(() => hasPost(other, "Phone replies"), "post target opens a collapsed group without posting or accepting terms");
    assert.equal(await other.eval("!document.querySelector('.agreement-dialog')"), true);
    if (media) {
        await phone.call("Network.emulateNetworkConditions", {...network, offline: false});
        await checkMedia(desktop, phone);
    }
    if (modes.includes("--agreements")) {
        await other.call("Page.navigate", {url: otherInvite});
        await until(() => live(other), "separate guest returns to other thread");
        await phone.call("Page.navigate", {url: otherInvite});
        await until(() => live(phone), "same browser follows another invite");
        await post(phone, "Second thread draft");
        await until(() => phone.eval("Boolean(document.querySelector('.agreement-dialog[open]'))"), "separate acceptance on a new thread");
        assert.equal(await hasPost(other, "Second thread draft"), false);
        await phone.eval("document.querySelector('[data-decline]').click()");
    }
    console.log("PASS two viewers, separate thread isolation, phone layout, live replies, own deletion, slow reconnect, draft retry, and ownership after reload");
    console.log("Post submit to visible in the other browser: " + desktopToPhone + " ms / " + phoneToDesktop + " ms");
}

async function checkFollowing(browser, invite) {
    await browser.eval("document.querySelector('#follow-thread').click()");
    await until(() => browser.eval("!document.querySelector('#follow-panel').hidden"), "follow panel");
    await until(() => browser.eval("!document.querySelector('#save-follow').disabled"), "follow controls ready");
    await browser.eval("document.querySelector('#follow-mode').value = 'muted'; document.querySelector('#save-follow').click()");
    await until(() => browser.eval("document.querySelector('#follow-status').textContent.includes('Alerts are muted')"), "muted bookmark");
    const {id} = await browser.eval("JSON.parse(localStorage.getItem('dysociate-following-v1'))[0]");
    await browser.call("Page.navigate", {url: origin.origin + "/t/following"});
    await until(() => browser.eval("document.querySelector('#follow-list article a')?.textContent === 'Browser test thread'"), "thread saved in Following");
    const path = new URL(invite).pathname;
    const snapshot = await (await fetch(new URL('/api/v1/threads/' + path.slice(3), origin), {signal: AbortSignal.timeout(5000)})).json();
    const target = origin.origin + "/t/following#open=" + id + "." + snapshot.posts[0].id;
    await browser.call("Page.navigate", {url: target});
    await until(() => browser.eval("document.activeElement?.dataset.postId === " + JSON.stringify(snapshot.posts[0].id)), "opaque link opens exact post");
    await browser.eval("document.querySelector('#follow-thread').click(); document.querySelector('#remove-follow').click()");
    await until(() => browser.eval("document.querySelector('#follow-status').textContent.includes('Removed')"), "unfollow");
    assert.equal(await browser.eval("localStorage.getItem('dysociate-following-v1')"), "[]");
    console.log("PASS Following, muted enrollment, opaque notification navigation, and unfollow");
}

async function checkPushEnrollment() {
    const invite = await createThread();
    const phone = await browserSession(390, 844, invite);
    await until(() => live(phone), "thread ready for phone alerts");
    await phone.eval(`(async () => {
        const keys = await crypto.subtle.generateKey({name: 'ECDH', namedCurve: 'P-256'}, true, ['deriveBits']);
        const b64 = bytes => btoa(String.fromCharCode(...bytes)).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, '');
        const p256dh = b64(new Uint8Array(await crypto.subtle.exportKey('raw', keys.publicKey)));
        const auth = b64(crypto.getRandomValues(new Uint8Array(16)));
        const active = {toJSON: () => ({endpoint: 'https://fcm.googleapis.com/fcm/send/local-enrollment-test', keys: {p256dh, auth}}),
            unsubscribe: async () => true};
        const registration = {pushManager: {
            getSubscription: async () => null,
            subscribe: async options => {
                if (!options.userVisibleOnly || options.applicationServerKey.length !== 65) throw Error('Invalid public key');
                return active;
            },
        }};
        Object.defineProperty(Notification, 'permission', {value: 'granted'});
        Object.defineProperty(navigator.serviceWorker, 'ready', {value: Promise.resolve(registration)});
        navigator.serviceWorker.register = async () => registration;
        document.querySelector('#follow-thread').click();
        return true;
    })()`);
    const mode = "document.querySelector('#follow-mode')";
    const save = "document.querySelector('#save-follow')";
    const status = "document.querySelector('#follow-status').textContent";
    assert.equal(await phone.eval(`${mode}.value`), "replies");
    await until(() => phone.eval(`!${save}.disabled`), "phone alerts ready to save");
    await phone.eval(`${save}.click()`);
    await until(() => phone.eval(`${status}.includes('Replies to me alerts are on')`), "replies enrollment saved");
    await phone.eval(`${mode}.value = 'all'; ${save}.click()`);
    await until(() => phone.eval(`${status}.includes('All activity alerts are on')`), "all activity enrollment saved");
    await phone.eval(`${mode}.value = 'muted'; ${save}.click()`);
    await until(() => phone.eval(`${status}.includes('Alerts are muted')`), "explicit mute saved");
    console.log("PASS phone alert enrollment defaults to Replies to me, saves both alert modes, and mutes only on request");
}

async function checkBackgroundPush() {
    const invite = await createThread();
    const phone = await browserSession(390, 844, invite);
    await until(() => live(phone), "test thread live");
    await cdp("Browser.grantPermissions", {browserContextId: phone.browserContextId, origin: origin.origin,
        permissions: ["notifications"]});
    await phone.eval(`(async () => {
        await navigator.serviceWorker.register('/t/push-sw.js', {scope: '/t/'});
        await navigator.serviceWorker.ready;
        return true;
    })()`);
    const observer = await browserSession(390, 844, new URL("/t/following", origin).href, phone.browserContextId);
    await observer.call("ServiceWorker.enable");
    const registrationId = await until(() => registrations.get(new URL("/t/", origin).href), "notification worker registration");
    await phone.call("Page.setWebLifecycleState", {state: "frozen"});
    const status = () => observer.eval(`navigator.serviceWorker.ready.then(registration => registration.getNotifications())
        .then(items => items.map(item => ({tag: item.tag, renotify: item.renotify, postId: item.data?.postId})))`);
    const followId = "a".repeat(43);
    const send = postId => observer.call("ServiceWorker.deliverPushMessage", {origin: origin.origin, registrationId,
        data: JSON.stringify({followId, postId})});
    try {
        const first = "p_" + "b".repeat(22);
        const second = "p_" + "c".repeat(22);
        await send(first);
        await until(async () => (await status()).some(item => item.postId === first), "system notification with thread tab frozen");
        await send(second);
        await until(async () => (await status()).some(item => item.postId === second), "alert replaces the previous post notification");
        assert.deepEqual((await status()).filter(item => item.tag === followId), [{tag: followId, renotify: true, postId: second}]);
    } finally {
        await phone.call("Page.setWebLifecycleState", {state: "active"});
    }
    console.log("PASS Chromium posts and renews a system notification while the live thread tab is frozen");
}
